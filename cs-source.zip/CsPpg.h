#if !defined(AFX_CSPPG_H__E7CB9F12_9316_11D1_9709_00A024CB61CA__INCLUDED_)
#define AFX_CSPPG_H__E7CB9F12_9316_11D1_9709_00A024CB61CA__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// CsPpg.h : Declaration of the CCsPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CCsPropPage : See CsPpg.cpp.cpp for implementation.

class CCsPropPage : public COlePropertyPage
{
        DECLARE_DYNCREATE(CCsPropPage)
        DECLARE_OLECREATE_EX(CCsPropPage)

// Constructor
public:
        CCsPropPage();

// Dialog Data
        //{{AFX_DATA(CCsPropPage)
        enum { IDD = IDD_PROPPAGE_CS };
                // NOTE - ClassWizard will add data members here.
                //    DO NOT EDIT what you see in these blocks of generated code !
        //}}AFX_DATA

// Implementation
protected:
        virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
        //{{AFX_MSG(CCsPropPage)
                // NOTE - ClassWizard will add and remove member functions here.
                //    DO NOT EDIT what you see in these blocks of generated code !
        //}}AFX_MSG
        DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CSPPG_H__E7CB9F12_9316_11D1_9709_00A024CB61CA__INCLUDED)
