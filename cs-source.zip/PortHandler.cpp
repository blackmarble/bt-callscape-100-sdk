// PortHandler.cpp: implementation of the CPortHandler class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//#include "coms32.h"
#include "PortHandler.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPortHandler::CPortHandler()
{
	strcpy(signature,"PortHandler");
}

CPortHandler::~CPortHandler()
{

}
