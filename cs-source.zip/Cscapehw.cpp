// Cscapehw.cpp: implementation of the CallScapeHW class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
// #include "coms32.h"
#include "Cscapehw.h"
#include "comcmd.h" // the callscape commands
// #include "CallScapeHandler.h"
#include "csctl.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

// GLOBAL for Command timer
bool g_bCommandTimerMatured; 	
CallScapeHW * g_Object = NULL;

void CALLBACK EXPORT CommandTimerProc(HWND hWnd, UINT nMsg, UINT nIDEvent, DWORD dwTime )
{
	TRACE("COMMAND TIMER MATURED");
	// only do this once
	if (!g_bCommandTimerMatured) {
		g_bCommandTimerMatured = true;
		if (g_Object != NULL) {
			g_Object->HandleCallScapeError("Command Timeout");

		}
	} // endif !g_bCommandTimer
}

// GLOBAL for Query timer
bool g_bQueryTimerMatured; 	

void CALLBACK EXPORT QueryTimerProc(HWND hWnd, UINT nMsg, UINT nIDEvent, DWORD dwTime )
{
	TRACE("Query TIMER MATURED");
	if (g_Object != NULL) {
		g_Object->QueryBox();
	}
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CallScapeHW::CallScapeHW(CCsCtrl * myHandler)
{
	// we need a port
	if (myHandler == NULL) {
		TRACE("CallScapeHandler is NULL\r\n");
		// error - return
	} 
	g_Object = this;
	m_uiCommandTimer = 0; // there isn't one yet
	g_bCommandTimerMatured = false;
	m_bValidResponse = false;
	// try a signature check first ?? 
//	if (strcmp(myHandler->signature,"CallScapeHandler") == 0) {
//		TRACE("CallScapeHW::Valid Handler supplied\r\n");
		m_Handler = myHandler;
//	} else {
//		TRACE("CallScapeHW::Invalid Handler supplied\r\n");
//	} // end else

	bConnected = FALSE;
//	m_LogStruct = LogStruct;
//	m_RxBuffer = LogStruct->IncomingData;
	// m_iState = CS_STATE_NOTCONNECTED;
	// initialize the command structure
	memset (m_CurrentCmd.sBuffer, 0, MAX_BUFFER_SIZE) ;
	m_CurrentCmd.nLength = 0;
	m_CurrentCmd.nRetry = 0;
	m_CurrentCmd.bWaiting = FALSE;
 // callscape incoming 
	m_nState = STATE_IDLE ; 
	// we are not currently processing
	// but we need to wait for threads to start
	m_byCommand = 0;
	m_nBuffer = 0;
	m_byChecksum = 0;
 // end of callscape 

} // end of Constructor

CallScapeHW::~CallScapeHW()
{
	delete m_myPort;
} // end of destructor

// Start Commandtimer
short CallScapeHW::StartCommandTimer()
{
	// if there is one running reset it
	if (m_uiCommandTimer != 0) {
	    StopCommandTimer();
	} 
	TRACE("Starting CommandTimer!");
	g_bCommandTimerMatured = false;
	m_uiCommandTimer = ::SetTimer(  NULL, 0,  CS_COMMAND_TIMEOUT_VAL, CommandTimerProc);
	if (m_uiCommandTimer == 0)
		TRACE("CommandTimer failed to initialize\r\n");
	return m_uiCommandTimer;
} // end of StartCommandTimer

// Stop CommandTimer
short CallScapeHW::StopCommandTimer()
{
	TRACE("Stopping CommandTimer!");
	if (m_uiCommandTimer == 0)
		return 0; // indicate success
	g_bCommandTimerMatured = false;
	// we can't use KillTimer because we are not a window
	return ::KillTimer(NULL, m_uiCommandTimer);
} // end of StopCommandTimer

// pass to callscape controls so that it display status

int CallScapeHW::HandleCallScapeEvent(int nCallScapeEvent, PBYTE lpBuf, DWORD dwBufLen)
{
	// first allocate the memory for the message
	TRACE("Callscape event\r\n");
	TRACE("Stopping command timer\r\n");
	StopCommandTimer();
	char * pDataPart = (char *) malloc(dwBufLen+1); // +1 to be on the safe side !
	if (pDataPart == NULL) {
		return CS_ERR_MEMORY;
	}
	// indicate that something has happened
	m_bValidResponse = true;
	
	// now allocate some memory for the structure
	TRACE("pDataPart at %lx\r\n", pDataPart);
	PCS_MESSAGE_STRUCT ms = (PCS_MESSAGE_STRUCT) malloc(sizeof(CS_MESSAGE_STRUCT));
	
	if (ms == NULL) {
		free (pDataPart) ; // we don't want this anymore
		return CS_ERR_MEMORY;
	}
	TRACE("ms alloced at %lx\r\n", ms);
	// now, we have to store lpBuf into the allocated memory
	// the memory is good - on to filling the structure
	memcpy(pDataPart, lpBuf, dwBufLen);
	// and set the pointer in the messagestruct to this block of memory
	ms->psData = pDataPart;
	// now set the Event code..
	ms->iEvent = nCallScapeEvent;
	// and post the message - handler must free up this memory
	m_Handler->PostMessage(CS_WM_EVENT, (WPARAM) ms, (LPARAM) dwBufLen);
	return CS_OK;
}

int CallScapeHW::HandleCallScapeError(PCHAR szMessage)
{
	// stop any timer that is running
	TRACE("HandleCallScapeError\r\n");
	TRACE("Stopping command timer\r\n");
	StopCommandTimer();
	TRACE("Should be handling error [%d]: >>%s<<", strlen(szMessage), szMessage);
	//return CS_OK; // don't send the message......
	// first allocate the memory for the message
	// this must not be reentrant....
	char * pDataPart = (char *) malloc(strlen(szMessage));
	if (pDataPart == NULL) {
		return CS_ERR_MEMORY;
	}
	// indicate that something has happened
	m_bValidResponse = true;
	
	// now allocate some memory for the structure
	TRACE("pDataPart alloced at %lx\r\n", pDataPart);
	PCS_MESSAGE_STRUCT ms = (PCS_MESSAGE_STRUCT) malloc(sizeof(CS_MESSAGE_STRUCT));
	
	if (ms == NULL) {
		free (pDataPart); // we don't want this anymore
		return CS_ERR_MEMORY;
	}
	// now, we have to store lpBuf into the allocated memory
	TRACE("ms alloced at %lx\r\n",ms);
	// the memory is good - on to filling the structure
	memcpy(pDataPart, szMessage, strlen(szMessage));
	// and set the pointer in the messagestruct to this block of memory
	ms->psData = pDataPart;
	// now set the Event code..
	ms->iEvent = 0;
	// and post the message - handler must free up this memory	
	m_Handler->PostMessage(CS_WM_ERROR, (WPARAM) ms, (LPARAM) strlen(szMessage));
	return CS_OK;
}

int CallScapeHW::HandleCallScapeMessage(PCHAR szMessage)
{
	// first allocate the memory for the message
	char * pDataPart = (char *) malloc(strlen(szMessage));
	if (pDataPart == NULL) {
		return CS_ERR_MEMORY;
	}
	// indicate that something has happened
	m_bValidResponse = true;
	
	TRACE("pDataPart alloced at %lx\r\n", pDataPart);
	// now allocate some memory for the structure
	PCS_MESSAGE_STRUCT ms = (PCS_MESSAGE_STRUCT) malloc(sizeof(CS_MESSAGE_STRUCT));
	
	if (ms == NULL) {
		free (pDataPart); // we don't want this anymore
		return CS_ERR_MEMORY;
	}
	
	TRACE("ms alloced at %lx\r\n",ms);
	// now, we have to store lpBuf into the allocated memory
	// the memory is good - on to filling the structure
	memcpy(pDataPart, szMessage, strlen(szMessage));
	// and set the pointer in the messagestruct to this block of memory
	ms->psData = pDataPart;
	// now set the Event code..
	ms->iEvent = 0;
	// and post the message - handler must free up this memory
	m_Handler->PostMessage(CS_WM_MESSAGE, (WPARAM) ms, (LPARAM) strlen(szMessage));
	return CS_OK;
}

// choose which port the callscape is connected to
int CallScapeHW::SetComPort(PCHAR szPortName)
{
  // the Port Should be opened for that name
  if (strlen(szPortName) > CS_SIZE_PORTNAME)
	  return CS_ERR_PORTNAMETOOLONG;
  strcpy(m_szMyPortName,szPortName);
  return CS_OK;
} // end of SetComPort

PCHAR CallScapeHW::GetComPort()
{
	if (strlen(m_szMyPortName) >= 4)  // assume it's valid
		return m_szMyPortName;
	else // assume it's invalid
		return NULL;
} // end of GetComPort

// connect to the hardware
int CallScapeHW::Connect()
{
	int iRetCode = CS_OK;
	char tmpErrMsg[10];
	HANDLE theHandle;
	if (bConnected) return CS_ERR_CONNECTED;
	m_myPort = new Port(this);
	m_myPort->SetName(GetComPort());

	iRetCode = ConfigurePort();
	if (iRetCode == CS_OK) {
		theHandle = m_myPort->SetupCommPort();
		TRACE("The handle is %lx", theHandle);
		if ((theHandle == 0) || (theHandle == NULL)) {
			iRetCode == CS_ERR_PORTCONFIG;
		}
	}
	if (iRetCode == CS_OK) {
		iRetCode = m_myPort->UpdateConnection();
	}

	if (iRetCode != CS_OK) {
	    sprintf(tmpErrMsg,">%x<",iRetCode);
		HandleCallScapeError(tmpErrMsg);
		return CS_ERR_PORTCONFIG;
	}
	bConnected = true;
	if (m_myPort->m_nStatus != P_OK) {
		return CS_ERR_BUSY;
		TRACE("Connect returning BUSY");
	} else {
		TRACE("Connect returning OK");
		return CS_OK;
	}
} // end of Connect

// close down the hardware
int CallScapeHW::Shutdown()
{
	if (!bConnected) {// give error but try to disconnect anyway so that
		// hardware is not confused
		TRACE("Error - shutdown called but not connected");
		return CS_ERR_PORTDISCONNECTED;
	} else {
	     m_myPort->BreakDownCommPort();
	}
	bConnected = FALSE;
	StopCommandTimer();
	return CS_OK;
} // end of Shutdown


int CallScapeHW::HandlePortEvent(int nPortEvent, PBYTE lpBuf, DWORD dwBufLen)
{
// we are expecting one of 4 basic commands
	//	1. One byte command start with ESC.  
//		ESC <Command byte>
//		2. Muti-byte command with format like: 
//		ESC2 <Length> <Command byte> <Parameters> <Checksum>
//		*	The data length is total number of data in bytes which do not
//			include <ESC2> and <Data Length byte> and <Checksum>.
// 		*	The <Checksum> is total sum value of the send data being inversed
//			and then plus one. 
//		We also have two types of acknowledgments:
// 		1. One byte acknowledgment as:
//		ACK, NAK
//		2. Muti-byte acknowledgment with format like:
//		ACK2 <Length> <Parameters> <Checksum>
//		*	The data length is total number of data in bytes which do not
//			include <ACK2> and <Data Length byte> and <Checksum>.
// 		*	The <Checksum> is total sum value of the send data being inversed
//			and then plus one. 
	static BYTE tmpBuf[3]; // to construct the ACK message
	DWORD i = 0;
	int iRetCode = 0;
// 	TRACE(">>Processing %d bytes<<\r\n",dwBufLen);
	for (i = 0; i < dwBufLen;i++) {
		// TRACE("(i=%d)",i);
		switch(m_nState) {
		case STATE_IDLE:
			TRACE("Expecting ESC/2/3\r\n");
			m_nParamCount = 0; // (data includes the command parameter)
			switch(lpBuf[i]) {
			case ESC:
				TRACE("ESC received\r\n");
				m_nBytesRemaining = 0; // expect no data bytes
				m_byBlock = ESC;
				m_nState = STATE_WAITCMDBYTE;
				m_byChecksum = ESC;
				TRACE("Expecting Command\r\n");
			break;
			case ESC2: 
				TRACE("ESC2 received\r\n");
				m_nState = STATE_WAITLENBYTE;
				m_byBlock = ESC2;
				m_byChecksum = ESC2;
				TRACE("Waiting for length byte\r\n");
			break;				
			case ESC3:
				TRACE("ESC3 received\r\n");
				m_nState = STATE_WAITLENBYTE;
				TRACE("Waiting for length byte\r\n");
				m_byBlock = ESC3;
				m_byChecksum = ESC3;
			break;
			default:
				// something has gone wrong here..
				TRACE("Unexpected response : %x", lpBuf[i]);
			} // end switch in STATE_IDLE
		break;
		case STATE_WAITRESPONSE:
			TRACE("Expecting ACK/NAK\r\n");
			m_nParamCount = 0; // (data includes the command parameter)
			switch(lpBuf[i]) {
			case ACK:
				TRACE("ACK RECEIVED\r\n");
				// back to IDLE ??
				m_nState = STATE_IDLE;
				break;
			case ACK2:
				TRACE("ACK2 RECEIVED\r\n");
				// same as ESC2 from here
				m_nState = STATE_WAITLENBYTE;
				// m_byBlock = ACK2; // ACK2 must be in response to something,
				// we must have set this when we issued the command
				m_byChecksum = ACK2;
				TRACE("Waiting for length byte\r\n");
				break;
			case NAK:
				TRACE("NAK RECEIVED\r\n"); // do we try again here ?
				break;
		    // after observing behaviour - we can get an ESC here instead of an ACK/NAK
			// so we really ought to do that instead.  Not sure what happens to our
		    // command - presumably it has failed. need to keep a command id to 
			// detect and report failures - but user won't know what command
		    // has failed unless I return a handle when they issue it
			case ESC:
				TRACE("Received an ESC whilst waiting for an ACK - last command failed ?\r\n");
				m_nBytesRemaining = 0; // expect no data bytes
				m_byBlock = ESC;
				m_nState = STATE_WAITCMDBYTE;
				m_byChecksum = ESC;
				TRACE("Expecting Command\r\n");
				break;
			case ESC3:
				// shouldn't be an ESC3 but what the hell
				TRACE("ESC3 received\r\n");
			case ESC2:
				TRACE("Received an ESC2 whilst waiting for an ACK - last command failed ?\r\n");
				m_nState = STATE_WAITLENBYTE;
				m_byBlock = ESC2;
				m_byChecksum = ESC2;
				TRACE("Waiting for length byte\r\n");
				break;

			default :
				TRACE("Unexpected response : %x", lpBuf[i]);
			} // end of switch in STATE_WAITRESPONSE
		break;
		case STATE_WAITLENBYTE:
			TRACE("Got Length byte %d\r\n",lpBuf[i]);
			m_nBytesRemaining = lpBuf[i]; // how many data to expect - including command byte
			
			m_byChecksum += lpBuf[i]; // length byte is included in checksum calculation
			// ACK2 goes straight to data, others use cmdbyte
			switch(m_byBlock) {
			case(PBEX2) : // ack2 and pbex2 should be treated the same way here
			case (ACK2) :  
				m_nState = STATE_WAITDATABYTE;
				TRACE("Expecting %d Data....", m_nBytesRemaining);
			break;
			case (ESC2):
			case (ESC3):
				m_nState = STATE_WAITCMDBYTE;
				TRACE("Expecting Command....");
			break;
			case (BPCM2): // CLIP only transfer - not memory block upload
				// add the length to the message
				m_CmdParams[m_nParamCount++] = m_nBytesRemaining;
				// don't break here - do the same as pbcm6
			case (PBCM6):
				TRACE("Received length byte - now onto data");
				// peculiarity - need this length byte as part of message
				// m_CmdParams[m_nParamCount++] = m_nBytesRemaining;
				// the first data byte should be the CLIP message id Ox80
				m_nState = STATE_WAITDATABYTE;
				TRACE("PBCM6 : Expecting %d data....", m_nBytesRemaining);
				break;

			default : TRACE("Invalid state - waitlenbyte for block %x", m_byBlock);
				m_nState = STATE_IDLE;
			} // end switch
		
		break;
		case STATE_WAITCMDBYTE:
			TRACE("Recieved Command %x\r\n", lpBuf[i]);
			if (m_byBlock == ESC) {// this is it - return ACK
				m_byCommand = lpBuf[i];
				// if length specified there should be at least 1 data (cmd + 1data = 2)
				// do command and return ACK or NACK
				TRACE("Command received : %x\r\n", lpBuf[i]);
				tmpBuf[1] = 0;
				if (ProcessCommand()== CS_OK) { // process command knows what state we were in..
					TRACE("Replying ACK\r\n");
					tmpBuf[0] = ACK;
				} else {
					TRACE("Replying NAK\r\n");
					tmpBuf[0] = ACK;
				} 
				// transmit our reply
				TxData(tmpBuf, 1); // only one byte to send
				// only reset to IDLE if one of the other commands doesn't require further information
				// i.e. CLIP data transfer
				if (m_nState == STATE_WAITCMDBYTE) {
					m_nState = STATE_IDLE;
				} // endif m_nState == STATE_WAITCMDBYTE
				// endif ESC
			} else {
			// could be ESC2 or ESC3 

			if (m_nBytesRemaining >=2 ) { 
				   m_nBytesRemaining--; //
				} else {
					TRACE("suspect data stream\r\n");
				} // endif m_nBytesRemaining >=2
				
			m_byCommand = lpBuf[i];
			m_byChecksum += m_byCommand; // start the checksum 
			m_nState = STATE_WAITDATABYTE;
			m_nParamCount=0; // reset counter
			TRACE("Expecting %d DataBytes\r\n", m_nBytesRemaining);
			} // end else (m_byBlock != ESC)
		break;
		case STATE_WAITDATABYTE:
			TRACE("[b%x = 0x%x]", m_nParamCount,lpBuf[i]);
			m_nBytesRemaining--;
			m_CmdParams[m_nParamCount++] = lpBuf[i];
			m_byChecksum += lpBuf[i]; // running total
			// TRACE("Checksum accumulator now at %x\r\n", m_byChecksum);
			if (m_nBytesRemaining == 0) {// got all the bytes we need
				m_nState = STATE_WAITCHECKSUM;
				TRACE("\r\nall bytes received...");
				TRACE("Expecting Checksum...");
			}
		break;	
		case STATE_WAITDATAHEAD:
			switch (lpBuf[i]) {
			case (ESC2) :
				/*
				TRACE("ESC2 received when we were expecting head data...");
				m_byBlock = ESC2;
				m_nBytesRemaining = 0;
				m_nParamCount = 0;
				m_nState = STATE_WAITLENBYTE;
				*/
				break;
			case (ESC) :

				TRACE("ESC received when we were expecting head data...");
				// we expect a command next - ignore what we are doing and run that
				// suspend any outgoing commands that we may have ??
				/*
				m_byBlock = ESC;
				m_nState = STATE_WAITCMDBYTE;				
				m_nBytesRemaining = 0;
				m_nParamCount = 0;
				*/
				// reply NAK
				TRACE("REPLYING NAK\r\n");
				m_nState = STATE_IDLE; // just reset for now - we should get the retry
		    	tmpBuf[0] = NAK;
		
				TxData(tmpBuf, 1); // only one byte to send
		
				break;
			default:
			    TRACE("Recieved datahead - expecting length");
				m_nState = STATE_WAITLENBYTE;
				// include this in the checksum ? - I think this is in the ptspiexe.cpp file
				// PBCM6 does not want the length byte as the data head
				if (m_byBlock != PBCM6) {
					TRACE("!=PBCM6");
				   m_CmdParams[m_nParamCount++] = lpBuf[i]; // we need the head in the CLIP info
				} else {// endif
					TRACE("==PBCM6");
				} // endif
				m_byChecksum = lpBuf[i];
			} // end of switch
			break;
		case STATE_WAITCHECKSUM:
			TRACE("Got Checksum.(%x)...", lpBuf[i]);
			m_nState = STATE_IDLE; // nothing more to do - might as well reset.
			if ((m_byChecksum += lpBuf[i]) == 0) {
				TRACE("Checksum Passed\r\n");
				m_bBadChecksum = FALSE;
			} else {
				TRACE("*** Checksum failed ***\r\n");
				m_bBadChecksum = TRUE;
			} // endif
			// process message here
			switch (m_byBlock) {
			case (ESC3) :
			case (ESC2) :
				iRetCode = ProcessCommand();
				m_nState = STATE_IDLE;  // that's all for this time
				break;
			case (BPCM2):
				m_nState = STATE_WAITCLASSID; // extra byte after checksum (not sure why but psp have it)
				break;
			case (PBEX2):
				m_nState = STATE_IDLE; // let's try to interpret the Query Struct
				BOXINFO tmpBoxInfo;
				// dirty but useful
				memcpy((void *) &tmpBoxInfo, m_CmdParams, m_nParamCount);
				// see if we can see these data
				iRetCode = ProcessQuery(&tmpBoxInfo);
				break;
			case (PBCM6): // uploading mem from the box
				iRetCode = ProcessBPCM2(CS_INCOMING_CLIP_OLD);
				// if there are more to do - issue another upload command
			} // end switch
			
			// send an ACK/NACK
			// if command processed successfully
			// we've already set the state back to idle, so all that remains is to respond...
			if (m_byBlock != ACK2) { // we don't ACK an ACK2, only ESC/2 commands
					tmpBuf[1] = 0; // prepare the message
				if ((!m_bBadChecksum) && (iRetCode==CS_OK)) {
					TRACE("Replying ACK\r\n");
					    tmpBuf[0] = ACK;
				} else { // something went wrong, either bad checksum or command failed
					TRACE("Replying NAK\r\n");
					tmpBuf[0] = NAK;
				} // endif
				TxData(tmpBuf, 1); // only one byte to send
			}
			break;
		case STATE_WAITCLASSID:
			// special case, we've received ClipInfo
			iRetCode = ProcessBPCM2(CS_INCOMING_CLIP_NEW); // tell ProceseBPCM2 this is live
			if ((!m_bBadChecksum) && (iRetCode==CS_OK)) {
					TRACE("Replying ACK\r\n");
					    tmpBuf[0] = ACK;
				} else { // something went wrong, either bad checksum or command failed
					TRACE("Replying NAK\r\n");
					tmpBuf[0] = NAK;
				} // endif
				TxData(tmpBuf, 1); // only one byte to send
				m_nState = STATE_IDLE; 
			break;
		default :
			TRACE("SERIOUS ERROR : Invalid state\r\n");
			m_nState = STATE_IDLE;
		} // end switch
	} // end of for each byte in the buffer	
	// depends what state we are in here...
	// if (m_nState == STATE_WAITDATABYTE)
       //TRACE("leaving HandleEvent - expecting a further %d bytes \r\n",m_nBytesRemaining);	
	return PH_OK; // we handled the event successfully
} // end of HandlePortEvent

int CallScapeHW::HandlePortError(PCHAR szMessage) 
{
	TRACE("CallScapeHW::HandlePortError\r\n");
	HandleCallScapeError(szMessage);
	return PH_OK;
}

int CallScapeHW::HandlePortMessage(PCHAR szMessage) 
{
	TRACE("CallScapeHW::HandlePortMessage\r\n");
	HandleCallScapeMessage(szMessage);
	return PH_OK;
}

int CallScapeHW::ConfigurePort()
{
	TRACE("Setting com property info\r\n");
	if (m_myPort==NULL) return CS_ERR_INVALID;
    m_myPort->SetConnected(FALSE);
    m_myPort->SetBaudRate(CBR_4800);
	m_myPort->SetByteSize(8);
	m_myPort->SetParity(NOPARITY); //
	m_myPort->SetStopBits(ONESTOPBIT); //
	m_myPort->SetBinary(TRUE);
    //
    // timeouts
    //
	TRACE("Setting gTimeoutsDefault\r\n");
	//  gTimeoutsDefault = { 0x01, 0, 0, 0, 0 };
    gTimeoutsDefault.ReadIntervalTimeout = 0x01;
	gTimeoutsDefault.ReadTotalTimeoutMultiplier = 0x00;
	gTimeoutsDefault.ReadTotalTimeoutConstant = 0x00;
	gTimeoutsDefault.WriteTotalTimeoutMultiplier = 0x00;
	gTimeoutsDefault.WriteTotalTimeoutConstant = 0x00;

    m_myPort->SetTimeouts(gTimeoutsDefault);

    //
    // read state and status events
    //
	// ARH Receive state is not required - used to determine whether to log
	// to window or to a file
    // gdwReceiveState            = RECEIVE_TTY;
	m_myPort->SetEventFlags(EVENTFLAGS_DEFAULT);
	m_myPort->SetFlagChar(FLAGCHAR_DEFAULT);
    //
    // Flow Control Settings
    //
	m_myPort->SetDTRControl(DTR_CONTROL_HANDSHAKE);
	m_myPort->SetRTSControl(RTS_CONTROL_DISABLE);
	m_myPort->SetXONChar(ASCII_XON);
	m_myPort->SetXOFFChar(ASCII_XOFF);
	m_myPort->SetXONLimit( RXQ_SIZE/4 ); 
	m_myPort->SetXOFFLimit(RXQ_SIZE/4 * 3);
// not required - these default to false.
//	m_myPort->SetCTSOutFlow(FALSE);
//	m_myPort->SetDSROutFlow(FALSE);
//	m_myPort->SetDSRInFlow(FALSE);
//	m_myPort->SetXONXOFFOutFlow(FALSE);
//	m_myPort->SetXONXOFFInFlow(FALSE);
//	m_myPort->SetTXAFTERXOFFSENT(FALSE);

//	m_myPort->DisableReading(FALSE);
//	m_myPort->DisableWriting(FALSE);
//	m_myPort->DisableEvents(FALSE);
//	m_myPort->DisableStatus(FALSE);
//	m_myPort->SetShowTimeouts(FALSE);
    return ( CS_OK ) ;
}


int CallScapeHW::DoSelfTest()
{
	// self test uses ATZ command
	if (!bConnected)
		return CS_ERR_PORTDISCONNECTED;
	if (SendCommand(ATZ, NULL, 0)  != CS_OK ) { // loop until we can send
		// wait a bit
		// waitforsingleobject... delay
		TRACE("Waiting for sendcommand");
		return CS_ERR_BUSY;
	} // no params
	return CS_OK;
} // end of DoSelfTest

// Query box
int CallScapeHW::QueryBox()
{
	TRACE("QueryBox");
	
	if (!bConnected)
		return CS_ERR_PORTDISCONNECTED;
	// to use PBEX2, we need to send params
	StartCommandTimer();
	
	CTime theTime = CTime::GetCurrentTime();
	static PCINFO pcInfo;
	pcInfo.dwVersion = 0x00010003; // get current TAPI version here ?
	pcInfo.byHour = (char) theTime.GetHour();
	pcInfo.byMinute = (char) theTime.GetMinute();
	pcInfo.bySecond = (char) theTime.GetSecond();
	pcInfo.byMonth = (char) theTime.GetMonth(); 
	pcInfo.byDay = (char) theTime.GetDay();
	if (SendCommand(PBEX2, (PCHAR) &pcInfo, sizeof(PCINFO)) != CS_OK) {
		TRACE("Waiting for send command before issuing next");
		StopCommandTimer();
		return CS_ERR_BUSY;
	}
	return CS_OK;
} // end of QueryBox


// transmit bytes to the callscape
int CallScapeHW::TxData(PBYTE TxData, DWORD dwNumBytes)
{
	// transmit the raw data bytes to the CallScape
	// need to know how many to send
	 m_myPort->TxData(TxData, dwNumBytes);
	return CS_OK;
} // end of TxData

int CallScapeHW::SetSpeakerVolume(int val)
{
	int nReturnCode = CS_OK;
	switch (val) {
	case CS_SPEAKER_VOLUME_LOW : 
		if (SendCommand(ATL1, NULL, 0) != CS_OK) // no params
			nReturnCode = CS_ERR_BUSY;
		break;
	case CS_SPEAKER_VOLUME_MEDIUM :
		if (SendCommand(ATL2, NULL, 0) != CS_OK)
			nReturnCode = CS_ERR_BUSY;
		break;
	case CS_SPEAKER_VOLUME_HIGH :
		if (SendCommand(ATL3, NULL, 0) != CS_OK)
			nReturnCode = CS_ERR_BUSY;
		break;
	default : // don't do anything
		nReturnCode = CS_ERR_INVALID;
	} // end of switch
	
	return nReturnCode;
} // end of SetSpeakerVolume

int CallScapeHW::SendCommand(BYTE byCommand, // Command byte.
							 LPCSTR lpsParams, // Pointer to command params
							 BYTE byParaLen) // length of command parameters
{   
    // "byCommand" != 0 means there's a command to be sent out.
	if (m_myPort->m_nStatus != P_OK) {
		TRACE("Port is BUSY - not sending command\r\n");
		return CS_ERR_BUSY;
	}
	if( byCommand )
	{ // can only send commands when we are idle
		if( m_nState == STATE_IDLE )
		{                     
			// A command is pending ? 
			//if( m_cmdComm.bWaiting )  
				// In case a command was interrupted by Box command.
			//	return FALSE ;
			m_byBlock = byCommand; // useful when ACK2 comes back
			FillCommandBuffer( byCommand, lpsParams, byParaLen ) ;
			TRACE("**Sending Command %x\r\n", byCommand);
			
			TxCommand() ;
			
			// Set new serial states.
            if (( byCommand == PBCM6) || (byCommand == BPCM2)) {
				TRACE("Expecting data header from here");
				m_nParamCount = 0; // we must reset it here
                m_nState = STATE_WAITDATAHEAD ; // we need to know we've got the data head
               // m_staComm.idBlock   = BLOCK_MEMO ;
			} else {
               m_nState = STATE_WAITRESPONSE ;

			}
		} else {// end if state_idle
			TRACE("NOT IDLE - not sending command");
			return CS_ERR_BUSY;
		}
		//else
		//{   
			// Not in STATE_IDLE then see if we have already a command
			// trying to send out.                          
			
///			if( m_cmdComm.nLength == 0 )
//			{                     
				// No command waiting in command buffer then must be in
				// receive BOX data status, so fill the command buffer.
//				FillCommandBuffer( byCmd, lpsPara, byParaLen ) ;
				// But here we should wait until the end of current
				// transmission period.
//				m_cmdComm.bWaiting = TRUE ;  
				
//			}                  
//			else
//			{   
				// PTP 12/26/95 Change byCmd to byTemp for the byCmd has
				// the same name with the function parameter "byCmd". 
//				BYTE byTemp = ( m_cmdComm.nLength > 2 ) ?
//								m_cmdComm.sBuffer[2] :
//								m_cmdComm.sBuffer[1] ;
								                                
				// We assume that "Exchange", "Upload" command has a lower
				// priority that they can be overrided by the other command.
//				if( byTemp == ESCExchangeInfo || byTemp == ESCUploadMemory )
//				{
//					FillCommandBuffer( byCmd, lpsPara, byParaLen ) ;
					// But here we should wait until the end of 
					// current Exchange/Upload command.
//					m_cmdComm.bWaiting = TRUE ;
//				}
//				else
					// We cannot override the previous command that has not
					// been completed yet if it is neither "Exchange" nor 
					// "Upload" command.
//					return FALSE ;    
					
//			}	// End else( m_cmdComm.nLength == 0 ) ;
							  
	//	}	// End if( m_staComm.idProcess == STATE_IDLE ) / else block ;
		
	} else {	// End if( byCmd ) ;      
		// "byCmd" == 0 means repeat the last command.
	                                                     
//		ASSERT( m_cmdComm.nLength != 0 ) ;
			                                
		// If there's a command waiting then we should send this command
		// out.
//		if( m_cmdComm.bWaiting )
//		{
//			m_cmdComm.bWaiting 	= FALSE ;
			// Clear retry counter in case we've retried too many times
			// before pending this command.
//			m_cmdComm.nRetry 	= 0 ;
//			SendCommand() ;        
			
			// Note that the "Upload" command has no chance of retrying
			// it's command, so here we jump directly to 
			// "STATE_WAITRESPONSE".    
//			m_staComm.idProcess = STATE_WAITRESPONSE ;			  
			
//		}	// End if( m_cmdComm.bWaiting ) ;   
		//else                                 
		//{                              
		    // We allow retry only 3 times for one command except command
		    // "Query/Memo" which has no chance for retry at all.
			//if( m_cmdComm.nRetry < 2 )
			//{
				//m_cmdComm.nRetry++ ;      
				
//				m_byReceiveArray.RemoveAll() ;
				
//				SendCommand() ; 
				
				// Note that the "Upload" command has no chance of retrying
				// it's command, so here we jump directly to 
				// "STATE_WAITRESPONSE".  
//				m_staComm.idProcess = STATE_WAITRESPONSE ;			
				
//			}                       
//			else                                                   
//			{
				// Command retry fail we has to back to idle state.
//				m_staComm.idProcess = STATE_IDLE ;
//				m_cmdComm.nLength	= 0 ;
							
				// In case timeout in waiting BOX response and the command 
				// retry times have already exceeded three times. The 
				// receive buffer may have no datas in it, so here we
				// allocate NULL buffer for reporting command failure. 
//				PostTSPIEvent( FALSE ) ;

				// PTP 3/5/1996 added as required by TAPI.
				
				// No response from serial port for too many 
				// times so here we have to assume that the
				// serial port cannot work properly.
//				ReportLineStateChange( LINEDEVSTATE_DISCONNECTED ) ;
							
				// PTP 2/27/1997 Added as required by TAPI module.
//				m_staTSPI.infoBox.staAssociatedPhone = ON ;
				
				// Change states of all the exist calls.      
//				for( int i = 0 ; i < MAX_CALLHANDLE ; i++ )
//				{   
//					if( m_lpLine->lpCall[i] != NULL )
						// NOTE : Function "ReportCallStateChange"
						//		  will check if the call handle
						//		  is already in idle state and
						//		  report to TAPI only if it is
						//		  not in idle state, so here
						//		  it is unecessary to check
						//		  if the call handle is currently
						//		  in idle state.
//						ReportCallStateChange( m_lpLine->lpCall[i],
//											   LINECALLSTATE_IDLE 
//											 ) ;               
//				}
				
//				return FALSE ;
				
//			}   
			
//		}	// End else( m_cmdComm.bWaiting ) ;
		
	}  	// End else "byCmd" == 0 ;    
	
	return CS_OK ;
	
} // end of SendCommand

/*
 * Function:	FillCommandBuffer		
 * --------------------------------------------------------------------------
 * Purpose:		Fill command bytes into command buffer, set orginal command
 *				states.
 * Return:	    
 * Assumption:               
 *				The function is called only by "CommSendCommand".
 * --------------------------------------------------------------------------
 */                    
 void CallScapeHW::FillCommandBuffer( BYTE byCmd,   	// Command byte.
						   	 		  LPCSTR lpsPara,	// Pointer to command
						   	 		  					// parameters.
						     		  BYTE byParaLen 	// Length of command
						     		  					// parameters.
						    		)                                    
{
	int i = 0 ; 
	
	if( lpsPara ) // there are parameters defined - need ESC2 command
	{                    
		BYTE byChecksum ;
		     
		// Put command head.
		m_CurrentCmd.sBuffer[i] = ESC2 ;
		byChecksum = m_CurrentCmd.sBuffer[i++] ;
		                       
		// Put command data length.		                       
		m_CurrentCmd.sBuffer[i] = byParaLen + 1 ;
		byChecksum += m_CurrentCmd.sBuffer[i++] ;
		                                      
		// Put command byte.     
		m_CurrentCmd.sBuffer[i] = byCmd ;
		byChecksum += m_CurrentCmd.sBuffer[i++] ;

		// Put command parameters.
		for( int j = 0 ; j < byParaLen ; j++ )
		{                                         
			m_CurrentCmd.sBuffer[i] = lpsPara[j] ;
			byChecksum += m_CurrentCmd.sBuffer[i++] ; 
		}		                    
		  
		// Set checksum.	
		byChecksum = ~byChecksum ;
		byChecksum++ ;
			  
		m_CurrentCmd.sBuffer[i] = byChecksum ; 
		
		m_CurrentCmd.nLength = byParaLen + 4 ;
				
	} else 	{ // No additional command parameters then must be a single command.
		m_CurrentCmd.sBuffer[i++] 	= ESC ;
		m_CurrentCmd.sBuffer[i]   	= byCmd ;
		m_CurrentCmd.nLength 		= 2 ;	
	}   // End if( lpsPara )          
	                    
	// Set initial command states.	                    
	m_CurrentCmd.nRetry  	= 0 ;
	m_CurrentCmd.bWaiting  = FALSE ;
	
 }	// end of FillCommandBuffer


BOOL CallScapeHW::TxCommand()
{
	// this uses the member data for a command
	m_CurrentCmd.nRetry++;
	return m_myPort->TxData(m_CurrentCmd.sBuffer, m_CurrentCmd.nLength) ;
} // end of TxCommand

int CallScapeHW::Hangup()
{
	if (!bConnected)
		return CS_ERR_PORTDISCONNECTED;
//	if (!bInCall)
//		return CS_ERR_NOTINCALL;
	return SendCommand(ATH0, NULL, 0)?CS_OK:CS_ERR_BUSY; // no params
} // end of Hangup

int CallScapeHW::Dial(PCHAR szNumToDial)
{
  if (!bConnected)
	  return CS_ERR_PORTDISCONNECTED;
  // we know the number...
  int iLen = strlen(szNumToDial);
  // prepend the "T"
  // malloc enough memory ?
  // or use static
  DIAL_STRUCT szDialStruct; 
  // dial pause needs to go in front
  szDialStruct.isDialPause = (short) 3000;
  sprintf(szDialStruct.szDialString,"%s",szNumToDial);
  iLen = strlen(szDialStruct.szDialString) + sizeof(short); // the dialstruct 
  TRACE("DialString is now %s",(const char *) &szDialStruct);
  return SendCommand(ATD, (const char *) &szDialStruct, iLen)?CS_OK:CS_ERR_BUSY;
  // return CS_OK;
} // end of Dial

int CallScapeHW::ProcessCommand()
{ // use member variables for speed
	BOOL bReturnCode = CS_ERR_INVALID;
	switch (m_byCommand) {
	  case BPEV:
		  TRACE("BPEV\r\n");
		  // need the event DWORD here - fill a BOXEvent struct
		  BOXEVENT tmpBoxEvent;
		  // dirty but useful
		  memcpy((void *) &tmpBoxEvent, m_CmdParams, m_nParamCount);
		  // see if we can see these data
		  bReturnCode = ProcessBPEV(&tmpBoxEvent);
		  break;
	  case BPCM2:
		  TRACE("CS request permission to send CLIP information\r\n");
		  // if we send ACK - the box will send data as 
  		  // <HEAD<, <DATALENGH>, <DATA>, <CHECKSUM>
		  m_nState = STATE_WAITDATAHEAD; // we now want the data head...but this should
		  // go straight in data ??
		  TRACE("Expecting DataHead\r\n");
		  m_byBlock = BPCM2; // we are expecting a CLIP block
		  bReturnCode = CS_OK; // give the ACK go ahead
		  break;
	  default :
		  TRACE("Unsupported Command received : %x\r\n"), m_byCommand;
		  bReturnCode = CS_ERR_INVALID;
		  break;
	} // end of switch
	return bReturnCode;
} // end of ProcessCommand

int CallScapeHW::ProcessBPEV(BOXEVENT * beBE)
{
   // BPEV is made up of bit fields..
  // call HandleCallScapeEvent(event, null, 0)
  int iRetCode = CS_OK;
  if (beBE->evALT) {
		iRetCode = HandleCallScapeEvent(CS_EV_ALT, NULL, 0);
  }
  if (beBE->evCAS)  {
		iRetCode = HandleCallScapeEvent(CS_EV_CAS, NULL, 0);
  }
  if (beBE->evLineDisconnect)  {
		iRetCode = HandleCallScapeEvent(CS_EV_LINEDISCONNECT, NULL, 0);
  }  
  if (beBE->evPhoneOffWithinRing)  {
		iRetCode = HandleCallScapeEvent(CS_EV_PHONEOFFWITHINRING, NULL, 0);
  }
  if (beBE->evPhoneOffWithoutRing)  {
		iRetCode = HandleCallScapeEvent(CS_EV_PHONEOFFWITHOUTRING, NULL, 0);
  }
  if (beBE->evPhoneOnHook)  {
		iRetCode = HandleCallScapeEvent(CS_EV_PHONEONHOOK, NULL, 0);
  }
  if (beBE->evExtensionPhoneOff)  {
		iRetCode = HandleCallScapeEvent(CS_EV_EXTENSIONPHONEOFF, NULL, 0);
  }
  if (beBE->evExtensionPhoneOn)  {
		iRetCode = HandleCallScapeEvent(CS_EV_EXTENSIONPHONEON, NULL, 0);
  }
  if (beBE->evBOXOffFollowingRing)  {
		iRetCode = HandleCallScapeEvent(CS_EV_BOXOFFFOLLOWINGRING, NULL, 0);
  }
  if (beBE->evBOXOffWithoutRing)  {
		iRetCode = HandleCallScapeEvent(CS_EV_BOXOFFWITHOUTRING, NULL, 0);
  }
  if (beBE->evDialTone)  {
		iRetCode = HandleCallScapeEvent(CS_EV_DIALTONE, NULL, 0);
  }
  if (beBE->evRingBackTone)  {
		iRetCode = HandleCallScapeEvent(CS_EV_RINGBACKTONE, NULL, 0);
  }
  if (beBE->evBusyTone)  {
		iRetCode = HandleCallScapeEvent(CS_EV_BUSYTONE, NULL, 0);
  }
  if (beBE->evNUTone)  {
		iRetCode = HandleCallScapeEvent(CS_EV_NUTONE, NULL, 0);
  }
  if (beBE->evParkTone)  {
		iRetCode = HandleCallScapeEvent(CS_EV_PARKTONE, NULL, 0);
  }
  if (beBE->evSpecialTone)  {
		iRetCode = HandleCallScapeEvent(CS_EV_SPECIALTONE, NULL, 0);
  }
  if (beBE->evEndOfDialing)  {
		iRetCode = HandleCallScapeEvent(CS_EV_ENDOFDIALLING, NULL, 0);
  }
  if (beBE->evEndOfRing)  {
	  	iRetCode = HandleCallScapeEvent(CS_EV_ENDOFRING, NULL, 0);
  }
  if (beBE->evIncomingRing)  {
	  	iRetCode = HandleCallScapeEvent(CS_EV_INCOMINGRING, NULL, 0);
  }
  if (beBE->evSpecialRing)  {
		iRetCode = HandleCallScapeEvent(CS_EV_SPECIALRING, NULL, 0);	  
  }
  if (beBE->evCodedRing)  {
		iRetCode = HandleCallScapeEvent(CS_EV_CODEDRING, NULL, 0);	  
  }
  if (beBE->evDistinctiveRing)  {
		iRetCode = HandleCallScapeEvent(CS_EV_DISTINCTIVERING, NULL, 0);	  
  }
  if (beBE->evRemoteConnected)  {
		iRetCode = HandleCallScapeEvent(CS_EV_REMOTECONNECTED, NULL, 0);	  
  }
  if (beBE->evEndOfTone)  {
		iRetCode = HandleCallScapeEvent(CS_EV_ENDOFTONE, NULL, 0);	  
  }
  if (beBE->evDialing)  {
		iRetCode = HandleCallScapeEvent(CS_EV_DIALLING, NULL, 0);	  
  }
  if (beBE->evBoxOnHook)  {
		iRetCode = HandleCallScapeEvent(CS_EV_BOXONHOOK, NULL, 0);	  
  }
  if (beBE->evRemoteDisconnected)  {
	  	iRetCode = HandleCallScapeEvent(CS_EV_REMOTEDISCONNECTED, NULL, 0);
  }
  if (beBE->evHold)  {
		iRetCode = HandleCallScapeEvent(CS_EV_HOLD, NULL, 0);	  
  }
  if (beBE->evLineConnect)  {
		iRetCode = HandleCallScapeEvent(CS_EV_LINECONNECT, NULL, 0);	  
  }
  // DTMF char could be pressed
  char cDialled[2];
  cDialled[1] = 0; // make it simpler for the event handler
  if (beBE->byDTMF != 0xff) { // we have a char
	  switch (beBE->byDTMF) {
	  case 0x00 :
		  cDialled[0] = 'D'; // not sure what D is from...
		  break;
      case 0x0a :
		  cDialled[0] = '0';
		  break;
	  case 0x0b:
		  cDialled[0] = '*';
	  case 0x0c:
		  cDialled[0] = '#';
	  case 0x0d:
		  cDialled[0] = 'A';
	  case 0x0e:
		  cDialled[0] = 'B';
	  case 0x0f:
		  cDialled[0] = 'C';
	  case 0x10:
		  cDialled[0] = '!'; // (TBR ???)
	  default: // can cope with 1 to 9 here
		  if ( (beBE->byDTMF < 1) || (beBE->byDTMF > 0x09)) {
		  // error - invalid
			  TRACE("Invalid byDTMF received\r\n");
		  } // endif
		  cDialled[0] = 0x30 + beBE->byDTMF;
	  } // end switch
		  // send event with 1 byte of data (as an ascii char);
	  iRetCode = HandleCallScapeEvent(CS_EV_DIALCHAR, (PBYTE) cDialled, 1);
  }
  return iRetCode;
} // end of ProcessBPEV

int CallScapeHW::ProcessBPCM2(int nClipState) 
{
	// nClipState is either CS_INCOMING_CLIP_OLD or CS_INCOMING_CLIP_NEW
	// old clip means it is a mem upload for missed call info
	// new clip is for a live update
	// clip data is in datas (CmdParams)
	int i = 0;
	// to display the CLIP information, 
	// (we need a break here to allow threads to continue).
	TRACE("Processing CLIP information");
	DISPLAYABLECLIP dispclipTransResult;
	// when we receive the CLIP structure, only params are in m_CmdParams...
	TranslateCLIP((char *) (m_CmdParams), (m_CmdParams[1]), &dispclipTransResult);
	// Q. is this a live call or an old one ?
	// Q. is this clip incoming or outgoing ? A. Must be incoming
	dispclipTransResult.nClipState = nClipState;
	switch(nClipState) {
	case CS_INCOMING_CLIP_OLD:
		TRACE("\r\nIncoming CLIP Old\r\n");
		break;
	case CS_INCOMING_CLIP_NEW:
		TRACE("\r\nIncoming CLIP New\r\n");
		// Upload the data ?
		// GetMissedCallDetails();
		break;
	} // end switch
	
	HandleCallScapeEvent(CS_EV_GOTCLIP, (PBYTE) &dispclipTransResult, sizeof(DISPLAYABLECLIP));
	return CS_OK;
} // end of ProcessBPCM2

int CallScapeHW::ProcessQuery(PBOXINFO PbiQueryResult)
{
	int nReturnCode = CS_OK;
	// we have the results of the Query command
	char tmpMessage[30];
	TRACE("Processing Query Results\r\n");
	sprintf(tmpMessage, "%d incoming calls missed\r\n", PbiQueryResult->byICMNumbers);
	TRACE(tmpMessage);
//	m_RxBuffer->SetSel(-1,-1);
//	m_RxBuffer->ReplaceSel(tmpMessage, FALSE);
	sprintf(tmpMessage, "%d outgoing calls missed\r\n", PbiQueryResult->byOGMNumbers);
	TRACE(tmpMessage);
//	m_RxBuffer->SetSel(-1,-1);
//	m_RxBuffer->ReplaceSel(tmpMessage, FALSE);
	sprintf(tmpMessage, "%d calls lost\r\n", PbiQueryResult->byLostCallNumbers);
	TRACE(tmpMessage);
//	m_RxBuffer->SetSel(-1,-1);
//	m_RxBuffer->ReplaceSel(tmpMessage, FALSE);
    nReturnCode = CS_OK;
	// OK, so we know if there is any mem to upload...
	// inform app that they have missed n calls
	char cMissed[4];
	cMissed[0] = PbiQueryResult->byICMNumbers;
	cMissed[1] = PbiQueryResult->byOGMNumbers;
	cMissed[2] = PbiQueryResult->byLostCallNumbers;
	cMissed[3] = 0;
	nReturnCode = HandleCallScapeEvent(CS_EV_QUERYRESULT, (PBYTE) cMissed, 3);

	// now it is up to the app (Callscape handler) to request these details from us
	/*
	if (PbiQueryResult->byICMNumbers + PbiQueryResult->byOGMNumbers > 0) {
		// signal that we want to have this info
		TRACE("Issuing PBCM6 command\r\n");
		SendCommand(PBCM6, NULL, 0); // no params date
	}
	*/

	return nReturnCode;
} // end of ProcessQueryResults

int CallScapeHW::GetMissedCallDetails()
{
	TRACE("Issuing PBCM6 command\r\n");
	return SendCommand(PBCM6, NULL, 0); // no params date
} // end of GetMissedCallDetails

int CallScapeHW::TranslateCLIP( LPSTR lpCLIP, DWORD CLIPSize,
				  LPDISPLAYABLECLIP lpTransResult)
{
 int  RtnValue = CS_OK;
 char ParamType;
 UINT Type_POS=0;
 UINT Param_Count=0;
 UINT Param_Len;
 char tmp_Mon[3];
 char Month[4];
 char Day[3];
 char Hours[3];
 char Minutes[3];
 BYTE msgType;
 BYTE callType;
 UINT nDigitCnt = 0;
 int 	k;
 
 UINT i;
 
 LPSTR param;
 if ((lpCLIP == NULL) || (lpTransResult == NULL))
	return CS_ERR_INVALID; // avoid "user too stupid errors"
 //lpTransResult->Call_Type[0]=NULL;
 strcpy((LPSTR)lpTransResult->Call_Type,"Voice Call");                     
 lpTransResult->Time_Data[0]=NULL;
 lpTransResult->Caller_Number[0]=NULL;
 lpTransResult->No_DN_Reason[0]=NULL;
 lpTransResult->Called_Number[0]=NULL;
 lpTransResult->Name_Text[0]=NULL;
 lpTransResult->No_Name_Reason[0]=NULL;
 lpTransResult->Messages_Number[0]=NULL;  //initialize all fields to NULL(empty)
                            
 
 if((msgType=*lpCLIP)!=MSGTYPE_CLIP)
    {
    RtnValue=CLIPERR_MSGTYPE;   //message type error
	TRACE("NOT A CLIP MESSAGE\r\n");
    goto Return; // AARRGGHHH
    }
 // AARRGHH again needs fixing here - 
 /*
 the CLIP message can be part of a larger message, so CLIP size IS NOT the length
 of the message.
 <head> <data length> <data> <checksum>
 */
 
 //if(*(lpCLIP+1)!=(unsigned char)(CLIPSize-2))
  if((unsigned char)*(lpCLIP+1)!=(unsigned char)CLIPSize)
 //GCG mofdified on 8.3
 //Reason:PTP defines that the CLIPSize is the message length,not the
 //length of this data block.So CLIPSize must be equal to *(lpCLIP+1).
    {
    RtnValue=CLIPERR_MSGLEN;    //message length error  
    goto Return;
    }
 
 param=lpCLIP+2;

 while(Type_POS<(unsigned char) CLIPSize) // was *(lpCLIP+1))    //lpCLIP[1] is message length
     {
      ParamType=(unsigned char)*(param+Type_POS);
      Param_Len=(unsigned char)*(param+Type_POS+1);
      
      switch(ParamType) {
          case CALL_TYPE:
               if(Param_Count) 
                    {
                    RtnValue=CLIPERR_CTPOS;//if call type exits,it must be the first parameter
                    goto Return;
                    }
               
               if(Param_Len!=CT_PARAM_LEN)
                    {
                    RtnValue=CLIPERR_CTLEN;//parameter length error
                    goto Return;
                    }
               
               switch(callType=(unsigned char)*(param+Type_POS+2)) {
                     case CT_VOICECALL:  
                          strcpy((LPSTR)lpTransResult->Call_Type,"Voice Call");                         
                          break;
                     case CT_RBWF:
                          strcpy((LPSTR)lpTransResult->Call_Type,"ring-back-when-free call");
                          break;
                     case CT_MSG_WAIT:   
                          strcpy((LPSTR)lpTransResult->Call_Type,"message waiting Call");
                          break;
                     default:
                          if(callType>=128)  
                          	  {
                          	  // _fstrcpy((LPSTR)lpTransResult->Call_Type,"Unknown Call");
                          
                              //GCG modified on 9.5
                              //Reason:if call type is >=128 and not equal to 129,
                              //ignore the whole CLIP
                              RtnValue=CLIPERR_CTCT;//call type error
                              goto Return;
                              }
                          else
                               strcpy((LPSTR)lpTransResult->Call_Type,"Voice Call");
                          break;
                     } //switch Call type
               break;
          
          case TIME_DATE:
               if(Param_Len!=TD_PARAM_LEN)
                    {
                    RtnValue=CLIPERR_TDLEN;//parameter length error
                    goto Return;
                    }
               
               memcpy(tmp_Mon,(LPSTR)(param+Type_POS+2),2);
               tmp_Mon[2]=0;
               memcpy(Day,(LPSTR)(param+Type_POS+4),2);
               Day[2]=0;
               if(atoi(Day)>31||!atoi(Day)) 
                {
                 //MessageBox("Day error");
                 //return -1;
                 break;
                 }
               memcpy(Hours,(LPSTR)(param+Type_POS+6),2);
               Hours[2]=0;
               if(atoi(Hours)>24||!atoi(Hours))
                {
                 //MessageBox("Hours error");
                 // return -1;
                 break;
                 }
               memcpy(Minutes,(LPSTR)(param+Type_POS+8),2);
               Minutes[2]=0;             
               if(atoi(Minutes)>60||!atoi(Minutes)) 
               {
                //MessageBox("Minutes error");
                //return -1;
                break;
               }
               switch(atoi(tmp_Mon)) {
                     case 1:
                          strcpy((LPSTR)Month,"JAN");
                          break;
                     case 2:
                          strcpy((LPSTR)Month,"FEB");
                          break;
                     case 3:
                          strcpy((LPSTR)Month,"MAR");
                          break;
                     case 4:
                          strcpy((LPSTR)Month,"APR");
                          break;
                     case 5:
                          strcpy((LPSTR)Month,"MAY");
                          break;
                     case 6:
                          strcpy((LPSTR)Month,"JUN");
                          break;
                     case 7:
                          strcpy((LPSTR)Month,"JUL");
                          break;
                     case 8:
                          strcpy((LPSTR)Month,"AUG");
                          break;
                     case 9:
                          strcpy((LPSTR)Month,"SEP");
                          break;
                     case 10:
                          strcpy((LPSTR)Month,"OCT");
                          break;
                     case 11:
                          strcpy((LPSTR)Month,"NOV");
                          break;
                     case 12:
                          strcpy((LPSTR)Month,"DEC");
                          break;
                     default:
                          goto Break;;
                          break;               
                     }// switch month
                 sprintf((char far*)lpTransResult->Time_Data,"%s-%s %s-%s",(char far*)Hours,
                   (char far*)Minutes,(char far*)Day,(char far*)Month);
                   //modified on 5.6 AM. Reason: use sprintf instead of sprintf
    Break:     break; 
               
          case CALLING_LINE_DN:
               {
               UINT   nCopyLen;//length to copy number.GCG added on 9.5
                
               //if length is >18,we must only copy 18 characters
               //GCG modified by 9.20
               //Relatived by QA:NQ59C012
               if(Param_Len>CLDN_MAX_PARLEN)
                   nCopyLen=CLDN_MAX_PARLEN;
               else     
                   nCopyLen=Param_Len;
                   
               memcpy((LPSTR)lpTransResult->Caller_Number,(LPSTR)(param+Type_POS+2),nCopyLen);
               lpTransResult->Caller_Number[nCopyLen]=0;
               for( i=0; i<nCopyLen; i++ )
                   { 
                    if((lpTransResult->Caller_Number[i]>0x39 ||
                       lpTransResult->Caller_Number[i]<0x30  )  
                       &&
                       lpTransResult->Caller_Number[i]!='-'  &&//GCG added on 9.3
                       lpTransResult->Caller_Number[i]!=' '  &&//GCG added on 9.28
                       lpTransResult->Caller_Number[i]!='('  &&//GCG added on 9.28
                       lpTransResult->Caller_Number[i]!=')'    //GCG added on 9.28
                       )
                       {
                        //lpTransResult->Caller_Number[0]=NULL;
                        //break;
                       
                        //GCG modified the above statement as the follwoing on 10.7
                        //Reason:If a character of the caller number is not
                        //0~9 or '-',' ','(',')',change it as space ' '.
                        //Relatived bug found by QA:NQ59C025
                        lpTransResult->Caller_Number[i]=' ';
                       }
                   }
			   
			   //GCG add the codes here on 96.11.4 to slove BT problem: B96574
//		       if( NetOpt.ConType == FEATURELINE )
			   //{
				   //get the caller number from the class data
				   CString sNumber( lpTransResult->Caller_Number );
				   
				   //count the number of digits
				   for( k =0; k<sNumber.GetLength(); k++ )
				   {
				        if( isdigit( sNumber.GetAt(k) ) )
				  	 		nDigitCnt++;
				   }
				   
				   if( nDigitCnt > 6  && sNumber.GetAt(0) == '0' )
				   {   //the number had more than 6 digit and the first character
				       //is '0', so we must append a '9' at the number
				       sNumber = '9' + sNumber;
					   strcpy( lpTransResult->Caller_Number, sNumber.GetBuffer(50) );        
					   sNumber.ReleaseBuffer();       
                   }
               }
               
               
               //}
               
               
               break;
          
          case REASON_AB_DN:
               if(Param_Len!=RADN_PARAM_LEN)
                    {
                    RtnValue=CLIPERR_RADNLEN;//parameter length error
                    goto Return;
                    }
                    
               switch(*(param+Type_POS+2)){
                    case 'P':
                         strcpy((LPSTR)lpTransResult->No_DN_Reason,"Number Withheld");
                         break;
                    case 'O':
                         strcpy((LPSTR)lpTransResult->No_DN_Reason,"Number Unavailable");
                         break;
                    default:
                         strcpy((LPSTR)lpTransResult->No_DN_Reason,"Other RADN reason");     
                         break;
                    } //switch Reason for Absence of DN 
                    
               //copy no number reason to caller number field of this class clip
               //GCG 96.6.25 add to fill the number field with no number reason
               //when no number available.
               strcpy( (LPSTR)lpTransResult->Caller_Number,
                         (LPSTR)lpTransResult->No_DN_Reason );
                    
               break;
               
          case CALLED_DN:
               {
               UINT   nCopyLen;//length to copy number.GCG added on 9.5
               
               if(Param_Len>CDN_MAX_PARLEN)
                   nCopyLen=CDN_MAX_PARLEN;
               else
                   nCopyLen=Param_Len;    
                    
               memcpy((LPSTR)lpTransResult->Called_Number,(LPSTR)(param+Type_POS+2),nCopyLen);
               lpTransResult->Called_Number[nCopyLen]=0;
               for(i=0; i<nCopyLen; i++)
                   { 
                    if( (lpTransResult->Called_Number[i]>0x39 ||
                         lpTransResult->Called_Number[i]<0x30  )
                         &&
                         lpTransResult->Called_Number[i]!='-'  &&//GCG added on 9.3
                         lpTransResult->Called_Number[i]!=' '  &&//GCG added on 9.28
                         lpTransResult->Called_Number[i]!='('  &&//GCG added on 9.28
                         lpTransResult->Called_Number[i]!=')'    //GCG added on 9.28
                       )
                       
                       {
                       //lpTransResult->Called_Number[0]=0;
                       //break;
                       
                       //GCG modified the above statement as the follwoing on 10.7
                       //Reason:If a character of the caller number is not
                       //0~9 or '-',' ','(',')',change it as space ' '.
                       //Relatived bug found by QA:NQ59C025
                       lpTransResult->Called_Number[i]=' ';
                       }
                    }
               }
               break;
               
          case CALLER_NAME_TEXT:
               {
               UINT nCopyLen;//length to copy name_text
               
               if(Param_Len>CNT_MAX_PARLEN)
                   nCopyLen=CNT_MAX_PARLEN;
               else
                   nCopyLen=Param_Len;    
                    
               memcpy((LPSTR)lpTransResult->Name_Text,(LPSTR)(param+Type_POS+2),nCopyLen);     
               lpTransResult->Name_Text[nCopyLen]=0;
               }
               break;
               
          case REASON_AB_NAME:
               if(Param_Len!=RANAME_PARLEN)
                    {
                    RtnValue=CLIPERR_RANLEN;
                    goto Return;
                    }
                    
               switch(*(param+Type_POS+2)){
                    case 'P':
                         strcpy((LPSTR)lpTransResult->No_Name_Reason,"Name Withheld");
                         break;
                    case 'O':
                         strcpy((LPSTR)lpTransResult->No_Name_Reason,"Name Unavailable");
                         break;
                    default:
                         strcpy((LPSTR)lpTransResult->No_Name_Reason,"Other RAN reason");     
                         break;
                    }// switch Reason for Absence of Name 
               break;
                    
          case NET_MSG_SYS_STA :
               if(Param_Len!=NMSS_PARLEN)
                    {
                    RtnValue=CLIPERR_NMSSLEN;
                    goto Return;
                    }
                    
               switch((unsigned char)*(param+Type_POS+2)) {
                    case 0:
                         sprintf((char far*)lpTransResult->Messages_Number,"%s","No messages");
                         break;
                    case 1:                                                                
                         sprintf((char far*)lpTransResult->Messages_Number,"%s","One or unspecified messages");
                         break;                                                           
                    default:
                         sprintf((char far*)lpTransResult->Messages_Number,"%d %s",(unsigned char)*(param+Type_POS+2),"messages");
                         break;
                    }// switch messages numbers
               
               break;
          
          } //swich ParamType
      
      Type_POS+=Param_Len+2; //next parameter type position
      Param_Count++;
     } //while
 
 RtnValue=0;//success
 
Return:
 return RtnValue;   //successfuly return

} // end of TranslateCLIP
