#if !defined(AFX_STDAFX_H__E7CB9F06_9316_11D1_9709_00A024CB61CA__INCLUDED_)
#define AFX_STDAFX_H__E7CB9F06_9316_11D1_9709_00A024CB61CA__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// stdafx.h : include file for standard system include files,
//      or project specific include files that are used frequently,
//      but are changed infrequently

#define VC_EXTRALEAN            // Exclude rarely-used stuff from Windows headers

#include <afxctl.h>         // MFC support for ActiveX Controls

// Delete the two includes below if you do not wish to use the MFC
//  database classes
//#include <afxdb.h>                    // MFC database classes
//#include <afxdao.h>                   // MFC DAO database classes

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC OLE automation classes
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>                     // MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__E7CB9F06_9316_11D1_9709_00A024CB61CA__INCLUDED_)
