========================================================================
		ActiveX Control DLL : CS
========================================================================

ControlWizard has created this project for your CS ActiveX Control
DLL, which contains 1 control.

This skeleton project not only demonstrates the basics of writing an
ActiveX Control, but is also a starting point for writing the specific
features of your control.

This file contains a summary of what you will find in each of the files
that make up your CS ActiveX Control DLL.

cs.mak
	The Visual C++ project makefile for building your ActiveX Control.

cs.h
	This is the main include file for the ActiveX Control DLL.  It
	includes other project-specific includes such as resource.h.

cs.cpp
	This is the main source file that contains code for DLL initialization,
	termination and other bookkeeping.

cs.rc
	This is a listing of the Microsoft Windows resources that the project
	uses.  This file can be directly edited with the Visual C++ resource
	editor.

cs.def
	This file contains information about the ActiveX Control DLL that
	must be provided to run with Microsoft Windows.

cs.clw
	This file contains information used by ClassWizard to edit existing
	classes or add new classes.  ClassWizard also uses this file to store
	information needed to generate and edit message maps and dialog data
	maps and to generate prototype member functions.

cs.odl
	This file contains the Object Description Language source code for the
	type library of your control.

/////////////////////////////////////////////////////////////////////////////
Cs control:

CsCtl.h
	This file contains the declaration of the CCsCtrl C++ class.

CsCtl.cpp
	This file contains the implementation of the CCsCtrl C++ class.

CsPpg.h
	This file contains the declaration of the CCsPropPage C++ class.

CsPpg.cpp
	This file contains the implementation of the CCsPropPage C++ class.

CsCtl.bmp
	This file contains a bitmap that a container will use to represent the
	CCsCtrl control when it appears on a tool palette.  This bitmap
	is included by the main resource file cs.rc.

/////////////////////////////////////////////////////////////////////////////
Help Support:

MakeHelp.bat
	Use this batch file to create your ActiveX Control's Help file,
	cs.hlp.

cs.hpj
	This file is the Help Project file used by the Help compiler to create
	your ActiveX Control's Help file.

*.bmp
	These are bitmap files required by the standard Help file topics for
	Microsoft Foundation Class Library standard commands.  These files are
	located in the HLP subdirectory.

cs.rtf
	This file contains the standard help topics for the common properties,
	events and methods supported by many ActiveX Controls.  You can edit
	this to add or remove additional control specific topics.  This file is
	located in the HLP subdirectory.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

stdafx.h, stdafx.cpp
	These files are used to build a precompiled header (PCH) file
	named stdafx.pch and a precompiled types (PCT) file named stdafx.obj.

resource.h
	This is the standard header file, which defines new resource IDs.
	The Visual C++ resource editor reads and updates this file.

/////////////////////////////////////////////////////////////////////////////
Other notes:

ControlWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
