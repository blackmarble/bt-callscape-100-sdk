// CsCtl.cpp : Implementation of the CCsCtrl ActiveX Control class.

#include "stdafx.h"
#include "cs.h"
#include "CsCtl.h"
#include "CsPpg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CCsCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CCsCtrl, COleControl)
        //{{AFX_MSG_MAP(CCsCtrl)
	ON_MESSAGE(CS_WM_MESSAGE, OnCSMessage)
	ON_MESSAGE(CS_WM_ERROR, OnCSError)
	ON_MESSAGE(CS_WM_EVENT, OnCSEvent)
	//}}AFX_MSG_MAP
        ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CCsCtrl, COleControl)
        //{{AFX_DISPATCH_MAP(CCsCtrl)
        DISP_FUNCTION(CCsCtrl, "Hangup", Hangup, VT_I2, VTS_NONE)
        DISP_FUNCTION(CCsCtrl, "Dial", Dial, VT_I4, VTS_BSTR)
	DISP_FUNCTION(CCsCtrl, "Connect", Connect, VT_I2, VTS_BSTR)
	DISP_FUNCTION(CCsCtrl, "Disconnect", Disconnect, VT_I2, VTS_NONE)
	DISP_FUNCTION(CCsCtrl, "Status", Status, VT_I2, VTS_NONE)
	DISP_FUNCTION(CCsCtrl, "ComPort", ComPort, VT_BSTR, VTS_NONE)
	DISP_FUNCTION(CCsCtrl, "CallTime", CallTime, VT_BSTR, VTS_I2)
	DISP_FUNCTION(CCsCtrl, "PhoneNumber", PhoneNumber, VT_BSTR, VTS_I2)
	DISP_FUNCTION(CCsCtrl, "CallName", CallName, VT_BSTR, VTS_I2)
	DISP_FUNCTION(CCsCtrl, "CallNoName", CallNoName, VT_BSTR, VTS_I2)
	DISP_FUNCTION(CCsCtrl, "CallMessagesNumber", CallMessagesNumber, VT_BSTR, VTS_I2)
	DISP_FUNCTION(CCsCtrl, "GetMissedCalls", GetMissedCalls, VT_I2, VTS_NONE)
	DISP_FUNCTION(CCsCtrl, "MissedCalls", MissedCalls, VT_I2, VTS_NONE)
	DISP_FUNCTION(CCsCtrl, "MissedLost", MissedLost, VT_I2, VTS_NONE)
	DISP_FUNCTION(CCsCtrl, "MissedOutgoing", MissedOutgoing, VT_I2, VTS_NONE)
	DISP_FUNCTION(CCsCtrl, "MissedIncoming", MissedIncoming, VT_I2, VTS_NONE)
	DISP_FUNCTION(CCsCtrl, "IsBusy", IsBusy, VT_I2, VTS_NONE)
	DISP_STOCKPROP_BACKCOLOR()
	//}}AFX_DISPATCH_MAP
        DISP_FUNCTION_ID(CCsCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CCsCtrl, COleControl)
        //{{AFX_EVENT_MAP(CCsCtrl)
	EVENT_CUSTOM("PhoneNumberChanged", FirePhoneNumberChanged, VTS_BSTR)
	EVENT_CUSTOM("StatusChanged", FireStatusChanged, VTS_I2)
	EVENT_CUSTOM("DialedChar", FireDialedChar, VTS_BSTR)
	EVENT_CUSTOM("EventChanged", FireEventChanged, VTS_I2)
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CCsCtrl, 1)
        PROPPAGEID(CCsPropPage::guid)
END_PROPPAGEIDS(CCsCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CCsCtrl, "CS.CsCtrl.1",
        0xe7cb9f02, 0x9316, 0x11d1, 0x97, 0x9, 0, 0xa0, 0x24, 0xcb, 0x61, 0xca)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CCsCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DCs =
                { 0xe7cb9f00, 0x9316, 0x11d1, { 0x97, 0x9, 0, 0xa0, 0x24, 0xcb, 0x61, 0xca } };
const IID BASED_CODE IID_DCsEvents =
                { 0xe7cb9f01, 0x9316, 0x11d1, { 0x97, 0x9, 0, 0xa0, 0x24, 0xcb, 0x61, 0xca } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwCsOleMisc =
        OLEMISC_ACTIVATEWHENVISIBLE |
        OLEMISC_SETCLIENTSITEFIRST |
        OLEMISC_INSIDEOUT |
        OLEMISC_CANTLINKINSIDE |
        OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CCsCtrl, IDS_CS, _dwCsOleMisc)


/// OUR TIMER FUNCTION

// GLOBAL for watchdog timer
bool g_bWatchDogMatured; 	

void CALLBACK EXPORT WatchDogTimerProc(HWND hWnd, UINT nMsg, UINT nIDEvent, DWORD dwTime )
{
	g_bWatchDogMatured = true;
} 


/////////////////////////////////////////////////////////////////////////////
// CCsCtrl::CCsCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CCsCtrl

BOOL CCsCtrl::CCsCtrlFactory::UpdateRegistry(BOOL bRegister)
{
        // TODO: Verify that your control follows apartment-model threading rules.
        // Refer to MFC TechNote 64 for more information.
        // If your control does not conform to the apartment-model rules, then
        // you must modify the code below, changing the 6th parameter from
        // afxRegApartmentThreading to 0.

        if (bRegister)
                return AfxOleRegisterControlClass(
                        AfxGetInstanceHandle(),
                        m_clsid,
                        m_lpszProgID,
                        IDS_CS,
                        IDB_CS,
                        afxRegApartmentThreading,
                        _dwCsOleMisc,
                        _tlid,
                        _wVerMajor,
                        _wVerMinor);
        else
                return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CCsCtrl::CCsCtrl - Constructor

CCsCtrl::CCsCtrl()
{
        InitializeIIDs(&IID_DCs, &IID_DCsEvents);
		m_busy = CS_OCX_STATE_DISCONNECTED; // start here
		m_ForcedBusy = CS_OCX_STATE_IDLE; // programmer can set this
		m_CurrentState = CS_OCX_STATE_DISCONNECTED;
		m_uiWatchDogTimer = 0;
		g_bWatchDogMatured = false;
        m_iStatus=0;
		m_iEvent=0;
        m_sComPort="";
        m_sCallPhoneNumber[0]="";
		m_Callscape=NULL; // the callscape object
	    m_sCallType[0]="";
	    m_sCallTime[0]="";
	    m_sCallName[0]="";
	    m_sCallNoName[0]="";
	    m_sCallMessagesNumber[0]="";
		m_iCallDirection[0]=0;
        m_icalllistsize=0;
		m_iMissedOut=0;
		m_iMissedIn=0;
		m_iMissedLost=0;
		m_iTotalMissedCalls=-1;
		MessageBox("Evaluation only - not for release\r\nVersion 1.2b", "BT CallScape OCX control", MB_OK | MB_APPLMODAL);
}

int CCsCtrl::HandleCallScapeEvent(int nCallScapeEvent, PBYTE lpBuf, DWORD dwBufLen)
{
	
	TRACE("In CsCtl::HandleCSEvent\r\n");
	
	short oldstatus=m_iStatus;
	int index=0;
	m_iEvent=nCallScapeEvent;
	switch (nCallScapeEvent) {
	case CS_EV_ALT:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("ALT\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_CAS:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("CAS\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_LINEDISCONNECT:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Line Disconnect\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_PHONEOFFWITHINRING:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Phone Off Hook within ring\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_PHONEOFFWITHOUTRING:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
  		TRACE("Phone Off Hook without ring\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_PHONEONHOOK:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Phone On Hook\r\n");
		m_iStatus=0;
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_EXTENSIONPHONEOFF:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Extension Phone Off Hook\r\n");
		m_iStatus=1;
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_EXTENSIONPHONEON:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Extension Phone On Hook\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_BOXOFFFOLLOWINGRING:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("BOX off following ring\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_BOXOFFWITHOUTRING:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("BOX off Without ring\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_DIALTONE:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Dial Tone\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_RINGBACKTONE:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("RingBack Tone\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_BUSYTONE:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Busy Tone\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_NUTONE:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("NU Tone\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_PARKTONE:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Park Tone\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_SPECIALTONE:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Special Tone\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_ENDOFDIALLING:  
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
  		TRACE("End of Dialling\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_ENDOFRING:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("End of Incoming Ring\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_INCOMINGRING:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Incoming Ring\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_SPECIALRING:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Special Ring\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_CODEDRING:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Coded Ring\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_DISTINCTIVERING:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Distinctive Ring\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_REMOTECONNECTED:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Remote Connected\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_ENDOFTONE:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("End of Tone\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_DIALLING:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Dialing\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_BOXONHOOK:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Box On Hook\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_REMOTEDISCONNECTED:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("RemoteDisconnected\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_HOLD:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		TRACE("Hold\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_LINECONNECT:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
  		TRACE("Line Connect\r\n");
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_GOTCLIP:
		TRACE("Got clip information\r\n");
		m_iEvent=0;
		// displayable clip is in lpBuf
		DISPLAYABLECLIP dispclip;
		memcpy(&dispclip, lpBuf, sizeof(DISPLAYABLECLIP));
   	    if ( dispclip.nClipState==CS_INCOMING_CLIP_OLD || dispclip.nClipState==CS_OUTGOING_CLIP_OLD ) index=++m_icalllistsize;
		if ( index > MAX_CALLS ) {
			TRACE("Overflow in stored calls");
			return CS_OK;
		}
        if ( dispclip.nClipState==CS_INCOMING_CLIP_OLD || dispclip.nClipState==CS_INCOMING_CLIP_NEW ) {
		    m_iCallDirection[index]=1;
		} else {
			m_iCallDirection[index]=0;
		}
	    m_sCallType[index]=dispclip.Call_Type;
	    m_sCallTime[index]=dispclip.Time_Data;
	    m_sCallName[index]=dispclip.Name_Text;
	    m_sCallNoName[index]=dispclip.No_Name_Reason;
	    m_sCallMessagesNumber[index]=dispclip.Messages_Number;
		m_sCallPhoneNumber[index]=dispclip.Caller_Number;
		TRACE("CLIP Number received : >>>%s<<<\r\n", dispclip.Caller_Number);
		if ( index==0 ) FirePhoneNumberChanged(dispclip.Caller_Number);
		PostEvent(CS_OCX_EV_GOTCLIP);
        break;
	case CS_EV_DIALCHAR:
		PostEvent(CS_OCX_EV_HANDLINGMISCEVENT);
		m_iEvent=0;
        tmpstr[0]=lpBuf[0];		
		tmpstr[1]=0;
        FireDialedChar(tmpstr);
		PostEvent(CS_OCX_EV_DONEMISCEVENT);
		break;
	case CS_EV_QUERYRESULT:
		m_iEvent=0;
		m_iMissedIn=lpBuf[0];
		m_iMissedOut=lpBuf[1];
		m_iMissedLost=lpBuf[2];
		m_iTotalMissedCalls=m_iMissedIn+m_iMissedOut;
		TRACE("Missed Calls : %d in, %d out, %d lost\r\n",m_iMissedIn, m_iMissedOut, m_iMissedLost);
		PostEvent(CS_OCX_EV_GOTQUERYRESULT);
		break;
	default:
		TRACE("Unrecognised event\r\n");
	} // end of switch
	if ( oldstatus!=m_iStatus) {
       FireStatusChanged(m_iStatus);
	}
	if ( m_iEvent!=0 ) FireEventChanged(m_iEvent);
	return CS_OK;
}

int CCsCtrl:: HandleCallScapeError(PCHAR szMessage){
//	TRACE("In Coms32Dlg::HandleCSError\r\n");
	// MESSAGEBOX ??
	return CS_OK;
}

int CCsCtrl:: HandleCallScapeMessage(PCHAR szMessage){
//	TRACE("In Coms32Dlg::HandleCSMessage\r\n");
	return CS_OK;
}
	

/////////////////////////////////////////////////////////////////////////////
// CCsCtrl::~CCsCtrl - Destructor

CCsCtrl::~CCsCtrl()
{
	    if ( m_Callscape!=NULL ) Disconnect();
}


/////////////////////////////////////////////////////////////////////////////
// CCsCtrl::OnDraw - Drawing function

void CCsCtrl::OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
        HICON hicon=NULL;
        if ( m_iStatus==0 ) {
         hicon = AfxGetApp()->LoadIcon(IDI_ONHOOK);
        } else {
         hicon = AfxGetApp()->LoadIcon(IDI_OFFHOOK);
        }
        CBrush cbBack(TranslateColor(GetBackColor()));
        pdc->FillRect(rcBounds, &cbBack);
        pdc->DrawIcon(rcBounds.TopLeft(),hicon);
}


/////////////////////////////////////////////////////////////////////////////
// CCsCtrl::DoPropExchange - Persistence support

void CCsCtrl::DoPropExchange(CPropExchange* pPX)
{
        ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
        COleControl::DoPropExchange(pPX);
}


/////////////////////////////////////////////////////////////////////////////
// CCsCtrl::OnResetState - Reset control to default state

void CCsCtrl::OnResetState()
{
        COleControl::OnResetState();  // Resets defaults found in DoPropExchange
}


/////////////////////////////////////////////////////////////////////////////
// CCsCtrl::AboutBox - Display an "About" box to the user

void CCsCtrl::AboutBox()
{
        CDialog dlgAbout(IDD_ABOUTBOX_CS);
        dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CCsCtrl message handlers

//
// CCsCtrl::Hangup
//
//
short CCsCtrl::Hangup()
{
        TRACE("Hangup\r\n");
        if ( m_Callscape == NULL ) return 1;
	    m_Callscape->Hangup(); 
        m_iStatus=0;
		m_sCallPhoneNumber[0]="";
		InvalidateControl(NULL);
		SetModifiedFlag();
        return 0;
} // CCsCtrl::Hangup

//
// CCsCtrl::Dial
//
// Dials the PhoneNumber
//
long CCsCtrl::Dial(LPCTSTR pno)
{
        TRACE("Dial\r\n");
		if (IsBusy()) return m_busy;
		if ( m_Callscape == NULL ) return 1;
        m_iStatus=1;
		strcpy(tmpstr,pno);
		m_sCallPhoneNumber[0]=pno;
        m_Callscape->Dial(tmpstr);
        InvalidateControl(NULL);
		SetModifiedFlag();
        return 0;
} // CCsCtrl::Dial

//
// CCsCtrl::Connect
//
// Connects the Callscape
//
short CCsCtrl::Connect(LPCTSTR port) 
{
	int trys=100;
	
	m_ForcedBusy = CS_OCX_STATE_BUSY;	
	if (PostEvent(CS_OCX_EV_CONNECTING)) {
		return CS_OCX_ERR_INVALIDSTATE;
	} // endif SetState

	if ( m_Callscape!=NULL ) Disconnect();

	m_Callscape = new CallScapeHW(this); // should be a pointer to a CallScapeHandler
	PostEvent (CS_OCX_EV_CONNECTED);
	PostEvent (CS_OCX_EV_QUERYBOX);
	
	m_sComPort=port;
	strcpy(tmpstr,port);
    m_Callscape->SetComPort(tmpstr);
	m_Callscape->Connect();
	int nRetry = 100;
	int iRetCode;
	while ( ((iRetCode = m_Callscape->QueryBox()) != CS_OK) && nRetry--) {
	  Sleep(0);
	}
	if (nRetry == 0)
		TRACE("Timeout - Callscape is BUSY\r\n");
	while ( m_iTotalMissedCalls == -1  && trys!=0) { 
		Sleep(0);
		trys--; 
	}
	if (iRetCode != CS_OK)
		return CS_OCX_STATE_ERROR; // an error condition
	m_ForcedBusy = CS_OCX_STATE_IDLE;
	return 0;
} // CCsCtrl::Connect


//
// CCsCtrl::Disconnect
//
// disconnects the Callscape
//
short CCsCtrl::Disconnect() 
{
	TRACE("CCsCtrl::Disconnect()\r\n");
	if (m_busy == CS_STATE_BUSY) return m_busy; // cannot disconnect yet
	PostEvent(CS_OCX_EV_DISCONNECTING);
	m_Callscape->Shutdown();
	TRACE("CCsCtrl::delete m_Callscape\r\n");
	delete m_Callscape;
    m_Callscape=NULL;	
	m_iStatus=-1;
	PostEvent(CS_OCX_EV_DISCONNECTED);
	return 0;
} // CCsCtrl::Disconnect

//
// CCsCtrl::Status
//
// returns the current status
//
short CCsCtrl::Status() 
{
	return m_iStatus;
} // CCsCtrl::Status

//
// CCsCtrl::ComPort
//
// returns the name of the comport
//
BSTR CCsCtrl::ComPort() 
{
	if (IsBusy()) {
		CString strResult;
		return strResult.AllocSysString(); 
	}
    return m_sComPort.AllocSysString();
} // CCsCtrl::ComPort


BSTR CCsCtrl::CallTime(short callnumber) 
{
	if ( callnumber < 0 || callnumber > m_icalllistsize || IsBusy() ){
		CString strResult;
		return strResult.AllocSysString(); 
	}
	return m_sCallTime[callnumber].AllocSysString();

}

BSTR CCsCtrl::PhoneNumber(short callnumber) 
{
	if ( callnumber < 0 || callnumber > m_icalllistsize || IsBusy() ) {
		CString strResult;
		return strResult.AllocSysString(); 
	}
	return m_sCallPhoneNumber[callnumber].AllocSysString();

}

BSTR CCsCtrl::CallName(short callnumber) 
{
	if ( callnumber < 0 || callnumber > m_icalllistsize || IsBusy() ) {
		CString strResult;
		return strResult.AllocSysString(); 
	}
	return m_sCallName[callnumber].AllocSysString();

}

BSTR CCsCtrl::CallNoName(short callnumber) 
{
	if ( callnumber < 0 || callnumber > m_icalllistsize || IsBusy() ) {
		CString strResult;
		return strResult.AllocSysString(); 
	}
	return m_sCallNoName[callnumber].AllocSysString();
}

BSTR CCsCtrl::CallMessagesNumber(short callnumber) 
{
	if ( callnumber < 0 || callnumber > m_icalllistsize || IsBusy() ) {
		CString strResult;
		return strResult.AllocSysString(); 
	}
	return m_sCallMessagesNumber[callnumber].AllocSysString();
}

short CCsCtrl::GetMissedCalls() 
{
  short iCounter;
  short trys=100;
  if (IsBusy()) return m_busy;
  if ((m_iMissedIn==0 ) && (  m_iMissedOut==0 ) ) { 
	  TRACE("no missed calls"); 
	  return 1; 
  } 
  iCounter=m_iMissedIn+m_iMissedOut;
  if (iCounter==m_icalllistsize )  { 
	  TRACE("iCounter = m_icalllistsize"); 
	  return 2; 
  } 

  // need to stay busy from here...
  m_ForcedBusy = CS_OCX_STATE_BUSY;
  if (StartWatchDogTimer() == 0) {
	  TRACE("Cannot Start Watchdog timer\r\n");
	  return CS_ERR_BADTIMER;
  }
  for ( int index=1; index <= iCounter ; index++) {
        PostEvent(CS_OCX_EV_GETCLIP);
	  	m_sCallType[index]="";
	    m_sCallTime[index]="";
	    m_sCallName[index]="";
	    m_sCallNoName[index]="";
	    m_sCallMessagesNumber[index]="";
		m_sCallPhoneNumber[index]="";
		TRACE("Calling GetMissedCallDetails\r\n");
		// need retries here
		while ((!g_bWatchDogMatured) && (m_Callscape->GetMissedCallDetails())) {
				Sleep(0);
			}  // end while

		// this will generate an event, and we will be called back
		// with the CLIP information
		trys=100;
		while ( trys > 0 && m_icalllistsize < index ) { 
			Sleep(0); 
			trys--;
		} //  end while
  }
  // ....to here
  m_ForcedBusy = CS_OCX_STATE_IDLE;

  if (StopWatchDogTimer()==0)
	  return CS_ERR_BADTIMER;
  return 0;
}

short CCsCtrl::MissedCalls() 
{
	if (IsBusy()) return m_busy;
	TRACE("MissedCalls called\r\n");
	return m_iTotalMissedCalls;
}

short CCsCtrl::MissedLost() 
{
	if (IsBusy()) return m_busy;
	return m_iMissedLost;
}

short CCsCtrl::MissedOutgoing() 
{
	if (IsBusy()) return m_busy;
	return m_iMissedOut;
}

short CCsCtrl::MissedIncoming() 
{
	if (IsBusy()) return m_busy;
	return m_iMissedIn;
}


LRESULT CCsCtrl::OnCSMessage(WPARAM wParam, LPARAM lParam)
{
	PCS_MESSAGE_STRUCT pms;
	pms = (PCS_MESSAGE_STRUCT) wParam;
	if (wParam == NULL) {
		return CS_ERR_INVALID;
	}
	PostEvent(CS_OCX_EV_HANDLINGMESSAGE);
	HandleCallScapeMessage((char *) wParam);
	PostEvent(CS_OCX_EV_DONEMESSAGE);
	TRACE("Freeing %lx",pms->psData);
	TRACE("Freeing %lx",pms);
	
	free ((void *) pms->psData); // free the message data buffer
	free ((void *) pms); // free the message struct itself
	return 0;
}
LRESULT CCsCtrl::OnCSError(WPARAM wParam, LPARAM lParam)
{
	PCS_MESSAGE_STRUCT pms;
	pms = (PCS_MESSAGE_STRUCT) wParam;
	if (wParam == NULL) {
		return CS_ERR_INVALID;
	}
	PostEvent(CS_OCX_EV_HANDLINGERROR);
	HandleCallScapeError((char *) wParam);
	PostEvent(CS_OCX_EV_DONEERROR);
	TRACE("Freeing %lx\r\n",pms->psData);
	TRACE("Freeing %lx\r\n",pms);
	free ((void *) pms->psData); // free the message data buffer
	free ((void *) pms); // free the message struct itself
	return 0;
}
LRESULT CCsCtrl::OnCSEvent(WPARAM wParam, LPARAM lParam)
{
	// the first byte in wParam is the event, the rest is data
	// lParam will be the length of data only, i.e. sizeof(WParam) -1 ( the event byte )
    int iEvent = 0;
	DWORD dwLen = 0;
	char * pDataBuf;
	PCS_MESSAGE_STRUCT pMessageStruct;
	pMessageStruct = (PCS_MESSAGE_STRUCT) wParam;
	
	// quick test
	if (pMessageStruct == NULL) {
		return CS_ERR_INVALID;
	}
	dwLen = (DWORD) lParam;
	iEvent = pMessageStruct->iEvent;
	pDataBuf = pMessageStruct->psData;
	HandleCallScapeEvent(iEvent, (PBYTE) pDataBuf, dwLen);
	TRACE("OnCSEvent");
	// free the memory
	TRACE("Wparam = %lx", wParam);
	TRACE("Freeing %lx\r\n",pMessageStruct->psData);
	TRACE("Freeing %lx\r\n",pMessageStruct);
	free ((void *) pMessageStruct->psData); // free the message data buffer
	free ((void *) pMessageStruct); // free the message struct itself
	TRACE("Done");
	return 0;
}

short CCsCtrl::IsBusy() 
{
	return m_busy || m_ForcedBusy; // ForcedBusy is where software can override
}

void CCsCtrl::SetBusy(short newstate) {
	// never change from error state...
	if (m_busy == CS_OCX_STATE_ERROR)
		return;
	if (newstate == CS_OCX_STATE_ERROR)
		TRACE("\r\n**ERROR state**\r\n");
	m_busy = newstate;

}
short CCsCtrl::PostEvent(short Event) {
	// our simple state machine...needed because message posting is an issue here...
	// return a fail if we cannot do what is expected.
	TRACE("PostEvent ");
	TranslateEvent(Event);
	TRACE("in State");
	TranslateState(m_CurrentState);
	TRACE("\r\n");
	// regardless of current state - check for errors
	if (Event == CS_OCX_EV_HANDLINGERROR) {
			m_CurrentState = CS_OCX_STATE_HANDLINGERROR;
			SetBusy(CS_OCX_STATE_ERROR);
			return CS_OCX_ERR_OK; // even though it's an error condition we are OK
	} // endif 
	switch (m_CurrentState) {

    case CS_OCX_STATE_HANDLINGERROR:
		// nothing allowed
		if (Event == CS_OCX_EV_DONEERROR) {
			SetBusy(CS_OCX_STATE_ERROR);
		} else { 
			TRACE("Ignoring event during error processing\r\n");
			return CS_OCX_ERR_INVALIDSTATE;
		} // endif
		break;
	case CS_OCX_STATE_DISCONNECTED:
		// from here we can only go to INITIALIZING
		TRACE("Currently Disconnected");
		if (Event == CS_OCX_EV_CONNECTING) {
			m_CurrentState = CS_OCX_STATE_INITIALIZING;
			TRACE("CurrentState now Initializing");
			break;
		} 
		return CS_OCX_ERR_INVALIDSTATE;
		break;

	case CS_OCX_STATE_INITIALIZING:
		// from here we can only go to idle

		switch (Event) {
		case CS_OCX_EV_CONNECTED :
			m_CurrentState = CS_OCX_STATE_IDLE;
			SetBusy(CS_OCX_STATE_IDLE) ; // tell the VB programmer we're idle
			return CS_OCX_ERR_OK;
			break;
		} // end switch

		return CS_OCX_ERR_INVALIDSTATE;
		break;

	case CS_OCX_STATE_IDLE:
		// can expect a few events in here
		switch (Event) {

		case CS_OCX_EV_QUERYBOX:
			m_CurrentState = CS_OCX_STATE_EXPECTQUERYRESULT;
			SetBusy(CS_OCX_STATE_BUSY);
			break;

		case CS_OCX_EV_GETCLIP:
			m_CurrentState = CS_OCX_STATE_EXPECTCLIP;
			SetBusy(CS_OCX_STATE_BUSY);
			break;

		case CS_OCX_EV_DISCONNECTING:
			m_CurrentState = CS_OCX_STATE_DISCONNECTING;
			SetBusy(CS_OCX_STATE_BUSY);
			break;

		
		case CS_OCX_EV_HANDLINGMESSAGE:
			m_CurrentState = CS_OCX_STATE_HANDLINGMESSAGE;
			break;

		case CS_OCX_EV_HANDLINGMISCEVENT:
			m_CurrentState = CS_OCX_STATE_HANDLINGMISCEVENT;
			break;

		default : // 
			TRACE("unexpected message ?");
			m_CurrentState = CS_OCX_STATE_IDLE;
			SetBusy(CS_OCX_STATE_IDLE);
		} // end switch 

		break;

	case CS_OCX_STATE_EXPECTQUERYRESULT:
		if (Event == CS_OCX_EV_GOTQUERYRESULT) {
			m_CurrentState = CS_OCX_STATE_IDLE;
			SetBusy(CS_OCX_STATE_IDLE);
		}
		break;

	case CS_OCX_STATE_EXPECTCLIP:
		if (Event == CS_OCX_EV_GOTCLIP) {
			// shouldn't go back to idle here...
			m_CurrentState = CS_OCX_STATE_IDLE;
			SetBusy(CS_OCX_STATE_IDLE);
		}
		break;

	case CS_OCX_STATE_DISCONNECTING:
		if (Event = CS_OCX_EV_DISCONNECTED) {
			m_CurrentState = CS_OCX_STATE_DISCONNECTED;
		    SetBusy(CS_OCX_STATE_DISCONNECTED); //
		} else {
			return CS_OCX_ERR_INVALIDSTATE;
		}
		break;

	case CS_OCX_STATE_HANDLINGMESSAGE:
		if (Event==CS_OCX_EV_DONEMESSAGE) {
			m_CurrentState = CS_OCX_STATE_IDLE;
		    SetBusy(CS_OCX_STATE_IDLE);
		}
		break;

	case CS_OCX_STATE_HANDLINGMISCEVENT:
		if (Event==CS_OCX_EV_DONEMISCEVENT) {
			m_CurrentState = CS_OCX_STATE_IDLE;
		    SetBusy(CS_OCX_STATE_IDLE);
		}
		break;
	default : 
		TRACE("BIG ERROR - UNKNOWN STATE - Going Back To Idle..\r\n");
		m_CurrentState = CS_OCX_STATE_IDLE;
		SetBusy(CS_OCX_STATE_IDLE) ;
	} // end switch on current state
	TRACE(" Now in State ");
	TranslateState(m_CurrentState);
	TRACE("\r\n");
	return CS_OCX_ERR_OK;
}

void CCsCtrl::TranslateState(short state) 
{
	switch (state) {
	case CS_OCX_STATE_IDLE :
		TRACE("STATE_IDLE");
		break;
	case CS_OCX_STATE_DISCONNECTED :
		TRACE("STATE_DISCONNECTED");
		break;
	case CS_OCX_STATE_DISCONNECTING	:
		TRACE("STATE_DISCONNECTING");
		break;
	case CS_OCX_STATE_INITIALIZING :
		TRACE("STATE_INITIALIZING");
		break;
	case CS_OCX_STATE_EXPECTQUERYRESULT	:
		TRACE("STATE_EXPECTQUERYRESULT");
		break;
	case CS_OCX_STATE_EXPECTCLIP :
		TRACE("STATE_EXPECTCLIP");
		break;
	case CS_OCX_STATE_BUSY :
		TRACE("STATE_BUSY");
		break;
	case CS_OCX_STATE_HANDLINGERROR			:
		TRACE("STATE_HANDLINGERROR");
		break;
	case CS_OCX_STATE_HANDLINGMESSAGE		:
		TRACE("STATE_HANDLINGMESSAGE");
		break;
	case CS_OCX_STATE_HANDLINGMISCEVENT		:
		TRACE("STATE_HANDLINGMISCEVENT");
		break;
	} // end switch

} // end of TranslateState

void CCsCtrl::TranslateEvent (short event)
{
	switch (event) {
// ....and the following events		
	case CS_OCX_EV_CONNECTING				:
		TRACE("EV_CONNECTING");
		break;
	case CS_OCX_EV_CONNECTED					:
		TRACE("EV_CONNECTED");
		break;
	case CS_OCX_EV_QUERYBOX					:
		TRACE("EV_QUERYBOX");
		break;
	case CS_OCX_EV_GOTQUERYRESULT			:
		TRACE("EV_GOTQUERYRESULT");
		break;
	case CS_OCX_EV_GETCLIP					:
		TRACE("EV_GETCLIP");
		break;
	case CS_OCX_EV_GOTCLIP					:
		TRACE("EV_GOTCLIP");
		break;
	case CS_OCX_EV_DISCONNECTING				:
		TRACE("EV_DISCONNECTING");
		break;
	case CS_OCX_EV_DISCONNECTED				:
		TRACE("EV_DISCONNECTED");
		break;
	case CS_OCX_EV_HANDLINGMESSAGE			:
		TRACE("EV_HANDLINGMESSAGE");
		break;
	case CS_OCX_EV_DONEMESSAGE				:
		TRACE("EV_DONEMESSAGE");
		break;
	case CS_OCX_EV_HANDLINGERROR 			:
		TRACE("EV_HANDLINGERROR");
		break;
	case CS_OCX_EV_DONEERROR					:
		TRACE("EV_DONEERROR");
		break;
	case CS_OCX_EV_HANDLINGMISCEVENT			:
		TRACE("EV_HANDLINGMISCEVENT");
		break;
	case CS_OCX_EV_DONEMISCEVENT				:
		TRACE("EV_DONEMISCEVENT");
		break;


	} // end event
} // end of TranslateEvent

short CCsCtrl::StartWatchDogTimer()
{
	TRACE("Starting WATCHDOG!\r\n");
    // if there is one running reset it
	if (m_uiWatchDogTimer != 0) {
	    StopWatchDogTimer();
	} 

	g_bWatchDogMatured = false;
	m_uiWatchDogTimer = ::SetTimer(  NULL, 0,  CS_WATCHDOG_TIMEOUT_VAL, WatchDogTimerProc);
	return m_uiWatchDogTimer;
} // end of StartWatchDog

short CCsCtrl::StopWatchDogTimer()
{
	TRACE("Stopping WATCHDOG!\r\n");
    if (m_uiWatchDogTimer == 0)
		return 0; // indicate success
	g_bWatchDogMatured = false;
	return ::KillTimer(NULL, m_uiWatchDogTimer);
} // end of StopWatchDog

