/*
 * Project:				PC Screen Phone	          	
 * Module:           	TSPI Test Module   
 * Program Name:        C O M C M D . H
 * Version:             1.0
 * Document No.
 * Module No.
 * Purpose:          	Communication command agreement between PC and BOX.
 * Author:              Pan Yong, Apr 4, 1995
 * Language:            Microsoft Visual C++ 1.5
 * Related Flowchart:	
 *						GetData.AF2	 ---- Illustrates requirement for getting
 *											each byte from serial port.
 *						BoxCmd.AF2 	 ---- Procedure for BOX command PC and
 *											BOX responses for PC command.
 *						PCCmd.AF2    ---- Procedure for PC command BOX and
 *											PC responses for BOX command.
 *						MemTran.AF2  ---- Procedure for transmission of memory
 *											datas between BOX and PC.
 *						DataTran.AF2 ---- Procedure for transmission of ADSI/
 *											CLASS datas between BOX and PC.
 * Related Resorce:     
 * Compile/Link:        
 * Memory Mode:         
 * Revise Record:       June 10, 1995 Updated for TSPI usage.
 * Copyright:           Copyright 1995 Inventec Electronics(NanJing) Co. Ltd.
 *                      All rights reserved.
 */     
#ifndef _INC_COMCMD
#define _INC_COMCMD 
                
                
// -------------------
// 1.)	Command types:
// -------------------
// We have two types of command format:
//	1. One byte command start with ESC.  
//		ESC <Command byte>
//	2. Muti-byte command with format like: 
//		ESC2 <Length> <Command byte> <Parameters> <Checksum>
//		*	The data length is total number of data in bytes which do not
//			include <ESC2> and <Data Length byte> and <Checksum>.
// 		*	The <Checksum> is total sum value of the send data being inversed
//			and then plus one. 
// We also have two types of acknowledgments:
// 	1. One byte acknowledgment as:
//		ACK, NAK
//	2. Muti-byte acknowledgment with format like:
//		ACK2 <Length> <Parameters> <Checksum>
//		*	The data length is total number of data in bytes which do not
//			include <ACK2> and <Data Length byte> and <Checksum>.
// 		*	The <Checksum> is total sum value of the send data being inversed
//			and then plus one. 
                                
                                
// -----------------------------------
// 2.)	General hand shaking sequence:
// -----------------------------------
// The correspondent between PC and BOX is as following:
//  1.  PC command to BOX. --> See "PCCmd.AF2"
//			Command
//		PC ---------> BOX
//			  ACK	
//		PC <--------- BOX     
//
//  2.  BOX event or request to PC. --> See "BoxCmd.AF2"
//		     Command
//		PC <--------- BOX
//			  ACK                      
//		PC ---------> BOX          
//
//	3. 	BOX Send ADSI data to PC. --> See "DataTran.AF2"
//           Command
//		PC <--------- BOX 
//			   ACK
//		PC ---------> BOX 
//		     1 block        
//		PC <--------- BOX     
//			   ACK             
//		PC ---------> BOX  	    
//							   
//		if( not end of data ) then send another data block. 
//
//	4. 	BOX Send CLASS to PC. --> See "DataTran.AF2"
//           Command
//		PC <--------- BOX 
//			  ACK
//		PC ---------> BOX 
//		      DATA        
//		PC <--------- BOX 
//			  ACK
//		PC ---------> BOX 
//
//	5. 	PC upload BOX memory. --> See "MemTran.AF2"
//           Command
//		PC ---------> BOX 
//		      DATA        
//		PC <--------- BOX 
//


// -----------------------------
// 3.)	Standard acknowledgment:
// -----------------------------
#define ACK		0x06	// "Yes" answer to queries or "ready for next
						// transmission". ( And the block followed will use
						// checksum verify method )  
#define ACK2	0x14	// Another "Yes" answer to queries followed by bytes
						// of variable length. 
#define ACK3	0x10	// "Yes" answer to queries or "ready for next
						// transmission" for CLASS CLIP data. ( The block 
						// followed will use CRC verify method for ADSI 
						// data block )
#define NAK		0x15	// "No" answer to queries or "errors found,
						// retransmit".
#define ESC		0x1b	// Marks beginning of an Escape control sequence
						// followed by a single byte of command.
#define ESC2	0x12	// Marks beginning of an Escape control sequence
						// followed by a command of multi-bytes.
#define ESC3	0x05	// Marks beginning of an Escape control sequence
						// followed by a command of multi-bytes. ESC3 also
						// means that the followed command data block is
						// simply the previously sent command data block
						// retry.


// -----------------
// 4.) 	DCD command:
// -----------------
// DCD command is signaled only when there is a large amout of datas in
// transmission.
#define DCD0    0xf0    // Cancel transmission. (Used only in "memory upload")
#define DCD1    0xf1    // CAS tone detected. (Used only in "Send ADSI")
#define DCD2 	0xf2 	// Extension phone on hook.
#define DCD3 	0xf3	// Extension phone off hook.
#define DCD4	0xf4	// Line disconnect.
#define DCD5	0xf5	// Park tone.
#define DCD6 	0xf6	// Time out.
										
										
// ------------------------                                                       
// 5.)	Command definition:
// ------------------------                                                        

// AT command from PC to Box.       
#define ATD 	0x90 	// Modem AT D (Dial) command. Followed by a string of
						// ASCII code valid as following:
						// 	"T", "0-9", "A-D", "#", "*", "P", ",", "!","W". 
						// Then PC should send data using format as following:
						//		<ESC2> <Data Length> <ATD> <Datas> <Checksum>
						// On receiving this block of data sent by PC, the 
						// BOX should response with ACK.
#define ATH0	0x91 	// Line off. 
						// Expected response: ACK, NAK.
#define ATH1	0x92 	// Line on.
						// Expected response: ACK, NAK.
#define ATM0	0x93 	// Mute the monitor.
						// Expected response: ACK, NAK.
#define ATM1 	0x94 	// Unmute the monitor.
						// Expected response: ACK, NAK.
#define ATL1	0x95 	// Low speaker volumn
						// Expected response: ACK, NAK.
#define ATL2	0x96 	// Medium speaker volumn.
						// Expected response: ACK, NAK.
#define ATL3	0x97 	// High speaker volumn.
						// Expected response: ACK, NAK.										
#define ATZ		0x98	// Self test.
						// The response of BOX using following formats:
						// 		<ACK2> 0x02 <word> <checksum> 
						//		Status word :
						//			bit 0 :	External RAM error.
						//      	bit 1 : UART error.
						//      	bit 2 :	Internal RAM error.
						//      	bit 3 : V23 modem error.
						//      	bit 4 : Line CTL CKT. 
						//      	bit 5 : CAS Detector.
						//      	bit 6 : Line reverse detector.
						//      	bit 7 : CPT detector.
						//			bit 8 : X
						//			bit 9 : X
						//			bit a : X
						//			bit b : X
						//			bit c : X
						//			bit d : X
						//			bit e : X
						//			bit f : X
struct tagBOXTest       
{	
	unsigned errExternalRAM	: 1 ;		// bit 0
	unsigned errUART 		: 1 ;       // bit 1
	unsigned errInternalRAM	: 1 ;       // bit 2
	unsigned errV23Modem	: 1 ;       // bit 3
	unsigned errLineCTLCKT	: 1 ;       // bit 4
	unsigned errCASDetector	: 1 ;       // bit 5
	unsigned errLineRevDet 	: 1 ;       // bit 6
	unsigned errCPTDetector	: 1 ;       // bit 7
	
	unsigned				: 1 ;     	// bit 8
	unsigned				: 1 ;      	// bit 9
	unsigned				: 1 ;       // bit a
	unsigned				: 1 ;       // bit b
	unsigned				: 1 ;       // bit c
	unsigned				: 1 ;       // bit d
	unsigned				: 1 ;       // bit e
	unsigned				: 1 ;       // bit f
} ;
typedef struct tagBOXTest BOXTEST ;
#define ATT		0x99	// Using tone dialing.
						// Expected response: ACK, NAK.
#define ATP		0x9a	// Using pulse dialing.
						// Expected response: ACK, NAK.
#define ATRC	0x9b	// Recall command.
						// Expected response: ACK, NAK.
#define ATCM	0x9c	// Pause command.
						// Expected response: ACK, NAK. 
										
// Exchange command from PC to Box
#define PBEX    0xa0    // Query the status of BOX.
#define PBEX2   0xa1    // NOTE: The difference between "PBEX" and "PBEX2"
                        //       is that the command "PBEX2" has chance for
                        //       retry just like those of normal command
                        //       while "PBEX" is for internal use only and
                        //       has no chance for retry at all.
                 		// PC should send data using format as following:
						//		<ESC2> 0x09 <PBEX> <Datas> <Checksum>
						// The data format is as following:
						//		Version dword:	XXXX (TAPI/TSPI compatible) 
						//						(e.g. 0x00010003 = Ver 1.03) 
						//		Hour byte:		X		
						//		Minute byte:    X
						//		Month byte:     X
						//		Day byte:       X   
						// BOX should send data using format as following:
                        //      <ACK2> 0x0b <Datas> <Checksum>
						// The data format is as following:
						//		Version dword:	
						//			XXXX ( TSPI/TAPI compatible ) 
						//			( e.g. 0x00010003 = Ver 1.03 ) 
						//		Status dword:    
						//			bit 0 	: Associated phone on/off hook.	
						//          bit 1 	: Extension phone on/off hook.                      
						//			bit 2 	: Line status. (on/off)
						//			bit 3 	: Power failure occurred.
						//			bit 4 	: Line disconnected from box.
						//			bit 5 	: Remote connected. (on/off)
						//			bit 6 	: Monitor muted. (Muted/Unmuted)
						//			bit 7 	: Monitor volumn. ( High/Low)  
						//			bit 8 	: Dial tone. (on/off)
						//			bit 9 	: Ring back tone. (on/off)
						//			bit a 	: Busy tone. (on/off)
						//			bit b	: NU tone. (on/off)
						//			bit c	: Park tone. (on/off) 						
						//			bit d	: Special dial tone. (on/off)
						//			bit e	: Normal incoming ring. (on/off)
						//			bit f	: Speicial ring. (RBWF) (on/off)
						//			bit 10	: Coded ring. (on/off)
						//			bit 11	: Distinective ring. (on/off)
						//			bit 12 	: Dialing. (on/off)
						//			bit 13 	: X   
						//			bit 14 	: X
						//			bit 15 	: X
						//			bit 16 	: X
						//			bit 17 	: X
						//			bit 18 	: X
						//			bit 19 	: X
						//			bit 1a 	: X
						//			bit 1b 	: X
						//			bit 1c 	: X
						//			bit 1d 	: X
						//			bit 1e 	: X
						//			bit 1f 	: X   
                        //      ICM byte:
                        //          XX  :   Number of ICMs in BOX memory.
                        //      OGM byte:
                        //          XX  :   Number of OGMs in Box memory.
                        //		Lost call byte:
                        //			XX  :	Number of lost calls.
struct tagPCInfo
{
	unsigned long 	dwVersion ;
	unsigned char	byHour ;
	unsigned char	byMinute ;
	unsigned char	byMonth ;
	unsigned char	byDay ;
	unsigned char	bySecond ;
} ;
typedef struct tagPCInfo PCINFO ;

typedef struct _BOXINFO
{
 	unsigned long 	lVersion ;      
 	
 	unsigned staAssociatedPhone : 1 ;  	// bit 0
 	unsigned staExtensionPhone 	: 1 ;   // bit 1
 	unsigned staLine			: 1 ;   // bit 2	
	unsigned staPowerFailure	: 1 ;  	// bit 3
	unsigned staLineDisconnect	: 1 ;   // bit 4
	unsigned staRemoteConnected	: 1 ;	// bit 5
	unsigned staMonitorMuted	: 1 ;   // bit 6
	unsigned staMonitorVolumn	: 1 ;   // bit 7
 	
	unsigned staDialTone		: 1 ;   // bit 8
	unsigned staRingBackTone	: 1 ;   // bit 9
	unsigned staBusyTone 		: 1 ;   // bit a
	unsigned staNUTone			: 1 ;   // bit b
	unsigned staParkTone		: 1 ;   // bit c
	unsigned staSpecialTone		: 1 ;   // bit d
	unsigned staIncomingRing	: 1 ;   // bit e
	unsigned staSpecialRing		: 1 ;   // bit f
	
	unsigned staCodedRing		: 1 ;   // bit 10
	unsigned staDistinctiveRing	: 1 ;   // bit 11
	unsigned staDialing			: 1 ;   // bit 12
	unsigned					: 1 ;   // bit 13
	unsigned					: 1 ;   // bit 14
	unsigned					: 1 ;   // bit 15
	unsigned					: 1 ;   // bit 16
	unsigned					: 1 ;   // bit 17
	
	unsigned					: 1 ;   // bit 18
	unsigned					: 1 ;   // bit 19
	unsigned					: 1 ;   // bit 1a
	unsigned					: 1 ;   // bit 1b
	unsigned					: 1 ;   // bit 1c
	unsigned					: 1 ;   // bit 1d
	unsigned					: 1 ;   // bit 1e
	unsigned					: 1 ;   // bit 1f
	
    unsigned char   byICMNumbers ;  
    unsigned char 	byOGMNumbers ;
    unsigned char   byLostCallNumbers ;
    
    // The following bytes indicate the current box date&time.
    // GCG 96.11.8
    unsigned char   byMonth ; 
    unsigned char   byDay ;
    unsigned char   byHour ;
    unsigned char   byMinute ;
    unsigned char   bySeconds ;
    
    unsigned char 	byEventID ;

} BOXINFO, *PBOXINFO;

// Request of PC to BOX.
#define PBCM1  	0xa1 	// Ask to quit.
						// Expected response: ACK, NAK.
#define PBCM2	0xa2 	// Ask BOX to monitor Digits.
						// Expected response: ACK, NAK.
#define PBCM3	0xa3 	// Ask BOX to bar monitoring Digits.
						// Expected response: ACK, NAK.
#define PBCM4	0xa4 	// Ask BOX to monitor CPT.
						// Expected response: ACK, NAK.
#define PBCM5	0xa5 	// Ask BOX to bar monitoring CPT.
						// Expected response: ACK, NAK.
#define PBCM6	0xa6	// Ask to upload the MEM data.
#define BATD	0xff	// Outgoing message type.
#define ECLS    0xfe	// Error in CLIP.
						// 1.) On receiving this command the BOX responses
						//	   with a block of dtats in its memory.
						// 	   Message may be "Incoming Data"( same as CLIP ),
						// 	   "Outgoing Data" (Begin with <BATD>) and "Error
						//	   in receiving CLIP" (Begin with ECLS) with
						//	   error report format is as following:
						//		<ECLS> 1 1 (error in message type) <checksum>
						//		<ECLS> 1 2 (error in parameter type)<checksum>
						// 		<ECLS> 1 3 (error in checksum) <checksum> 
						// 2.) During the transmission if a hardware signal 
						// 	   "DCD" being received then PC should responses
						//	   with <ACK> to suspend the entire transmission 
						// 	   process.
						// 3.) Followed "DCD" signal there is a byte of 
						//	   command. PC can then responses it but without
						//	   any echo to BOX.
						// 4.) BOX can then continue the suspended 
						// 	   transmission after "DCD" and followed command
						//	   byte being sent.                             
                                           
// ADSI Command of PC to Box.
#define PBAC0   0xb0    // Send DTMF String.
						// PC should send data using format as following:
						//	  <ESC2> <Data Length> <PBAC0> <Data> <Checksum>
						// The valid data is DTMF string valid from 0-9, *, 
						// #, A-D.
						// On receiving this block of data sent by PC, the 
						// BOX should response with ACK.
#define PBAC1   0xb1    // Send extend DTMF string.
						// PC should send data using format as following:
						//	  <ESC2> <Data Length> <PBAC1> <Data> <Checksum>
						// The valid data is DTMF string valid from 0-9, *, 
						// #, A-D.
						// On receiving this block of data sent by PC, the 
						// BOX should response with ACK.
#define PBAC2	0xb2	// Open switch-hook.
						// Expected response: ACK, NAK.
#define PBAC3	0xb3 	// Close switch-hook.
						// Expected response: ACK, NAK.
#define PBAC4	0xb4 	// Flash switch-hook.
						// Expected response: ACK, NAK.
#define PBAC5	0xb5 	// Wait for detection of dial tone.
						// Expected response: ACK, NAK.
#define PBAC6	0xb6	// Dial pulse one.
						// Expected response: ACK, NAK.
#define PBAC7	0xb7 	// Switch to data.
						// Expected response: ACK, NAK.
#define PBAC8 	0xb8 	// Switch to voice.
						// Expected response: ACK, NAK.
#define PBAC9	0xb9 	// Open the voice path.
						// Expected response: ACK, NAK.
#define PBAC10	0xba 	// Close the voice path.
						// Expected response: ACK, NAK.
#define PBAC11	0xbb	// Pause time set command.
						// PC should send data using format as following:
						//		<ESC2> 0x02 <PBAC11> <byte> <Checksum>
						//	 	The byte is timeout constant in 0.1 second
						//		with min value of 10 to max 120.
						// On receiving this block of data sent by PC, the
						// BOX should response with ACK.

// Event from BOX to PC.
#define BPEV	0xc0	// BOX should send data using format as following:
						//		<ESC2> 0x06 <BPEV> <Datas> <Checksum>
						// The data format is as following:
						//		Event dword  
						//			bit 0  	: ALT tone detected.
						//			bit 1	: CAS tone detected.           
						//			bit 2	: Telephone line diconnected.          
						//			bit 3	: Associated phone off hook
						//					  within power ring.
						//			bit 4	: Associated phone off hook
						//					  without power ring.
						//			bit 5 	: Associated phone on hook.
						//			bit 6	: Extension phone off hook.
						//			bit 7	: Extension phone on hook.
						//			bit 8	: BOX off hook following power 
						//					: ring.
						//			bit 9	: BOX off hook without preceding
						//					: ring.
						//			bit a	: Dial tone.
						//			bit b	: Ring back tone.
						//			bit c	: Busy tone. (Number engaged tone)
						//			bit d	: Number unobtainable tone.
						//			bit e	: Park tone. (Path enaged tone)
						//			bit f	: Special proceed indication
						//					: (stuttered dial tone)
						//			bit 10  : End of dialing.
						//			bit 11	: End of power ring. 
						//			bit 12	: Normal incoming ring.
						//			bit 13	: Speicial ring. (RBWF)
						//			bit 14	: Coded ring.
						//			bit 15	: Distinective ring.
						//			bit 16	: Remote part connected.
						//			bit 17	: End of tone.
						//			bit 18	: Dial begin.
						//			bit 19	: Box on hook.
						//			bit 1a	: Remote part diconnected.
						//			bit 1b	: The previous call is on hold.
						//			bit 1c	: Telephone line connected.
						//			bit 1d	: X
						//			bit 1e	: X
						//			bit 1f	: X
						//		DTMF byte ( According decode rule of MT8870 )
						//			0x00	: 'D'
						//			0x01	: '1'
						//			0x02	: '2'
						//			0x03	: '3'
						//			0x04	: '4'
						//			0x05	: '5'
						//			0x06	: '6'
						//			0x07	: '7'
						//			0x08    : '8'
						//			0x09	: '9'
						//			0x0a	: '0'
						//			0x0b	: '*'
						//			0x0c	: '#'
						//			0x0d	: 'A'
						//			0x0e	: 'B'
						//			0x0f	: 'C'
						//			0x10	: '!' ( TBR )
						//			0xff	: No DTMF signal.
struct tagBOXEvent
{                                              
	unsigned evALT					: 1 ;	// bit 0	Not used.
	unsigned evCAS					: 1 ;	// bit 1
	unsigned evLineDisconnect		: 1 ;	// bit 2	
	unsigned evPhoneOffWithinRing	: 1 ;   // bit 3
	unsigned evPhoneOffWithoutRing	: 1 ; 	// bit 4  
	unsigned evPhoneOnHook			: 1 ; 	// bit 5
	unsigned evExtensionPhoneOff	: 1 ;   // bit 6
	unsigned evExtensionPhoneOn		: 1 ;	// bit 7
	
	unsigned evBOXOffFollowingRing	: 1 ;	// bit 8 	
	unsigned evBOXOffWithoutRing	: 1 ;	// bit 9	
	unsigned evDialTone				: 1 ;   // bit a
	unsigned evRingBackTone			: 1 ;	// bit b
	unsigned evBusyTone				: 1 ;	// bit c
	unsigned evNUTone				: 1 ;	// bit d
	unsigned evParkTone				: 1 ;	// bit e
	unsigned evSpecialTone			: 1 ;	// bit f  
	
	unsigned evEndOfDialing			: 1 ;	// bit 10
	unsigned evEndOfRing			: 1 ;	// bit 11
	unsigned evIncomingRing			: 1 ;	// bit 12 
	unsigned evSpecialRing			: 1 ; 	// bit 13
	unsigned evCodedRing			: 1 ;	// bit 14
	unsigned evDistinctiveRing		: 1 ;	// bit 15
	unsigned evRemoteConnected		: 1 ;	// bit 16
	unsigned evEndOfTone			: 1 ;	// bit 17
	
	unsigned evDialing				: 1 ;	// bit 18
	unsigned evBoxOnHook			: 1 ;	// bit 19	
	unsigned evRemoteDisconnected	: 1 ;	// bit 1a
	unsigned evHold					: 1 ;	// bit 1b
	unsigned evLineConnect			: 1 ;	// bit 1c
	unsigned 						: 1 ;	// bit 1d
	unsigned 						: 1 ;	// bit 1e
	unsigned						: 1 ; 	// bit 1f
	
	unsigned char byDTMF ;
	
	unsigned char byEventID ;
	
} ;
typedef struct tagBOXEvent BOXEVENT ;	

#define BPCM1	0xd0	// Ask to send the ADSI.
						// 1.) On receiving this command the PC should response
						// 	   with ACK if it's ready.
						// 2.) Then BOX should send data using format as 
						//	   following:
						//			<Head> <Data Length> <Datas> <Checksum> 
						// 3.) During the transmission if a hardware signal 
						// 	   "DCD" being received then PC should responses
						//	   with <ACK> to suspend the entire transmission 
						// 	   process.
						// 4.) Followed "DCD" signal there is a byte of 
						//	   command. PC can then responses it but without
						//	   any echo to BOX.
						// 5.) BOX can then continue the suspended 
						// 	   transmission after "DCD" and followed command
						//	   byte being sent.                             
						// 6.) On end of this transmission if PC received
						//	   correctly it should response with <ACK> else
						//	   <NAK>.

#define BPCM2	0xd1	// Ask to send the CLIP.
						// 1.) On receiving this command the PC should response
						// 	   with ACK if it's ready.
						// 2.) Then BOX should send data using format as 
						//	   following:
						//			<Head> <Data Length> <Datas> <Checksum> 
						// 3.) During the transmission if a hardware signal 
						// 	   "DCD" being received then PC should responses
						//	   with <ACK> to suspend the entire transmission 
						// 	   process.
						// 4.) Followed "DCD" signal there is a byte of 
						//	   command. PC can then responses it but without
						//	   any echo to BOX.
						// 5.) BOX can then continue the suspended 
						// 	   transmission after "DCD" and followed command
						//	   byte being sent.                             
						// 6.) On end of this transmission if PC received
						//	   correctly it should response with <ACK> else
						//	   <NAK>.

#endif
