#if !defined(AFX_CS_H__E7CB9F08_9316_11D1_9709_00A024CB61CA__INCLUDED_)
#define AFX_CS_H__E7CB9F08_9316_11D1_9709_00A024CB61CA__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// cs.h : main header file for CS.DLL

#if !defined( __AFXCTL_H__ )
        #error include 'afxctl.h' before including this file
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCsApp : See cs.cpp for implementation.

class CCsApp : public COleControlModule
{
public:
        BOOL InitInstance();
        int ExitInstance();
};

extern const GUID CDECL _tlid;
extern const WORD _wVerMajor;
extern const WORD _wVerMinor;

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CS_H__E7CB9F08_9316_11D1_9709_00A024CB61CA__INCLUDED)
