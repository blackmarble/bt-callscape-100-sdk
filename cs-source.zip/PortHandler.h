// PortHandler.h: interface for the CPortHandler class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PORTHANDLER_H__618ECF45_9AF1_11D1_962F_00A024CB5FE4__INCLUDED_)
#define AFX_PORTHANDLER_H__618ECF45_9AF1_11D1_962F_00A024CB5FE4__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#ifndef _PORTHANDLER_
#define _PORTHANDLER_
#include "port.h"
// a port handler is required to handle a COM port

#define PH_OK 0 // ok for porthandler
class CPortHandler  
{
// PortHandler class forces user to provide the following functions
// HandleEvent(...);
// HandleError(...);
// HandleMessage(...); // for debug purposes only
public:
	CPortHandler();
	virtual ~CPortHandler();
	virtual int HandlePortEvent(int nPortEvent, PBYTE lpBuf, DWORD dwBufLen) = 0;
	virtual int HandlePortError(PCHAR szMessage) = 0;
	virtual int HandlePortMessage(PCHAR szMessage) = 0;
	char signature[20]; // set to "PortHandler"	

protected:
	Port * m_myPort; // the Port object
};

#endif // _PORTHANDLER_

#endif // !defined(AFX_PORTHANDLER_H__618ECF45_9AF1_11D1_962F_00A024CB5FE4__INCLUDED_)
