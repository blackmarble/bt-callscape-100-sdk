// CsPpg.cpp : Implementation of the CCsPropPage property page class.

#include "stdafx.h"
#include "cs.h"
#include "CsPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CCsPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CCsPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CCsPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CCsPropPage, "CS.CsPropPage.1",
	0xe7cb9f03, 0x9316, 0x11d1, 0x97, 0x9, 0, 0xa0, 0x24, 0xcb, 0x61, 0xca)


/////////////////////////////////////////////////////////////////////////////
// CCsPropPage::CCsPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CCsPropPage

BOOL CCsPropPage::CCsPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_CS_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CCsPropPage::CCsPropPage - Constructor

CCsPropPage::CCsPropPage() :
	COlePropertyPage(IDD, IDS_CS_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CCsPropPage)
	// NOTE: ClassWizard will add member initialization here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CCsPropPage::DoDataExchange - Moves data between page and properties

void CCsPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CCsPropPage)
	// NOTE: ClassWizard will add DDP, DDX, and DDV calls here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CCsPropPage message handlers
