/*
  ---------------------------------------------------------------------------
  Class  : CallScapeHW
  Author : A.R.Haynes
  Date   : 22/1/1998
  ---------------------------------------------------------------------------
  Revision History :
  22/1/1998     0.1     Created

  ---------------------------------------------------------------------------
  Comments :
  The CallScapeHW class :- deals with all messaging required by the callscape
  hardware to allow simple creation.
  Messaging Format
  ================
  Messaging format is known from PC Screen Phone file comcmd.h
  Commands
  --------
  1. For a one byte command
  ESC <Command Byte>
  2. For a multibyte command
  ESC2<length> <Command byte> <Parameters> <Checksum>

  where
  <length> is num bytes NOT COUNTING <ESC2> and <length> and <Checksum>
  <Checksum> is total sum value of all bytes except checksum inversed then +1 (???)

  Acknowledgements
  ----------------
  1. One byte acknowledgement
  ACK,NAK
  2. Multibyte acknowledgement
  ACK2 <Length> <Parameters> <Checksum>
  where <length> and <checksum> are as defined for commands.

  General PC command to BOX
      Command
  PC----------->BOX
        ACK
  PC<-----------BOX

  Box event or request to PC

  PC<-----------BOX
        ACK
  PC----------->BOX

 Box send Class to PC
      Command
  PC<-----------BOX
        ACK
  PC----------->BOX
       Data
  PC<-----------BOX
        ACK
  PC----------->BOX

  PC Upload BOX Memory
      Command
  PC----------->BOX
        ACK
  PC<-----------BOX

  Revision History :
  22/1/1998     0.1     Created

  ---------------------------------------------------------------------------
*/
#ifndef _CALLSCAPEHW_
#define _CALLSCAPEHW_
#include "PortHandler.h"  // com port class
#include "CallScapeEvents.h"  // com port class
#include "comcmd.h" // the callscape commands
#include "class.h" // the callscape clip defines

// forward declaration of our handler
class CCallScapeHandler;  // the handler - we need a pointer to one to function
class CCsCtrl;

// messages
#define CS_WM_MESSAGE					WM_USER + 0x01
#define CS_WM_ERROR						WM_USER + 0x02
#define CS_WM_EVENT						WM_USER + 0x03

#define CS_SIZE_PORTNAME				P_MAX_NAME_LEN
#define CS_SPEAKER_VOLUME_LOW           0x01
#define CS_SPEAKER_VOLUME_MEDIUM        0x02
#define CS_SPEAKER_VOLUME_HIGH          0x03

#define CS_OK					0x00
#define CS_ERR_PORTDISCONNECTED	0x01
#define CS_ERR_PORTCONFIG		0x02
#define CS_ERR_PORTNAMETOOLONG	0x03
#define CS_ERR_CONNECTED		0x04
#define CS_ERR_INVALID			0x05
#define CS_ERR_BUSY				0x06
#define CS_ERR_MEMORY			0x07
#define CS_ERR_NOCALLSCAPE		0x08

// the states
#define CS_STATE_IDLE			0x00
#define CS_STATE_INITIALIZING	0x01
#define CS_STATE_NOTCONNECTED   0x02
#define CS_STATE_BUSY			0x03
#define CS_STATE_WAITCMD		0x04
#define CS_STATE_WAITDATA		0x05
#define CS_STATE_DISCONNECTING	0x06
// CLIP states
#define CS_INCOMING_CLIP_OLD	0x01
#define CS_INCOMING_CLIP_NEW	0x02
#define CS_OUTGOING_CLIP_OLD	0x03
#define CS_OUTGOING_CLIP_NEW	0x04

// number of times a command should be attempted before failing
#define CS_NUM_RETRIES			0x03

// Command timeout - if no response within this time something is wrong
#define CS_COMMAND_TIMEOUT_VAL	5000 // 5 seconds

// buffer size
#define MAX_BUFFER_SIZE 260 // taken from ptspiexe.h

// a command structure
typedef struct _CS_COMMANDSTRUCT
{
	BYTE sBuffer[MAX_BUFFER_SIZE] ;
	int  nLength ;
	int  nRetry ;
	BOOL bWaiting ;
} CS_COMMANDSTRUCT, *PCS_COMMANDSTRUCT ;

typedef struct _DIAL_STRUCT
{
	short isDialPause; // two bytes
	char szDialString[50]; // how long can a phone number be ?
} DIAL_STRUCT , *PDIAL_STRUCT;

typedef struct _CS_MESSAGE_STRUCT
{
	int iEvent;		// the event number
	char * psData; // the buffer
}  CS_MESSAGE_STRUCT, *PCS_MESSAGE_STRUCT;

class CallScapeHW : public CPortHandler{
   public:
	  // every callscape needs a callscape handler
      CallScapeHW(CCsCtrl * myHandler);  // the callscape constuctor
      ~CallScapeHW(); // the callscape destructor
   
      SetComPort(PCHAR szPortName); // allows user to set the COMn eg "COM1"
                                     // port (all others hardcoded)
                                     // win32 compliant - not necessary COMn
      Dial(PCHAR szNumToDial); // requests callscape to initiate dial
      Hangup();          // forces callscape to hangup
      GetStatus();       // returns current status code
      BOOL TestSanity(); // returns FALSE if not 100% happy
      DoSelfTest();
	  Connect();
	  int QueryBox(); // returns status
	  int GetMissedCallDetails(); // ask to upload the missed call info
	  TxCommand(); // transmits current command from command member params
	  Shutdown(); // close down the comms
      SetSpeakerVolume(int val); // LOW,MEDIUM,HIGH
      // this is public so that timer events can trigger an error
	  int HandleCallScapeError(PCHAR szMessage);

   protected:	  
	  // Functions to be provided for PortHandler
	  int HandlePortEvent(int nPortEvent, PBYTE lpBuf, DWORD dwBufLen);
	  int HandlePortError(PCHAR szMessage);
	  int HandlePortMessage(PCHAR szMessage);


	  int HandleCallScapeEvent(int nCallScapeEvent, PBYTE lpBuf, DWORD dwBufLen);
	 
	  int HandleCallScapeMessage(PCHAR szMessage);

	  PCHAR GetComPort(); // get the port name

      LineOff();
      LineOn();
      MuteMonitor();
      UnMuteMonitor();
      QueryStatus();
      Quit();
      MonitorDigits();
      StopMonitoringDigits();
      MonitorCPT();
      StopMonitoringCPT();
      UploadMEM();
      SetOutgoingMessageType();
      ReportErrorInClip();
	  int SendCommand(BYTE byCommand, LPCSTR lpsParams, BYTE byParaLen);
	  void FillCommandBuffer( BYTE byCmd, LPCSTR lpsPara, BYTE byParaLen );

  private:

	  int		TxData(PBYTE TxData, DWORD dwNumBytes); // transmits raw bytes to CallScape
	  int		ProcessCommand();  // interpret data stream received from callscape
	  int		ProcessBPEV(BOXEVENT * beBE); // interpret the BPEV stream
	  int		ProcessBPCM2(int nClipState) ; // proces the raw CLIP message
	  int		ProcessQuery(PBOXINFO PbiQueryResult);
	  int		TranslateCLIP( LPSTR lpCLIP, DWORD CLIPSize,
				  LPDISPLAYABLECLIP lpTransResult);
	  int		ConfigurePort();
	  short     StartCommandTimer();
	  short     StopCommandTimer();
	  bool		m_bValidResponse; // used to determine if real hardware connected
	  // CCallScapeHandler * m_Handler;
	  CCsCtrl *		m_HandlerCWnd;
	  CCsCtrl *		m_Handler;
	  Port *		m_myPort;
	  CHAR			m_szMyPortName[CS_SIZE_PORTNAME+1];
	  BOOL			bConnected;
	  
	  // the Command timeout timer
	  UINT		m_uiCommandTimer;
	  
      COMMTIMEOUTS gTimeoutsDefault;

	  CS_COMMANDSTRUCT m_CurrentCmd; // the current command we are processing

	  // received data buffer
  	  BYTE		m_rxBuffer[1024]; // don't know how big to expect....
  	  int		m_nBuffer;		  // number of bytes n rxBuffer
	  
	  // the parsed command
	  int		m_nState; 	  
	  int		m_byBlock;			// ESC, ESC2, ESC3
	  int		m_byCommand;		// BPEV, ATD etc.
	  BYTE		m_CmdParams[1024];	// where to put them
	  int		m_nParamCount;		// offset into CmdParams to put data bytes
	  int		m_nBytesRemaining;	// how many more params to expect
	  BYTE		m_byChecksum;		// running checksum result
	  BOOL		m_bBadChecksum;		// FALSE = pass or TRUE = fail

};  //ehd of class
#endif // _CALLSCAPEHW_
