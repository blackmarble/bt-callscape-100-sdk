// CallScapeHandler.cpp: implementation of the CCallScapeHandler class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//#include "coms32.h"
#include "CallScapeHandler.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCallScapeHandler::CCallScapeHandler()
{
	strcpy(signature, "CallScapeHandler");
}

CCallScapeHandler::~CCallScapeHandler()
{

}
