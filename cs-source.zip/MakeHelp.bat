@echo off
REM -- First, make map file from resource.h
echo // MAKEHELP.BAT generated Help Map file.  Used by CS.HPJ. > "hlp\cs.hm"
echo. >>hlp\cs.hm
echo // Commands (ID_* and IDM_*) >> "hlp\cs.hm"
makehm ID_,HID_,0x10000 IDM_,HIDM_,0x10000 resource.h >> "hlp\cs.hm"
echo. >> "hlp\cs.hm"
echo // Prompts (IDP_*) >> "hlp\cs.hm"
makehm IDP_,HIDP_,0x30000 resource.h >> "hlp\cs.hm"
echo. >> "hlp\cs.hm"
echo // Resources (IDR_*) >> "hlp\cs.hm"
makehm IDR_,HIDR_,0x20000 resource.h >> "hlp\cs.hm"
echo. >> "hlp\cs.hm"
echo // Dialogs (IDD_*) >> "hlp\cs.hm"
makehm IDD_,HIDD_,0x20000 resource.h >> "hlp\cs.hm"
echo. >> "hlp\cs.hm"
echo // Frame Controls (IDW_*) >> "hlp\cs.hm"
makehm IDW_,HIDW_,0x50000 resource.h >> "hlp\cs.hm"
REM -- Make help for Project CS
start /wait hcw /C /E /M "cs.hpj"
echo.
