// CallScapeHandler.h: interface for the CCallScapeHandler class.
//
//////////////////////////////////////////////////////////////////////

/*
CallScapeHandler
(c) Black Marble Ltd. 1998
Author	:	A.R.Haynes
Date	:	01/02/1998

To Use the Callscape :

  (1) derive a class from this base class - this forces you to provide
  the following Handler functions
  HandleEvent(int nCallScapeEvent, PBYTE lpBuf, DWORD dwBufLen);
    Handle event will be called every time the callscape detects a 
	change in circumstances that it thinks it's handler should be aware of
	nCallScapeEvent : provides details of the event
	lpBuf : contains further details (if there)
	specifically, if nCallScapeEvent = CS_EV_GOTCLIP, 
	a displayable CLIP structure is passed in lpBuf.
	dwBufLen specifies the number of valid bytes in lpBuf

  HandleError(PHAR szMessage)
  HandleMessage(PCHAR szMessage)
	These are simple messaging handlers to allow debugging of the 
	application

  (2) declare a new CallScape object as follows
  CallScape myCallScape = new CallScape(this);
  we have to do this within a class derived from CallScapeHandler, so that the
  "this" pointer is valid.  
  (3) As a further precaution, the signature member varaible should 
  be initialized to "CallScapeHandler" in the  class constructor
  (4) Use the following methods
  myCallScape.SetCommPort("COM1"); // or whatever port is to be used
  myCallscape.Connect();  
  (5) // when finished use

	myCallScape.Shutdown();
	delete myCallScape;
  
  // the following functions are available
  int Dial(PCHAR szNumToDial)
  ---------------------------
  dials the number given in (szNumToDial)
  returns on of the following error codes
	CS_ERR_PORTDISCONNECTED // connection cannot be established
	CS_ERR_BUSY			// the callscape cannot dial at this time
  asynchronous errors may be given via HandleCallScapeEvents()

  int Hangup()
  ------------
  Hangs up the current call
  returns on of the following error codes
	CS_ERR_PORTDISCONNECTED // connection cannot be established
	CS_IDLE	// the callscape cannot hangup because it is not in a call

  
  int Shutdown()
  --------------
  can return CS_ERR_PORTDISCONNECTED if we are not already connected

*/

#if !defined(AFX_CALLSCAPEHANDLER_H__618ECF41_9AF1_11D1_962F_00A024CB5FE4__INCLUDED_)
#define AFX_CALLSCAPEHANDLER_H__618ECF41_9AF1_11D1_962F_00A024CB5FE4__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef _CALLSCAPEHANDLER_
#define _CALLSCAPEHANDLER_

#include "cscapehw.h" // the ComPort class containing info
#include "CallScapeEvents.h"
class CCallScapeHandler
// CallScapeHandler class forces user to provide the following functions
// HandleEvent(...);
// HandleError(...);
// HandleMessage(...); // for debug purposes only
{
public:
	CCallScapeHandler();
	virtual ~CCallScapeHandler();
	// these are now done with messages
	//virtual int HandleCallScapeEvent(int nCallScapeEvent, PBYTE lpBuf, DWORD dwBufLen) = 0;
	//virtual int HandleCallScapeError(PCHAR szMessage) = 0;
	//virtual int HandleCallScapeMessage(PCHAR szMessage) = 0;
	char signature[20];

protected:
	char signature[20];
	CallScapeHW * m_Callscape; // the callscape object
};
#endif // _CALLSCAPEHANDLER_

#endif // !defined(AFX_CALLSCAPEHANDLER_H__618ECF41_9AF1_11D1_962F_00A024CB5FE4__INCLUDED_)
