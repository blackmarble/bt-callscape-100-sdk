// Port.h: interface for the Port class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PORT_H__A522EF15_90B7_11D1_962F_00A024CB5FE4__INCLUDED_)
#define AFX_PORT_H__A522EF15_90B7_11D1_962F_00A024CB5FE4__INCLUDED_
#ifndef _PORT_
#define _PORT_
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include "ttyinfo.h"
#include "chwstate.h" // the states
class CPortHandler; // Forward declaration because we'll be needing this later...
//
// Error Codes
//
#define P_OK					0x00
#define P_ERR_INVALID_PORTNAME	0x10
#define P_ERR_INVALID_ESCAPEFN	0x20
#define P_ERR_DISCONNECTED		0x30
#define P_ERR_NAMETOOLONG		0x40
#define P_MAX_NAME_LEN			20 // max name of port
// Port Status events
#define P_STATUS_NOWRITETHREAD	0x01 // clear these bits when thread
#define P_STATUS_NOMONITORTHREAD	0x02 // has started

// Port Events
//
#define EV_PORT_RXDATA			0x01
#define	EV_PORT_ERROR			0x02
#define EV_PORT_STATUSCHANGE	0x03

//
// Write request types
//
#define WRITE_CHAR          0x01
#define WRITE_FILE          0x02
#define WRITE_FILESTART     0x03
#define WRITE_FILEEND       0x04
#define WRITE_ABORT         0x05
#define WRITE_BLOCK         0x06


typedef struct WRITEREQUEST
{
  DWORD      dwWriteType;        // char, file start, file abort, file packet
  DWORD      dwSize;             // size of buffer
  char       ch;                 // ch to send
  char *     lpBuf;              // address of buffer to send
  HANDLE     hHeap;              // heap containing buffer
  HWND       hWndProgress;       // status bar window handle
  struct WRITEREQUEST *pNext;    // next node in the list
  struct WRITEREQUEST *pPrev;    // prev node in the list
} WRITEREQUEST, *PWRITEREQUEST;

#define AMOUNT_TO_READ          512
#define RXQ_SIZE				1024
//#define NUM_READSTAT_HANDLES    4
#define NUM_READSTAT_HANDLES    3

//typedef struct STATUS_MESSAGE
//{
//   struct STATUS_MESSAGE * lpNext;     // pointer to next node
//    char chMessageStart;                // variable length string start here
//} STATUS_MESSAGE;

class Port  
{
public :

	//
	//  Writer heap variables - make these public because the threads need them
	//
	CRITICAL_SECTION gcsWriterHeap;
	CRITICAL_SECTION gcsDataHeap;
	HANDLE ghWriterHeap;
	HANDLE ghWriterEvent;
	// HANDLE ghTransferCompleteEvent;
	//	HANDLE ghStatusMessageEvent;
	//	HANDLE ghStatusMessageHeap;
	DWORD	m_TlsLastComStat;
	DWORD	m_TlsLastError;
	DWORD	m_TlsLastStatus;
    //
	//  Write request data structure; look in Writer.c for more info
	//
	// typedef struct WRITEREQUEST;

	struct WRITEREQUEST *gpWriterHead;
	struct WRITEREQUEST *gpWriterTail;
	//
	// flag to indicate whether the port is ready yet
	int m_nStatus;
	//
	//  Flags controlling thread actions
	//
	HANDLE ghThreadExitEvent;
	BOOL gfAbortTransfer;

	Port(CPortHandler * myOwner); // open the port  - must use SetName later
	virtual ~Port();
	BOOL TxData(PBYTE lpBuf, DWORD dwNumBytes); // simple way to get at WRITER_ADDNEWNODE with string

	HANDLE	SetupCommPort(); // configures the communications resource
	int		UpdateConnection(); // resets comms parameters
	int		BreakDownCommPort(); // shuts down the CommPort
	// The Worker Threads need to access the following
	void	HandleWriteRequests(); // Writer Thread needs this, so make it public
	void	ErrorReporter(PCHAR message);	// also uses m_LogWindow
	void	MessageReporter(PCHAR message);	// also uses m_LogWindow
	void	ErrorHandler(PCHAR message);	// uses m_LogWindow
	void	ErrorInComm(PCHAR message);		// shuts down com port first
	void    IncomingDataReporter(PCHAR message); // sends to m_RxWindow
	void	CheckModemStatus( BOOL bUpdateNow );
	void    CheckComStat(BOOL bUpdateNow);
	void	ProcessReceivedData(PBYTE lpBuf, DWORD dwBufLen);
	void	OutputABuffer(PBYTE lpBuf, DWORD dwBufLen);
	void	ReportStatusEvent(DWORD dwStatus);
//	void	StatusMessage();	
	int		EscapeFunction(DWORD dwFN);
	
	int		SetName(PCHAR szNewName);
	PCHAR	GetName();
	HANDLE  GetComDev();
	void	SetComDev(HANDLE hNewHandle);
	HANDLE	GetWriterThreadHandle();
	void	SetWriterThreadHandle(HANDLE hNewHandle);
	HANDLE	GetMonitorThreadHandle();
	void	SetMonitorThreadHandle(HANDLE hNewHandle);
	BOOL	IsConnected();
	void	SetConnected(BOOL bState);
	BYTE	GetParity();
	void	SetParity(BYTE bNewParity);
	BOOL	GetStopBits();
	void	SetStopBits(BOOL bNewStop);
	DWORD	GetBaudRate();
	void	SetBaudRate(DWORD dwNewBaud);
	DWORD	GetEventFlags();
	void	SetEventFlags(DWORD dwNewEventFlags);
	BOOL	ReadingDisabled();
	void	DisableReading(BOOL fNewReading);
	BOOL	WritingDisabled();
	void	DisableWriting(BOOL fNewWriting);
	BOOL	EventsDisabled();
	void	DisableEvents(BOOL fNewState);
	BOOL	StatusDisabled();
	void	DisableStatus(BOOL fNewStatus);
	//BOOL	ShowTimeouts();
	//void	SetShowTimeouts(BOOL fNewState);
	BOOL	GetBinary();
	void	SetBinary(BOOL fNewState);
	DWORD	GetDTRControl();
	void	SetDTRControl(DWORD dwNewVal);
	DWORD	GetRTSControl();
	void	SetRTSControl(DWORD dwNewVal);
	CHAR	GetXONChar();
	void	SetXONChar(CHAR chNewChar);
	CHAR	GetXOFFChar();
	void	SetXOFFChar(CHAR chNewChar);
	WORD	GetXONLimit();
	void	SetXONLimit(WORD wNewVal);
	WORD	GetXOFFLimit();
	void	SetXOFFLimit(WORD wNewVal);
	BOOL	GetCTSOutFlow();
	void	SetCTSOutFlow(BOOL bNewVal);
	BOOL	GetDSROutFlow();
	void	SetDSROutFlow(BOOL bNewVal);
	BOOL	GetDSRInFlow();
	void	SetDSRInFlow(BOOL bNewVal);
	BOOL	GetXONXOFFOutFlow();
	void	SetXONXOFFOutFlow(BOOL bNewVal);
	BOOL	GetXONXOFFInFlow();
	void	SetXONXOFFInFlow(BOOL bNewVal);
	BOOL	GetTXAFTERXOFFSENT();
	void	SetTXAFTERXOFFSENT(BOOL bNewVal);
	BYTE	GetByteSize();
	void	SetByteSize(BYTE bNewByte);
	CHAR	GetFlagChar();
	void	SetFlagChar(CHAR chNewFlag);
	COMMTIMEOUTS GetOrigTimeouts();
	void	SetOrigTimeouts(COMMTIMEOUTS cto);
	void	SetTimeouts(COMMTIMEOUTS cto);
	COMMTIMEOUTS GetTimeouts();
	// PDCB	GetDCB();
	// int		SetDCB(PDCB theDCB);

	
private :
	
	void	InitConstructor(); // common initialization for constructors
	void	WriterComplete();
	void    WriterAbort(PWRITEREQUEST pAbortNode);
	void    WriterBlock(PWRITEREQUEST pAbortNode);
	void    WriterChar(PWRITEREQUEST pAbortNode);
	void	WriterGeneric(PBYTE lpBuf, DWORD dwToWrite);
	void	StartThreads();
	
	BOOL	WriterAddNewNode(  DWORD dwRequestType, 
                        DWORD dwSize, 
                        char ch, 
                        char * lpBuf, 
                        HANDLE hHeap, 
                        HWND hProgress);
	BOOL	WriterAddNewNodeTimeout(   DWORD dwRequestType, 
                                DWORD dwSize, 
                                char ch, 
                                char * lpBuf, 
                                HANDLE hHeap, 
                                HWND hProgress,
                                DWORD dwTimeout  );
 	BOOL	WriterAddFirstNodeTimeout(   DWORD dwRequestType, 
                                DWORD dwSize, 
                                char ch, 
                                char * lpBuf, 
                                HANDLE hHeap, 
                                HWND hProgress,
                                DWORD dwTimeout  );
	void	AddToLinkedList(PWRITEREQUEST pNode);
	void	AddToFrontOfLinkedList(PWRITEREQUEST pNode);
	PWRITEREQUEST RemoveFromLinkedList(PWRITEREQUEST pNode);
    void	ReportComStat(COMSTAT ComStat);
	
//	void	InitStatusMessage();
//	void	UpdateStatus(char * szText);
	void	ReportModemStatus(DWORD dwModemStatus);
	void	ReportCommError();

	// PRIVATE MEMBER DATA
	CPortHandler * m_myPortHandler;
	// and a whole host of settings
	
	// 
	//
	//  Status updating
	//
	
	CRITICAL_SECTION gStatusCritical;
//	HFONT ghFontStatus;
	int   gnStatusIndex;

//	struct STATUS_MESSAGE * glpStatusMessageHead;
//	struct STATUS_MESSAGE * glpStatusMessageTail;
	// A com port has a name
	char	m_szName[P_MAX_NAME_LEN];
	// and a whole pile of other information
	HANDLE  hCommPort;						// the handle of the com port
	DCB		m_dcb;							// current comms settings 
	HANDLE  hReaderStatus;					// handle for Reader/Status
	HANDLE  hWriter;						// handle for the writer
    DWORD   dwEventFlags;					// The EventFlags
    CHAR    chFlag;
	CHAR    chXON;
	CHAR	chXOFF;
    WORD    wXONLimit;
	WORD	wXOFFLimit;
    DWORD   fRtsControl;
    DWORD   fDtrControl;
    BOOL    fConnected;
	BOOL	fBinary;
	BOOL    fTransferring;
	BOOL	fRepeating;
    BOOL    fLocalEcho;
	BOOL    fNewLine;
    BOOL    fDisplayErrors;
	BOOL    fAutowrap;
    BOOL    fCTSOutFlow;
    BOOL    fDSROutFlow;
	BOOL	fDSRInFlow;
    BOOL	fXonXoffOutFlow;
	BOOL	fXonXoffInFlow;
    BOOL	fTXafterXoffSent;
    BOOL	fNoReading;
	BOOL	fNoWriting;
	BOOL	fNoEvents;
	BOOL	fNoStatus;
//    BOOL	fDisplayTimeouts;
    BYTE    bPort;
	BYTE	bByteSize;
	BYTE	bParity;
	BYTE	bStopBits;
    DWORD   dwBaudRate ;
    COMMTIMEOUTS timeoutsorig;
    COMMTIMEOUTS timeoutsnew;
    //int     xSize;
	//int		ySize;
	//int     xScroll;
	//int     yScroll;
	//int     xOffset;
	//int		yOffset;
    //int		nColumn;
	//int		nRow;
	//int		xChar;
	//int		yChar;
	//int		nCharPos;
  
};

#endif // _PORT_
#endif // !defined(AFX_PORT_H__A522EF15_90B7_11D1_962F_00A024CB5FE4__INCLUDED_)
