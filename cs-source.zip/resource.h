//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by cs.rc
//
#define IDS_CS                          1
#define IDD_ABOUTBOX_CS                 1
#define IDB_CS                          1
#define IDI_ABOUTDLL                    1
#define IDS_CS_PPG                      2
#define IDS_CS_PPG_CAPTION              200
#define IDD_PROPPAGE_CS                 200
#define IDI_OFFHOOK                     201
#define IDC_COMPORT                     201
#define IDI_ONHOOK                      202

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
