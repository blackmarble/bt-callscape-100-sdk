// (c) Black Marble Ltd.
// Author : A.R.Haynes
// 01/02/1998
// the events that the callscape handler should handle
#ifndef _CHWEVENTS_
 #define _CHWEVENTS_

	#define CS_EV_ALT						0x0001
	#define CS_EV_CAS						0x0002
	#define CS_EV_LINEDISCONNECT			0x0003
	#define CS_EV_PHONEOFFWITHINRING		0x0004
	#define CS_EV_PHONEOFFWITHOUTRING		0x0005
	#define CS_EV_PHONEONHOOK				0x0006
	#define CS_EV_EXTENSIONPHONEOFF			0x0007
	#define CS_EV_EXTENSIONPHONEON			0x0008
	#define CS_EV_BOXOFFFOLLOWINGRING		0x0009
	#define CS_EV_BOXOFFWITHOUTRING			0x000a
	#define CS_EV_DIALTONE					0x000b
	#define CS_EV_RINGBACKTONE				0x000c
	#define CS_EV_BUSYTONE					0x000d
	#define CS_EV_NUTONE					0x000e
	#define CS_EV_PARKTONE					0x000f
	#define CS_EV_SPECIALTONE				0x0010
	#define CS_EV_ENDOFDIALLING				0x0011
	#define CS_EV_ENDOFRING					0x0012
	#define CS_EV_INCOMINGRING				0x0013
	#define CS_EV_SPECIALRING				0x0014
	#define CS_EV_CODEDRING					0x0015
	#define CS_EV_DISTINCTIVERING			0x0016
	#define CS_EV_REMOTECONNECTED			0x0017
	#define CS_EV_ENDOFTONE					0x0018
	#define CS_EV_DIALLING					0x0019
	#define CS_EV_BOXONHOOK					0x001a
	#define CS_EV_REMOTEDISCONNECTED		0x001b
	#define CS_EV_HOLD						0x001c
	#define CS_EV_LINECONNECT				0x001d
	#define CS_EV_GOTCLIP					0x001e // callscape has clip info for us
	#define CS_EV_QUERYRESULT				0x001f // the box query results
    #define CS_EV_DIALCHAR					0x0020 // button pressed on phone terminal

#endif //_CHWEVENTS_