// cs.cpp : Implementation of CCsApp and DLL registration.

#include "stdafx.h"
#include "cs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CCsApp NEAR theApp;

const GUID CDECL BASED_CODE _tlid =
		{ 0xe7cb9eff, 0x9316, 0x11d1, { 0x97, 0x9, 0, 0xa0, 0x24, 0xcb, 0x61, 0xca } };
const WORD _wVerMajor = 1;
const WORD _wVerMinor = 0;

//COleControlModule::afxTraceEnabled=TRUE;


////////////////////////////////////////////////////////////////////////////
// CCsApp::InitInstance - DLL initialization

BOOL CCsApp::InitInstance()
{
#ifdef _DEBUG
	afxTraceEnabled = TRUE;
#endif

	BOOL bInit = COleControlModule::InitInstance();
   
	if (bInit)
	{
		// TODO: Add your own module initialization code here.
	}

	return bInit;
}


////////////////////////////////////////////////////////////////////////////
// CCsApp::ExitInstance - DLL termination

int CCsApp::ExitInstance()
{
	// TODO: Add your own module termination code here.

	return COleControlModule::ExitInstance();
}


/////////////////////////////////////////////////////////////////////////////
// DllRegisterServer - Adds entries to the system registry

STDAPI DllRegisterServer(void)
{
	AFX_MANAGE_STATE(_afxModuleAddrThis);

	if (!AfxOleRegisterTypeLib(AfxGetInstanceHandle(), _tlid))
		return ResultFromScode(SELFREG_E_TYPELIB);

	if (!COleObjectFactoryEx::UpdateRegistryAll(TRUE))
		return ResultFromScode(SELFREG_E_CLASS);

	return NOERROR;
}


/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the system registry

STDAPI DllUnregisterServer(void)
{
	AFX_MANAGE_STATE(_afxModuleAddrThis);

	if (!AfxOleUnregisterTypeLib(_tlid, _wVerMajor, _wVerMinor))
		return ResultFromScode(SELFREG_E_TYPELIB);

	if (!COleObjectFactoryEx::UpdateRegistryAll(FALSE))
		return ResultFromScode(SELFREG_E_CLASS);

	return NOERROR;
}
