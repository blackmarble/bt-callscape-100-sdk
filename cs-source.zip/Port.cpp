// Port.cpp: implementation of the Port class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
// #include "coms32.h"
#include "Port.h"
#include "cscapehw.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

UINT MyWriterThreadProc(LPVOID pParam)  
{   
	// let's play to ensure that the thread works
	Port* thePort = (Port *) pParam;
	TRACE("Started WriterThreadProc\r\n");
	SYSTEM_INFO sysInfo;
    HANDLE hArray[2];
    DWORD dwRes;
    DWORD dwSize;
    BOOL fDone = FALSE;

    //
    // create a heap for WRITE_REQUEST packets
    //
    GetSystemInfo(&sysInfo);
    thePort->ghWriterHeap = HeapCreate(0, sysInfo.dwPageSize*2, sysInfo.dwPageSize*4);
    if (thePort->ghWriterHeap == NULL) {
        thePort->ErrorInComm("HeapCreate (write request heap)");
		TRACE("Error creating heap for writer");
	}
	TRACE("Created Heap");
	// initialize our thread local storage
	// we want to put a COMSTAT into m_TlsComStat and 
	LPVOID tmpPointer = malloc(sizeof(COMSTAT));
	if (tmpPointer == NULL) {
		  TRACE("Internal Memory allocation error\r\n");
		return 1;
	}
	TlsSetValue(thePort->m_TlsLastComStat, tmpPointer);
	tmpPointer = NULL;
	tmpPointer = TlsGetValue(thePort->m_TlsLastComStat);

  
    //
    // create synchronization events for write requests and file transfers
    //
    thePort->ghWriterEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
    if (thePort->ghWriterEvent == NULL)
        thePort->ErrorInComm("CreateEvent(write request event)");

//    thePort->ghTransferCompleteEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
 //   if (thePort->ghTransferCompleteEvent == NULL)
  //      thePort->ErrorInComm("CreateEvent(transfer complete event)");

    //
    // initialize write request linked list
    //
    dwSize = sizeof(WRITEREQUEST);
    thePort->gpWriterHead = (WRITEREQUEST *) HeapAlloc(thePort->ghWriterHeap, HEAP_ZERO_MEMORY, dwSize);
    thePort->gpWriterTail = (WRITEREQUEST *) HeapAlloc(thePort->ghWriterHeap, HEAP_ZERO_MEMORY, dwSize);
    thePort->gpWriterHead->pNext = thePort->gpWriterTail;
    thePort->gpWriterTail->pPrev = thePort->gpWriterHead;

    hArray[0] = thePort->ghWriterEvent;
    hArray[1] = thePort->ghThreadExitEvent;

	TRACE("Writer Thread : initialization complete\r\n");
	thePort->m_nStatus ^= P_STATUS_NOWRITETHREAD;
	
    while ( !fDone ) {
        dwRes = WaitForMultipleObjects(2, hArray, FALSE, WRITE_CHECK_TIMEOUT);
        switch(dwRes)
        {
            case WAIT_TIMEOUT:
                    break;

            case WAIT_FAILED:
					TRACE("Wait Failed\n");
                    thePort->ErrorReporter("WaitForMultipleObjects( writer proc )");
//                    break;

            //
            // write request event
            //
            case WAIT_OBJECT_0:
				    thePort->HandleWriteRequests();
                    break;
            //
            // thread exit event
            //
            case WAIT_OBJECT_0 + 1:
                    fDone = TRUE;
                    break;
        }
    }

//    CloseHandle(thePort->ghTransferCompleteEvent);
    CloseHandle(thePort->ghWriterEvent);

    //
    // Destroy WRITE_REQUEST heap
    //
    HeapDestroy(thePort->ghWriterHeap);

	// free our ThreadLocalStorage
	free(TlsGetValue(thePort->m_TlsLastComStat));
    return 1;
} // end of MyWriterThreadProc

UINT MyMonitorThreadProc(LPVOID pParam)  //  LPVOID pParam )
{   
	Port * thePort = (Port *) pParam;
	
    OVERLAPPED osReader = {0};  // overlapped structure for read operations
    OVERLAPPED osStatus = {0};  // overlapped structure for status operations
    HANDLE     hArray[NUM_READSTAT_HANDLES];
    DWORD      dwStoredFlags = 0xFFFFFFFF;      // local copy of event flags
    DWORD      dwCommEvent;     // result from WaitCommEvent
    DWORD      dwOvRes;         // result from GetOverlappedResult
    DWORD 	   dwRead;          // bytes actually read
    DWORD      dwRes;           // result from WaitForSingleObject
    BOOL       fWaitingOnRead = FALSE;
    BOOL       fWaitingOnStat = FALSE;
    BOOL       fThreadDone = FALSE;
    BYTE   	   lpBuf[RXQ_SIZE]; // [AMOUNT_TO_READ];


    //
    // create two overlapped structures, one for read events
    // and another for status events
    //
	// TRACE("Handle is : %lx", thePort->GetComDev());
    osReader.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
    if (osReader.hEvent == NULL) {
		TRACE("Error creating Read Event");
        thePort->ErrorInComm("CreateEvent (Reader Event)");
	}
    osStatus.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
    if (osStatus.hEvent == NULL) {
		TRACE("Error creating Status Event");
        thePort->ErrorInComm("CreateEvent (Status Event)");
	}
    //
    //   We want to detect the following events:
    //   Read events (from ReadFile)
    //   Status events (from WaitCommEvent)
    //   Status message events (from our MessageReporter)
    //   Thread exit events (from our shutdown functions)
    //
    hArray[0] = osReader.hEvent;
    hArray[1] = osStatus.hEvent;
    hArray[2] = thePort->ghThreadExitEvent;
//    hArray[2] = thePort->ghStatusMessageEvent;
//    hArray[3] = thePort->ghThreadExitEvent;

    // initialize our thread local storage
	// we want to put a COMSTAT into m_TlsComStat and 
	LPVOID tmpPointer = malloc(sizeof(COMSTAT));
	if (tmpPointer == NULL) {
		  TRACE("Internal Memory allocation error\r\n");
		return 1;
	}
	TlsSetValue(thePort->m_TlsLastComStat, tmpPointer);
	tmpPointer = NULL;
	tmpPointer = TlsGetValue(thePort->m_TlsLastComStat);

    //
    // initial check, forces updates
    //
	// TRACE("chkmdmst...");
    thePort->CheckModemStatus(TRUE);
	// TRACE("done\r\n");
	// TRACE("chkcomst...");
    thePort->CheckComStat(TRUE);
	// TRACE("done\r\n");
	TRACE("Monitor thread initialized\r\n");
	thePort->m_nStatus ^= P_STATUS_NOMONITORTHREAD;
    while ( !fThreadDone ) {
        //
        // If no reading is allowed, then set flag to
        // make it look like a read is already outstanding.
        //
        if (thePort->ReadingDisabled()) {
            fWaitingOnRead = TRUE;
        }
        //
        // if no read is outstanding, then issue another one
        //
		int x;
        if (!fWaitingOnRead) {
			// TRACE("Issuing Read %d, %x\r\n", AMOUNT_TO_READ,thePort->GetComDev());
            if (!ReadFile(thePort->GetComDev(), lpBuf, AMOUNT_TO_READ, &dwRead, &osReader)) {
				x = GetLastError();
				// TRACE("GLErr = %x\r\n",x);
                if ( x != ERROR_IO_PENDING) {	  // read not delayed?
                    thePort->ErrorInComm("ReadFile in ReaderAndStatusProc");
				}
                fWaitingOnRead = TRUE;
            } else {    // read completed immediately
				TRACE("Read completed immediately\r\n");
/*
              if ((dwRead != MAX_READ_BUFFER) && thePort->ShowTimeouts()) {
				TRACE("Read timed out immediately\r\n");
               // thePort->TRACE("Read timed out immediately.\r\n");
			  }
*/
              if (dwRead) {
			 	// TRACE("%d Bytes received\r\n", dwRead);
                thePort->ProcessReceivedData(lpBuf, dwRead);
			  }
            } // end of else read completed
        } // end if not waiting on read

        //
        // If status flags have changed, then reset comm mask.
        // This will cause a pending WaitCommEvent to complete
        // and the resultant event flag will be NULL.
        //
		if (dwStoredFlags != thePort->GetEventFlags()) {
            dwStoredFlags = thePort->GetEventFlags();
			// TRACE("IssueSetCommMask [%x] [%x]\r\n", dwStoredFlags, thePort->GetEventFlags());
            if (!SetCommMask(thePort->GetComDev(), dwStoredFlags)) {
				thePort->ErrorReporter("SetCommMask");
			}
        }
		// CommMask should be 1F8 (default - 0x00000101
        //
        // If event checks are not allowed, then make it look
        // like an event check operation is outstanding
        //
        if (thePort->EventsDisabled()) {
			fWaitingOnStat = TRUE;
		}
        //
        // if no status check is outstanding, then issue another one
        //
        if (!fWaitingOnStat) {
            if (thePort->EventsDisabled())
                fWaitingOnStat = TRUE;
            else {
                if (!WaitCommEvent(thePort->GetComDev(), &dwCommEvent, &osStatus)) {
                    if (GetLastError() != ERROR_IO_PENDING)	  // Wait not delayed?
                        thePort->ErrorReporter("WaitCommEvent");
                    else
                        fWaitingOnStat = TRUE;
                }
                else
                    // WaitCommEvent returned immediately
                    thePort->ReportStatusEvent(dwCommEvent);
            }
        }

        //
        // wait for pending operations to complete
        //
        if ( fWaitingOnStat && fWaitingOnRead ) {
			
            dwRes = WaitForMultipleObjects(NUM_READSTAT_HANDLES, hArray, FALSE, STATUS_CHECK_TIMEOUT);
            switch(dwRes)
            {
                //
                // read completed
                //
                case WAIT_OBJECT_0:
					
                    if (!GetOverlappedResult(thePort->GetComDev(), &osReader, &dwRead, FALSE)) {
                        if (GetLastError() == ERROR_OPERATION_ABORTED)
                            TRACE("Read aborted\r\n");
                        else
                            thePort->ErrorInComm("GetOverlappedResult (in Reader)");
                    }
                    else {      // read completed successfully
						/*
                        if ((dwRead != MAX_READ_BUFFER) && thePort->ShowTimeouts())
                            TRACE("Read timed out overlapped.\r\n");
						*/
                        if (dwRead) {
							// TRACE("%d BYTES RECEIVED\r\n", dwRead);
							thePort->ProcessReceivedData(lpBuf, dwRead);
                            // thePort->OutputABuffer(lpBuf, dwRead);
						}
                    }
			
                    fWaitingOnRead = FALSE;
                    break;

                //
                // status completed
                //
                case WAIT_OBJECT_0 + 1: 
					
                    if (!GetOverlappedResult(thePort->GetComDev(), &osStatus, &dwOvRes, FALSE)) {
                        if (GetLastError() == ERROR_OPERATION_ABORTED)
                            TRACE("WaitCommEvent aborted\r\n");
                        else
                            thePort->ErrorInComm("GetOverlappedResult (in Reader)");
                    }
                    else       // status check completed successfully
                        thePort->ReportStatusEvent(dwCommEvent);

                    fWaitingOnStat = FALSE;
                    break;

                //
                // status message event
                //
                case WAIT_OBJECT_0 + 2:
					// TRACE("Status message event\r\n");
                    //thePort->StatusMessage();
//                    break;
//
//                //
//                // thread exit event
//                //
//                case WAIT_OBJECT_0 + 3:
					TRACE("Thread exit event");
                    fThreadDone = TRUE;
                    break;

                case WAIT_TIMEOUT:
                    //
                    // timeouts are not reported because they happen too often
                    // OutputDebugString("Timeout in Reader & Status checking\n\r");
                    //
                    //
                    // if status checks are not allowed, then don't issue the
                    // modem status check nor the com stat check
                    //

                    if (!thePort->StatusDisabled()) {
                        thePort->CheckModemStatus(FALSE);    // take this opportunity to do
						DWORD dwRealMask;
						GetCommMask(thePort->GetComDev(),&dwRealMask);
                        thePort->CheckComStat(FALSE);        //   a modem status check and
                                                    //   a comm status check
                    }

                    break;                       

                default:
                    thePort->ErrorReporter("WaitForMultipleObjects(Reader & Status handles)");
                    break;
            }
        }
    }

    //
    // close event handles
    //
    CloseHandle(osReader.hEvent);
    CloseHandle(osStatus.hEvent);
    
	// free our ThreadLocalStorage
	free(TlsGetValue(thePort->m_TlsLastComStat));
    
	return 0;
} // end of MyMonitorThreadProc

/*----------------------------------------------------------------------------
FUNCTION: WaitForThreads(PORT *)

PURPOSE: Waits a specified time for the worker threads to exit

PARAMETERS:
    dwTimeout - milliseconds to wait until timeout

RETURN:
    WAIT_OBJECT_0 - successful wait, threads are not running
    WAIT_TIMEOUT  - at least one thread is still running
    WAIT_FAILED   - failure in WaitForMultipleObjects

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it

----------------------------------------------------------------------------*/

DWORD WaitForThreads(Port * thePort)
{	
    HANDLE hThreads[2];
    DWORD  dwRes;
	DWORD dwTimeout = 20000;
    hThreads[0] = thePort->GetMonitorThreadHandle();
    hThreads[1] = thePort->GetWriterThreadHandle();

    //
    // set thread exit event here
    //
	TRACE("Waiting for threads...\r\n");
    SetEvent(thePort->ghThreadExitEvent);

    dwRes = WaitForMultipleObjects(2, hThreads, TRUE, dwTimeout);
    switch(dwRes)
    {
        case WAIT_OBJECT_0:
			
        case WAIT_OBJECT_0 + 1: 
			
            dwRes = WAIT_OBJECT_0;
            break;

        case WAIT_TIMEOUT:
            // TRACE("Wait timeout\r\n");
            if (WaitForSingleObject(thePort->GetMonitorThreadHandle(), 0) == WAIT_TIMEOUT)
                TRACE("Reader/Status Thread didn't exit.\n\r");

            if (WaitForSingleObject(thePort->GetWriterThreadHandle(), 0) == WAIT_TIMEOUT)
                TRACE("Writer Thread didn't exit.\n\r");

            break;

        default:
            thePort->ErrorReporter("WaitForMultipleObjects");
			TRACE("WaitForMultipleObjects returning %d Last Error[%d]", dwRes, GetLastError());
            break;
    }

    //
    // reset thread exit event here
    //
    ResetEvent(thePort->ghThreadExitEvent);

    return dwRes;
}


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Port::Port(CPortHandler * myHandler)
{
	if (myHandler == NULL) {
		return;
	}
	TRACE("Port constructor called\r\n");
	if (strcmp(myHandler->signature,"PortHandler") == 0) {
		TRACE("Port::Port Valid Port handler supplied\r\n");
		m_myPortHandler = myHandler;
	} else {
		TRACE("Port::Port INVALID Port handler supplied\r\n");
		return;
	} // end else
	InitConstructor();
}

Port::~Port()
{
 TRACE("Port Destructor called for %s", m_szName);	
 TRACE("Delete critical sections ");	
 DeleteCriticalSection(&gStatusCritical); // from initializecriticalsection
 DeleteCriticalSection(&gcsWriterHeap);// from initializecriticalsection
 TRACE("Close Handles ");	
 //CloseHandle(ghStatusMessageEvent);	 // from createevent
 CloseHandle(ghThreadExitEvent);     // from createevent
 TRACE("Destroy Heap ");	
// HeapDestroy(ghStatusMessageHeap);  // from heapcreate

 // free the TLS handles
 TlsFree(m_TlsLastComStat);
 TlsFree(m_TlsLastError);
 TlsFree(m_TlsLastStatus);
 TRACE("End of constructor ");	
} // end of destructor

void Port::InitConstructor()
{

 // Initially, the threads won't have started
 m_nStatus = (P_STATUS_NOWRITETHREAD | P_STATUS_NOMONITORTHREAD);
 SetConnected(FALSE); // we are not yet connected
 // TRACE("Configuring default parameters\r\n");
 SetCTSOutFlow(FALSE);
 SetDSROutFlow(FALSE);
 SetDSRInFlow(FALSE);
 SetXONXOFFOutFlow(FALSE);
 SetXONXOFFInFlow(FALSE);
 SetTXAFTERXOFFSENT(FALSE);

 DisableReading(FALSE);
 DisableWriting(FALSE);
 DisableEvents(FALSE);
 DisableStatus(FALSE);
// SetShowTimeouts(FALSE);

 InitializeCriticalSection(&gStatusCritical);
 InitializeCriticalSection(&gcsWriterHeap);
 //
 // status message event
 //
//  ghStatusMessageEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
//    if (ghStatusMessageEvent == NULL)
//        ErrorReporter("CreateEvent (Status message event)");

//  InitStatusMessage();
 //
 // Thread exit event
 //
  ghThreadExitEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
  
  if (ghThreadExitEvent == NULL)
        ErrorReporter("CreateEvent (Thread exit event)");        
  // allocate thread local storage - DLL's (i.e. OCX's complain if we use old-style thread static)
  m_TlsLastComStat = TlsAlloc();
  m_TlsLastError = TlsAlloc();
  m_TlsLastStatus = TlsAlloc();
 }

//////////////////////////////////////////
// SetupCommPort
HANDLE Port::SetupCommPort()
{
    //
    // open communication port handle
    //
	// TRACE("Creating com port file\n");
	char tmpBuf[100];
	sprintf(tmpBuf,"Creating Com Port File %s\r\n", GetName());
	TRACE(tmpBuf);
    SetComDev(CreateFile(  GetName(),  
                                      GENERIC_READ | GENERIC_WRITE, 
                                      0, 
                                      0, 
                                      OPEN_EXISTING,
                                      FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED,
                                      0));
	// TRACE("File created\n");
	// TRACE("Handle is : %lx", GetComDev());
    if (GetComDev() == INVALID_HANDLE_VALUE) {   
        ErrorReporter("CreateFile returned invalid handle");
        return NULL;
    }

    //
    // Save original comm timeouts and set new ones
    //
	// TRACE("Setting CommTimeouts\n");
	
	COMMTIMEOUTS tmpTimeouts;
    if (!GetCommTimeouts( GetComDev(), &tmpTimeouts)) {
		SetOrigTimeouts(tmpTimeouts);		
		// TIMEOUTSORIG
        ErrorReporter("GetCommTimeouts");
	}
	SetOrigTimeouts(tmpTimeouts);
    //
    // Set port state
    //
	// TRACE("Calling UpdateConnection\n");
    UpdateConnection();
	// TRACE("Calling SetupComm\n");
    //
    // set comm buffer sizes
    //
    SetupComm(GetComDev(), MAX_READ_BUFFER, MAX_WRITE_BUFFER);
	
	// these are specific to callscape, should really be done by CallScapeHW object
    //
    // raise DTR
    //
	TRACE("Calling EscapeCommFunction to raise DTR\n");
    if (!EscapeCommFunction(GetComDev(), SETDTR)) {
        ErrorReporter("EscapeCommFunction (SETDTR)");
	} // endif

	//
    // clear RTS
    //
	TRACE("Calling EscapeCommFunction to clear RTS\n");
    if (!EscapeCommFunction(GetComDev(), CLRRTS)) {
        ErrorReporter("EscapeCommFunction (CLRRTS)");
	} // endif

    //
    // start threads and set initial thread state to not done
    //
	TRACE("Starting threads");
    StartThreads();
	
    
    //
    // set overall connect flag
    //
    SetConnected(TRUE); // CONNECTED( m_ttyInfo ) = TRUE ;
	
    return GetComDev();
	
} // SetupCommPort

//////////////////////////////////////////
// UpdateConnection
int Port::UpdateConnection()
{
    
	DCB dcb = {0};
    
    dcb.DCBlength = sizeof(dcb);
    // TRACE("Setting Comm properties\r\n");
    //
    // get current DCB settings
    //
    if (!GetCommState(GetComDev(), &dcb)) {
	   ErrorReporter("GetCommState");
	}
	//
    // update DCB rate, byte size, parity, and stop bits size
    //
    dcb.BaudRate = GetBaudRate();
    dcb.ByteSize = GetByteSize();
    dcb.Parity   = GetParity();
    dcb.StopBits = GetStopBits();

    //
    // update event flags
    //
    if (GetEventFlags() & EV_RXFLAG) {
	  // TRACE("Setting RXFlag ");
	  dcb.EvtChar = GetFlagChar();
	} else {
	  dcb.EvtChar = '\0';
	}
    //
    // update flow control settings
    //
    dcb.fDtrControl     = GetDTRControl();
    dcb.fRtsControl     = GetRTSControl();

    dcb.fOutxCtsFlow    = GetCTSOutFlow();
    dcb.fOutxDsrFlow    = GetDSROutFlow();
    dcb.fDsrSensitivity = GetDSRInFlow();
    dcb.fOutX           = GetXONXOFFOutFlow();
    dcb.fInX            = GetXONXOFFInFlow();
    dcb.fTXContinueOnXoff = GetTXAFTERXOFFSENT();
    dcb.XonChar         = GetXONChar();
    dcb.XoffChar        = GetXOFFChar();
    dcb.XonLim          = GetXONLimit();
    dcb.XoffLim         = GetXOFFLimit();

    //
    // DCB settings not in the user's control
    //
    dcb.fParity = TRUE;
	dcb.fBinary = TRUE;
    //
    // set new state
    //
    if (!SetCommState(GetComDev(), &dcb)) {
		TRACE("Error SetCommState");
	   ErrorReporter("SetCommState");
	}
    //
    // set new timeouts
    //
	// TRACE("Setting CommTimeouts for %d", GetComDev());
	COMMTIMEOUTS tmpTimeouts;
	tmpTimeouts = GetTimeouts();
    if (!SetCommTimeouts(GetComDev(), &tmpTimeouts)) {
		SetTimeouts(tmpTimeouts);
    	TRACE("Error SetCommTimeouts");
	    ErrorReporter("SetCommTimeouts");
	}
	SetTimeouts(tmpTimeouts);
    return P_OK;
} // end of UpdateConnection

/*
FUNCTION: BreakDownCommPort

PURPOSE: Closes a connection to a comm port

RETURN:
    P_OK  - successful breakdown of port
    P_ERR_PORTDISCONNECTED - port isn't connected

COMMENTS: Waits for threads to exit,
          clears DTR, restores comm port timeouts, purges any i/o
          and closes all pertinent handles

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it

-----------------------------------------------------------------------------*/
int Port::BreakDownCommPort()
{
	TRACE("SHUTTING DOWN com port\r\n");
    if (!IsConnected()) {
		TRACE("Not connected");
        return P_ERR_DISCONNECTED;
	}
    SetConnected(FALSE);
	// TRACE("\r\nnow in BreakDownCommPort\r\n");
    //
    // wait for the threads for a small period
    //
	// kill the threads
	TRACE("Wait for threads...\r\n");
	if (WaitForThreads(this) != WAIT_OBJECT_0) {
      /*  
            if threads haven't exited, then they will
            interfere with a new connection.  I must abort
            the entire program.
       */ 
	    TRACE("Error closing port from WaitForThreads");
        ErrorHandler("Error closing port.\r\n");
	}    
    //
    // lower DTR
    //
	TRACE("Lower DTR\r\n");
    if (!EscapeCommFunction(GetComDev(), CLRDTR)) {
        ErrorReporter("EscapeCommFunction(CLRDTR)");
	}
    //
    // restore original comm timeouts
    //
	// TRACE("Restoring timeouts\r\n");
	COMMTIMEOUTS tmpTimeouts;
	tmpTimeouts = GetOrigTimeouts();
    if (!SetCommTimeouts(GetComDev(), &tmpTimeouts)) {
        ErrorReporter("SetCommTimeouts (Restoration to original)");
	}
    //
    // Purge reads/writes, input buffer and output buffer
    //
	// TRACE("PurgingComm\r\n");
    if (!PurgeComm(GetComDev(), PURGE_FLAGS)) {
        ErrorReporter("PurgeComm");
	}
	TRACE("Closing handles\r\n");
    CloseHandle(GetComDev());
    CloseHandle(GetMonitorThreadHandle());
    CloseHandle(GetWriterThreadHandle());
	TRACE("Done - returning TRUE\r\n");
    return P_OK;
} // BreakDownComPort
////////////////////////////////////////////////////////
//
void Port::ErrorReporter(PCHAR message)
{
	// pass the message upwards
	EnterCriticalSection(&gStatusCritical);
	m_myPortHandler->HandlePortError(message);
	LeaveCriticalSection(&gStatusCritical);
} // end of ErrorReporter

////////////////////////////////////////////////////////
//
#if 0
void Port::MessageReporter(PCHAR message)
{
//	if (m_LogWindow==NULL) return;
	EnterCriticalSection(&gStatusCritical);
//	m_LogWindow->SetSel(-1,-1); // no selection
//	m_LogWindow->ReplaceSel(message, FALSE);
	LeaveCriticalSection(&gStatusCritical);
} // end of MessageReporter
////////////////////////////////////////////////////////
//
void Port::IncomingDataReporter(PCHAR message)
{
//	if (m_RxWindow==NULL) return;
	EnterCriticalSection(&gStatusCritical);
//	m_RxWindow->SetSel(-1,-1); // no selection
//	m_RxWindow->ReplaceSel(message, FALSE);
	LeaveCriticalSection(&gStatusCritical);

} // end of ErrorReporter
#endif

void Port::ErrorHandler(PCHAR message)
{
	ErrorReporter(message);
	delete this;
	ExitProcess(0);
} // end ErrorHandler
/*-----------------------------------------------------------------------------

FUNCTION: ErrorInComm( char * )

PURPOSE: Handle a fatal error after comm port is opened

PARAMETERS:
    szMessage - Error message from app

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it

-----------------------------------------------------------------------------*/
void Port::ErrorInComm(char * szMessage)
{
    ErrorReporter(szMessage);
    BreakDownCommPort();
    ExitProcess(0);
}
/*-----------------------------------------------------------------------------

FUNCTION: HandleWriteRequests

PURPOSE: Retrieves write request and calls the proper function
         depending on the write request type.

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it

            5/25/96   AllenD      Modified to include

-----------------------------------------------------------------------------*/
void Port::HandleWriteRequests()
{
    PWRITEREQUEST pWrite;
    
    pWrite = gpWriterHead->pNext;
    
    while(pWrite != gpWriterTail) {
        switch(pWrite->dwWriteType)
        {
            case WRITE_CHAR:          WriterChar(pWrite);                break;

//            case WRITE_FILESTART:     WriterFileStart(pWrite->dwSize);   break;
/*
            case WRITE_FILE:          WriterFile(pWrite);
                                      //
                                      // free data block
                                      //
                                      EnterCriticalSection(&gcsDataHeap);
                                      fRes = HeapFree(pWrite->hHeap, 0, pWrite->lpBuf);
                                      LeaveCriticalSection(&gcsDataHeap);
                                      if (!fRes)
                                          ErrorReporter("HeapFree(file transfer buffer)");
                                      break;

            case WRITE_FILEEND:       WriterComplete();                 break;

            case WRITE_ABORT:         WriterAbort(pWrite);              break;
*/
            case WRITE_BLOCK:         WriterBlock(pWrite);              break;

            default:                  ErrorReporter("Bad write request"); 
                                      break;
        }

        //
        // remove current node and get next node
        //
        pWrite = RemoveFromLinkedList(pWrite);
        pWrite = gpWriterHead->pNext;
    }

    return;
}

/*-----------------------------------------------------------------------------

FUNCTION: WriterComplete

PURPOSE: Handle an transfer completion

HISTORY:   Date:      Author:     Comment:
            1/26/96   AllenD      Wrote it

-----------------------------------------------------------------------------*/
void Port::WriterComplete()
{
//    if (!SetEvent(ghTransferCompleteEvent))
//        ErrorReporter("SetEvent (transfer complete event)");

    return;
}

/*-----------------------------------------------------------------------------

FUNCTION: WriterAbort

PURPOSE: Handle an transfer abort.  Delete all writer packets.
         Data packets get deleted with the entire data heap in the transfer
         thread.

HISTORY:   Date:      Author:     Comment:
            1/26/96   AllenD      Wrote it

-----------------------------------------------------------------------------*/
void Port::WriterAbort(PWRITEREQUEST pAbortNode)
{
    PWRITEREQUEST pCurrent;
    PWRITEREQUEST pNextNode;
    BOOL fRes;
    int i = 0;
    char szMessage[30];

    EnterCriticalSection(&gcsWriterHeap);
    // remove all nodes after me
    pCurrent = pAbortNode->pNext;

    while (pCurrent != gpWriterTail) {
        pNextNode = pCurrent->pNext;
        fRes = HeapFree(ghWriterHeap, 0, pCurrent);
        if (!fRes)
            break;
        i++;
        pCurrent = pNextNode;
    }

    pAbortNode->pNext = gpWriterTail;
    gpWriterTail->pPrev = pAbortNode;
    LeaveCriticalSection(&gcsWriterHeap);

    sprintf(szMessage, "%d packets ignored.\n", i);
    OutputDebugString(szMessage);

    if (!fRes)
        ErrorReporter("HeapFree (Writer heap)");

//    if (!SetEvent(ghTransferCompleteEvent))
//        ErrorReporter("SetEvent (transfer complete event)");

    return;
} // end
/*-----------------------------------------------------------------------------

FUNCTION: WriterBlock(PWRITEREQUEST)

PURPOSE: Sends a block of characters

PARAMETERS:
    pWrite - pointer to write request packet

COMMENTS: WRITEREQUEST packet contains the following:
            lpBuf       : Address of data buffer
            dwSize      : size of data buffer

HISTORY:   Date:      Author:     Comment:
            1/29/96   AllenD      Wrote it

-----------------------------------------------------------------------------*/
void Port::WriterBlock(PWRITEREQUEST pWrite)
{   

    WriterGeneric((PBYTE) pWrite->lpBuf, pWrite->dwSize);
    return;
}


/*-----------------------------------------------------------------------------

FUNCTION: WriterChar(PWRITEREQUEST)

PURPOSE: Handles sending characters

PARAMETER:
    pWrite - pointer to write request packet

COMMENTS: WRITEREQUEST packet contains the following:
            ch : character to send

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it

-----------------------------------------------------------------------------*/
void Port::WriterChar(PWRITEREQUEST pWrite)
{
    WriterGeneric((PBYTE) &(pWrite->ch), 1);
    return;
}
/*-----------------------------------------------------------------------------

FUNCTION: TxData(char *)

PURPOSE: Handles sending normal buffer

PARAMETER:
    lpBuf     - pointer to data buffer
    
HISTORY:   Date:      Author:     Comment:
           21/01/99   ARH	      Ripped from AllenD, who Wroteit

-----------------------------------------------------------------------------*/
BOOL Port::TxData(PBYTE lpBuf, DWORD dwNumBytes)
{
   // this is a flaky solution, but simpler to acheive for now
	BOOL bResult = TRUE;
	// TRACE ("TxData %d bytes >>%s<<\r\n", dwNumBytes, lpBuf);
	if (*lpBuf == 0) return false;
	char tmp[256]; // bodge
	sprintf(tmp, "%s", lpBuf); 
	/*
	DWORD dwRequestType, 
                        DWORD dwSize, 
                        char ch, 
                        char * lpBuf, 
                        HANDLE hHeap, 
                        HWND hProgress
	*/
	bResult = WriterAddNewNode(WRITE_BLOCK, dwNumBytes, NULL, (char *) lpBuf, NULL, NULL);
	/*
	DWORD dwOffset = 0;
	while( (dwOffset < dwNumBytes) && bResult) {// while there are chars to send
		bResult = WriterAddNewNode(WRITE_CHAR, 0, (char) lpBuf[dwOffset], NULL, NULL, NULL);
		dwOffset++; // next char
    } // end while
	*/
	if (!bResult)
		TRACE("*** Write FAILED ***\r\n");
	
	return bResult;    
}
/*-----------------------------------------------------------------------------

FUNCTION: WriterGeneric(char *, DWORD)

PURPOSE: Handles sending all types of data

PARAMETER:
    lpBuf     - pointer to data buffer
    dwToWrite - size of buffer

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it

-----------------------------------------------------------------------------*/
void Port::WriterGeneric(PBYTE lpBuf, DWORD dwToWrite)
{
    OVERLAPPED osWrite = {0};
    HANDLE hArray[2];
    DWORD dwWritten;
    DWORD dwRes;

    //
    // If no writing is allowed, then just return
    //
    if (WritingDisabled()) {
		TRACE("NO Writing - returning\r\n");
        return ;
	}

    //
    // create this writes overlapped structure hEvent
    //
    osWrite.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
    if (osWrite.hEvent == NULL)
        ErrorInComm("CreateEvent (overlapped write hEvent)");

    hArray[0] = osWrite.hEvent;
    hArray[1] = ghThreadExitEvent;
    
    //
    // issue write
    //
	// TRACE("Writing %d chars >>%s<<[%x]\r\n", dwToWrite, (char *) lpBuf, lpBuf[0]);
    if (!WriteFile(GetComDev(), lpBuf, dwToWrite, &dwWritten, &osWrite)) {
        if (GetLastError() == ERROR_IO_PENDING) { 
            //
            // write is delayed
            //
            dwRes = WaitForMultipleObjects(2, hArray, FALSE, INFINITE);
            switch(dwRes)
            {
                //
                // write event set
                //
                case WAIT_OBJECT_0:
                            SetLastError(ERROR_SUCCESS);
                            if (!GetOverlappedResult(GetComDev(), &osWrite, &dwWritten, FALSE)) {
                                if (GetLastError() == ERROR_OPERATION_ABORTED)
                                    TRACE("Write aborted\r\n");
                                else
                                    ErrorInComm("GetOverlappedResult(in Writer)");
                            }
                            
                            if (dwWritten != dwToWrite) {
								// Some data didn't get transmitted                                
								if (GetLastError() != ERROR_SUCCESS) {
                                    ErrorReporter("Error writing data to port (overlapped)");
									TRACE("Error writing to port\r\n");
								} // endif error
                            } // endif dwWritten != dwToWrite
                            break;

                //
                // thread exit event set
                //
                case WAIT_OBJECT_0 + 1:
                            break;

                //                
                // wait timed out
                //
                case WAIT_TIMEOUT:
                            TRACE("Wait Timeout in WriterGeneric.\r\n");
                            break;

                case WAIT_FAILED:
                default:    ErrorInComm("WaitForMultipleObjects (WriterGeneric)");
                            break;
            }
        }
        else    
            //
            // writefile failed, but it isn't delayed
            //
            ErrorInComm("WriteFile (in Writer)");
    }
    else {
        //
        // writefile returned immediately
        //
        if (dwWritten != dwToWrite)  TRACE("Write timed out. (immediate)\r\n");
    }

    CloseHandle(osWrite.hEvent);
    
    return;
}

/*-----------------------------------------------------------------------------

FUNCTION: WriterAddNewNode(DWORD, DWORD, char, char *, HANDLE, HWND)

PURPOSE: Adds a new write request packet

PARAMETERS:
    dwRequestType - write request packet request type
    dwSize        - size of write request
    ch            - character to write
    lpBuf         - address of buffer to write
    hHeap         - heap handle of data buffer
    hProgress     - hwnd of transfer progress bar

RETURN:
    TRUE if node is added to linked list
    FALSE if node can't be allocated.

COMMENTS: Allocates a new packet and fills it based on the
          parameters passed in.

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it

-----------------------------------------------------------------------------*/
BOOL Port::WriterAddNewNode(  DWORD dwRequestType, 
                        DWORD dwSize, 
                        char ch, 
                        char * lpBuf, 
                        HANDLE hHeap, 
                        HWND hProgress)
{
    PWRITEREQUEST pWrite;

    //
    // allocate new packet
    //
	int sizewr = sizeof(WRITEREQUEST);
    pWrite = (WRITEREQUEST *) HeapAlloc(ghWriterHeap, 0, sizeof(WRITEREQUEST));
    if (pWrite == NULL) {
        ErrorReporter("HeapAlloc (writer packet)");
		TRACE("pWrite == NULL in AddToLinkedList\r\n");
        return FALSE;
    }

    //
    // assign packet info
    //
    pWrite->dwWriteType  = dwRequestType;
    pWrite->dwSize       = dwSize;
    pWrite->ch           = ch;
    pWrite->lpBuf        = lpBuf;
    pWrite->hHeap        = hHeap;
    pWrite->hWndProgress = hProgress;

    AddToLinkedList(pWrite);
    
    return TRUE;
}

/*-----------------------------------------------------------------------------

FUNCTION: WriterAddNewNodeTimeout(DWORD, DWORD, char, char *, 
                                    HANDLE, HWND, DWORD)

PURPOSE: Adds a new write request packet, timesout if can't allocate packet.

PARAMETERS:
    dwRequestType - write request packet request type
    dwSize        - size of write request
    ch            - character to write
    lpBuf         - address of buffer to write
    hHeap         - heap handle of data buffer
    hProgress     - hwnd of transfer progress bar
    dwTimeout     - timeout value for waiting

RETURN:
    TRUE if node is added to linked list
    FALSE if node can't be allocated.

COMMENTS: Allocates a new packet and fills it based on the
          parameters passed in.  If the first attemp to allocate packet
          fails, then the function sleeps and tries again when it resumes.

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it

-----------------------------------------------------------------------------*/
BOOL Port::WriterAddNewNodeTimeout(   DWORD dwRequestType, 
                                DWORD dwSize, 
                                char ch, 
                                char * lpBuf, 
                                HANDLE hHeap, 
                                HWND hProgress,
                                DWORD dwTimeout  )
{
    PWRITEREQUEST pWrite;

    //
    // attempt first allocation
    //
    pWrite = (WRITEREQUEST *) HeapAlloc(ghWriterHeap, 0, sizeof(WRITEREQUEST));
    if (pWrite == NULL) {
        Sleep(dwTimeout);
        //
        // attempt second allocation
        //
        pWrite = (WRITEREQUEST *) HeapAlloc(ghWriterHeap, 0, sizeof(WRITEREQUEST));
        if (pWrite == NULL) {
            ErrorReporter("HeapAlloc (writer packet)");
            return FALSE;
        }
    }

    //
    // assign packet info
    //
    pWrite->dwWriteType  = dwRequestType;
    pWrite->dwSize       = dwSize;
    pWrite->ch           = ch;
    pWrite->lpBuf        = lpBuf;
    pWrite->hHeap        = hHeap;
    pWrite->hWndProgress = hProgress;

    AddToLinkedList(pWrite);
    
    return TRUE;
}

/*-----------------------------------------------------------------------------

FUNCTION: WriterAddFirstNodeTimeout(DWORD, DWORD, char, char *, 
                                    HANDLE, HWND, DWORD)

PURPOSE: Adds a new write request packet and places it at the front of the 
         list, timesout if can't allocate packet.

PARAMETERS:
    dwRequestType - write request packet request type
    dwSize        - size of write request
    ch            - character to write
    lpBuf         - address of buffer to write
    hHeap         - heap handle of data buffer
    hProgress     - hwnd of transfer progress bar
    dwTimeout     - timeout value for waiting

RETURN:
    TRUE if node is added to linked list
    FALSE if node can't be allocated.

COMMENTS: This function differs from WriterAddNewNodeTimeout only in that
          it places the node at the front of the list.

HISTORY:   Date:      Author:     Comment:
            1/26/96   AllenD      Wrote it

-----------------------------------------------------------------------------*/
BOOL Port::WriterAddFirstNodeTimeout(   DWORD dwRequestType, 
                                DWORD dwSize, 
                                char ch, 
                                char * lpBuf, 
                                HANDLE hHeap, 
                                HWND hProgress,
                                DWORD dwTimeout  )
{
    PWRITEREQUEST pWrite;

    //
    // attempt first allocation
    //
    pWrite = (WRITEREQUEST *) HeapAlloc(ghWriterHeap, 0, sizeof(WRITEREQUEST));
    if (pWrite == NULL) {
        Sleep(dwTimeout);
        //
        // attempt second allocation
        //
        pWrite = (WRITEREQUEST *) HeapAlloc(ghWriterHeap, 0, sizeof(WRITEREQUEST));
        if (pWrite == NULL) {
            ErrorReporter("HeapAlloc (writer packet)");
            return FALSE;
        }
    }

    //
    // assign packet info
    //
    pWrite->dwWriteType  = dwRequestType;
    pWrite->dwSize       = dwSize;
    pWrite->ch           = ch;
    pWrite->lpBuf        = lpBuf;
    pWrite->hHeap        = hHeap;
    pWrite->hWndProgress = hProgress;

    AddToFrontOfLinkedList(pWrite);
    
    return TRUE;
}


/*-----------------------------------------------------------------------------

FUNCTION: AddToLinkedList(PWRITEREQUEST)

PURPOSE: Adds a node to the write request linked list

PARAMETERS:
    pNode - pointer to write request packet to add to linked list

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it

-----------------------------------------------------------------------------*/
void Port::AddToLinkedList(PWRITEREQUEST pNode)
{
    PWRITEREQUEST pOldLast;
    //
    // add node to linked list
    //
    EnterCriticalSection(&gcsWriterHeap);

    pOldLast = gpWriterTail->pPrev;

    pNode->pNext = gpWriterTail;
    pNode->pPrev = pOldLast;

    pOldLast->pNext = pNode;
    gpWriterTail->pPrev = pNode;

    LeaveCriticalSection(&gcsWriterHeap);

    //
    // notify writer thread that a node has been added
    // 
	if (!SetEvent(ghWriterEvent))
        ErrorReporter("SetEvent( writer packet )");
    
    return;    
}

/*-----------------------------------------------------------------------------

FUNCTION: AddToFrontOfLinkedList(PWRITEREQUEST)

PURPOSE: Adds a node to the front of the write request linked list

PARAMETERS:
    pNode - pointer to write request packet to add to linked list

HISTORY:   Date:      Author:     Comment:
            1/26/96   AllenD      Wrote it

-----------------------------------------------------------------------------*/
void Port::AddToFrontOfLinkedList(PWRITEREQUEST pNode)
{
    PWRITEREQUEST pNextNode;
    //
    // add node to linked list
    //
    EnterCriticalSection(&gcsWriterHeap);

    pNextNode = gpWriterHead->pNext;
    
    pNextNode->pPrev = pNode;
    gpWriterHead->pNext = pNode;
    
    pNode->pNext = pNextNode;
    pNode->pPrev = gpWriterHead;

    LeaveCriticalSection(&gcsWriterHeap);

    //
    // notify writer thread that a node has been added
    // 
    if (!SetEvent(ghWriterEvent))
        ErrorReporter("SetEvent( writer packet )");
    
    return;    
}

/*-----------------------------------------------------------------------------

FUNCTION: RemoveFromLinkedList(PWRITEREQUEST)

PURPOSE: Deallocates the head node and makes the passed in node 
         the new head node.
         Sets the head node point to node just after the passed in node.
         Returns the node pointed to by the head node.

PARAMETERS:
    pNode - pointer to node to make the new head

RETURN:
    Pointer to next node.  This will be NULL if there are no
    more nodes in the list.

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it

-----------------------------------------------------------------------------*/
PWRITEREQUEST Port::RemoveFromLinkedList(PWRITEREQUEST pNode)
{
    PWRITEREQUEST pNextNode;
    PWRITEREQUEST pPrevNode;
    BOOL bRes;

    EnterCriticalSection(&gcsWriterHeap);
    
    pNextNode = pNode->pNext;
    pPrevNode = pNode->pPrev;    
    
    bRes = HeapFree(ghWriterHeap, 0, pNode);
    
    pPrevNode->pNext = pNextNode;
    pNextNode->pPrev = pPrevNode;

    LeaveCriticalSection(&gcsWriterHeap);

    if (!bRes)
        ErrorReporter("HeapFree(write request)");

    return pNextNode;     // return the freed node's pNext (maybe the tail)
}
/*-----------------------------------------------------------------------------
FUNCTION: CheckModemStatus(BOOL)

PURPOSE: Check new status and possibly report it

PARAMETERS:
    bUpdateNow - if TRUE, update should be done
                 if FALSE, update is done only if status is different

COMMENTS: Reports status if bUpdateNow is true or
          new status is different from old status

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it

-----------------------------------------------------------------------------*/
void Port::CheckModemStatus( BOOL bUpdateNow )
{
    //
    // dwOldStatus needs to be static so that it is maintained 
    // between function calls by the same thread.
    // It also needs to be __declspec(thread) so that it is 
    // initialized when a new thread is created.
    //

    // __declspec(thread) static DWORD dwOldStatus = 0; 
	
	
	// this makes it thread local
	
    DWORD dwNewModemStatus;

    if (!GetCommModemStatus(GetComDev(), &dwNewModemStatus))
        ErrorReporter("GetCommModemStatus");
    //
    // Report status if bUpdateNow is true or status has changed
    //
    if (bUpdateNow || (dwNewModemStatus != (DWORD) TlsGetValue(m_TlsLastStatus))) {
        ReportModemStatus(dwNewModemStatus);
        // dwOldStatus = dwNewModemStatus;
		TlsSetValue(m_TlsLastStatus, (LPVOID) dwNewModemStatus); // put it in TLS
    }
	
    return;
}

/*-----------------------------------------------------------------------------

FUNCTION: CheckComStat(BOOL)

PURPOSE: Calls ClearCommError and reports the results.

PARAMETERS:
    bUpdateNow - If TRUE, then ReportComStat is called with new results.
                 if FALSE, then ReportComStat is called only if
                 new results differ from old.

COMMENTS: Called when the ReaderAndStatusProc times out after waiting on
          its event handles.  Also called from ReportStatusEvent.

HISTORY:   Date:      Author:     Comment:
           12/18/95   AllenD      Wrote it

-----------------------------------------------------------------------------*/
void Port::CheckComStat(BOOL bUpdateNow)
{
    COMSTAT ComStatNew;
    DWORD dwErrors;

    // __declspec(thread) static COMSTAT ComStatOld = {0};
    // __declspec(thread) static DWORD dwErrorsOld = 0;
	LPVOID tmpPointer = NULL;
	tmpPointer = TlsGetValue(m_TlsLastComStat);
	COMSTAT * pComStatOld = (COMSTAT *) tmpPointer; // we'll use our TLS
	// this pointer is to TLS, so we don't need to setvalue for comstat
	// errors are different though
    BOOL bReport = bUpdateNow;

    if (!ClearCommError(GetComDev(), &dwErrors, &ComStatNew))
        ErrorReporter("ClearCommError");

    if (dwErrors != (DWORD) TlsGetValue(m_TlsLastError)) {
        bReport = TRUE;
        // dwErrorsOld = dwErrors;
		TlsSetValue(m_TlsLastError, (LPVOID) dwErrors);
    }

    if (memcmp(pComStatOld, &ComStatNew, sizeof(COMSTAT))) {
        bReport = TRUE;
        memcpy(pComStatOld, &ComStatNew, sizeof(COMSTAT));
    }
    
    if (bReport)
        ReportComStat(ComStatNew);

    // ComStatOld = &ComStatNew;
	memcpy(pComStatOld, &ComStatNew, sizeof(COMSTAT));

    return;
}

/*-----------------------------------------------------------------------------

FUNCTION: ReportComStat( COMSTAT )

PURPOSE: Update status dialog controls based on the COMSTAT structure

PARAMETERS:
    ComStat - comstat structure used to update comm stat controls.  

HISTORY:   Date:      Author:     Comment:
           12/01/95   AllenD      Wrote it
           12/18/95   AllenD      Modified it

-----------------------------------------------------------------------------*/
void Port::ReportComStat(COMSTAT ComStat)
{
	return; // don't do anything at the moment
	if (ComStat.fCtsHold) 
		TRACE("CTS HOLD\r\n");
	else
		TRACE("NOT CTS HOLD\r\n");
    if (ComStat.fDsrHold)
		TRACE("DSR HOLD\r\n");
	else
		TRACE("NOT DSR HOLD\r\n");
	if (ComStat.fRlsdHold)
		TRACE("Rlsd HOLD\r\n");
	else
		TRACE("NOT Rlsd HOLD\r\n");
    if (ComStat.fXoffHold)
		TRACE("Xoff HOLD\r\n");
	else
		TRACE("NOT Xoff HOLD\r\n");
    if (ComStat.fXoffSent)
		TRACE("Xoff SENT\r\n");
	else
		TRACE("NOT Xoff SENT\r\n");
    if (ComStat.fEof)
		TRACE("fEof SET\r\n");
	else
		TRACE("NOT fEof SET\r\n");
	if (ComStat.fTxim)
		TRACE("fTxim SET\r\n");
	else
		TRACE("NOT fTxim SET\r\n");
    if (ComStat.cbOutQue)
		TRACE("cbOutQue SET\r\n");
	else
		TRACE("NOT cbOutQue SET\r\n");
	if (ComStat.cbInQue) {
		// TRACE("cbInQue = %d",ComStat.cbInQue);
		TRACE("cbInQue SET\r\n");
	}
	else
		TRACE("NOT cbInQue SET\r\n");
    return;
}

/*-----------------------------------------------------------------------------

FUNCTION: ProcessReceived(char *, DWORD)

PURPOSE: Deal with incoming data

PARAMETERS:
    lpBuf    - address of data buffer
    dwBufLen - size of data buffer

COMMENTS: If buffer is 0 length, then do nothing.

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it
		   21/01/98	  ARH		  Stole it from AllenD
-----------------------------------------------------------------------------*/
void Port::ProcessReceivedData(PBYTE lpBuf, DWORD dwBufLen)
{
    if (dwBufLen == 0) {
		TRACE("NULL Buffer in OutputABuffer\n\r");
        OutputDebugString("NULL Buffer in OutputABuffer\n\r");
        return;
    }
	PBYTE localbuf = NULL;
	localbuf = (PBYTE) malloc(dwBufLen*sizeof(BYTE));
	if (localbuf == NULL) {
		TRACE("Couldn't allocate memory");
	} else {

		memcpy(localbuf, lpBuf, dwBufLen);
		if (m_myPortHandler != NULL)
			m_myPortHandler->HandlePortEvent(EV_PORT_RXDATA, lpBuf, dwBufLen);
		free(localbuf);
	}
	// log the data
	// OutputABuffer(lpBuf, dwBufLen);	
	
    return;
} // end of ProcessReceivedData

/*-----------------------------------------------------------------------------

FUNCTION: OutputABuffer(char *, DWORD)

PURPOSE: Send a rec'd buffer to the approprate location

PARAMETERS:
    hTTY     - handle to the TTY child window
    lpBuf    - address of data buffer
    dwBufLen - size of data buffer

COMMENTS: If buffer is 0 length, then do nothing.

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it
		   21/01/98	  ARH		  Stole it from AllenD
-----------------------------------------------------------------------------*/
void Port::OutputABuffer(PBYTE lpBuf, DWORD dwBufLen)
{
    if (dwBufLen == 0) {
        OutputDebugString("NULL Buffer in OutputABuffer\n\r");
        return;
    }
	
    // OutputABufferToWindow(lpBuf, dwBufLen);
	// Send to m_TTYRxBuffer
	// no longer strings - use binary here....
	char tmpBuf[RXQ_SIZE];
	char tmpStr[5];
	// dynamic alloc data here
	if (dwBufLen > RXQ_SIZE) {
		TRACE("Too much data to print sensibly - returning");
		return;
	}
	memset(tmpBuf,0,RXQ_SIZE);
	DWORD i = 0;
	while (i < dwBufLen) {
		sprintf(tmpStr,"[%x]", lpBuf[i++]);
		strcat(tmpBuf,tmpStr );
	} // end char
	strcat(tmpBuf,"\r\n");
	// TRACE("\r\nReceived bytes = %s\r\n", tmpBuf);
	/*
	EnterCriticalSection(&gStatusCritical);
	m_RxWindow->SetSel(-1,-1); // no selection
	m_RxWindow->ReplaceSel(tmpBuf, FALSE);
	LeaveCriticalSection(&gStatusCritical);
	lpBuf[dwBufLen] = 0; // terminate the received string
	*/
	// IncomingDataReporter(lpBuf);
    
    return;
}


/*------------------------------------------------------------------------
FUNCTION: ReportStatusEvent(DWORD)

PURPOSE: Report a comm status event

PARAMETERS:
    dwStatus - status event flag from WaitCommEvent

COMMENTS: This is different than line status (aka Modem Status).

NOTE: EV_RING isn't detected on Windows 95.  This is a known problem.
      A workaround to the problem is to rely on GetCommModemStatus, or
      set the modem to send a "RING" and have the app detect it.

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it

/*-----------------------------------------------------------------------------*/
void Port::ReportStatusEvent(DWORD dwStatus)
{
    
    TRACE("EVENT: ");
    if ( dwStatus & EV_CTS ) TRACE ("CTS " );
    if ( dwStatus & EV_DSR ) TRACE ( "DSR " );
    if ( dwStatus & EV_ERR ) TRACE ( "ERR " );
    if ( dwStatus & EV_RING ) TRACE ( "RING " );
    if ( dwStatus & EV_RLSD ) TRACE ( "RLSD " );
    if ( dwStatus & EV_BREAK ) TRACE ( "BREAK " );
    if ( dwStatus & EV_RXFLAG ) TRACE ( "RXFLAG " );
    if ( dwStatus & EV_RXCHAR ) TRACE ( "RXCHAR " );
    if ( dwStatus & EV_TXEMPTY ) TRACE ( "TXEMPTY " );

    /*
        If dwStatus == NULL, then no status event flags are set.
        This happens when the event flag is changed with SetCommMask.
    */
    if (dwStatus == 0x0000)
        TRACE("NULL");

    TRACE("\r\n");

    
    /*
        If an error flag is set in the event flag, then
        report the error with the status message
        If not, then just report the comm status.
    */
    if (dwStatus & EV_ERR)
        ReportCommError();
    
    /*
        Might as well check the modem status and comm status now since
        the event may have been caused by a change in line status.
        Line status is indicated by the CheckModemStatus function.
    */
    CheckModemStatus( FALSE );

    /*
        Since line status can affect sending/receiving when 
        hardware flow-control is used, ReportComStat should 
        be called to show comm status.  This is called only if no error
        was reported in the event flag.  If an error was reported, then
        ReportCommError was called above and CheckComStat was already called
        in that function.
    */
    if (!(dwStatus & EV_ERR))
        CheckComStat( FALSE );

    return;
}

/*-----------------------------------------------------------------------------

FUNCTION: ReportCommError

PURPOSE: Calls ClearCommError and reports the results

COMMENTS: This function is called if EV_ERR occurs and is called
          when the ReaderAndStatusProc times out after waiting on
          its event handles.

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it

-----------------------------------------------------------------------------*/
void Port::ReportCommError()
{
    COMSTAT comStat;
    DWORD   dwErrors;

    //
    // Get and clear current errors on the port
    //
    if (!ClearCommError(GetComDev(), &dwErrors, &comStat))
        ErrorReporter("ClearCommError");

    //
    // get error flags
    //
    
   
    //
    // if there really were errors, then report them
    //
    if (dwErrors) {
      TRACE ("ERROR: ");
      if (dwErrors & CE_DNS ) TRACE("DNS " );
      if ( dwErrors & CE_IOE ) TRACE( "IOE " );
      if ( dwErrors & CE_OOP) TRACE( "OOP " );
      if ( dwErrors & CE_PTO ) TRACE( "PTO " );
      if ( dwErrors & CE_MODE ) TRACE( "MODE " );
      if ( dwErrors & CE_BREAK) TRACE( "BREAK " );
      if ( dwErrors & CE_FRAME ) TRACE( "FRAME " );
      if ( dwErrors & CE_RXOVER ) TRACE( "RXOVER " );
      if ( dwErrors & CE_TXFULL ) TRACE( "TXFULL ");
      if ( dwErrors & CE_OVERRUN ) TRACE( "OVERRUN ");
      if ( dwErrors & CE_RXPARITY ) TRACE( "RXPARITY ");

    }
    

    //
    // Report info from the COMSTAT structure
    //
    ReportComStat(comStat);

    //
    // Show COMSTAT structure with the error indicator
    //
    if (comStat.fCtsHold) TRACE("Tx waiting for CTS signal.\r\n");
    if (comStat.fDsrHold) TRACE("Tx waiting for DSR signal.\r\n");
    if (comStat.fRlsdHold) TRACE("Tx waiting for RLSD signal.\r\n");
    if (comStat.fXoffHold)  TRACE("Tx waiting, XOFF char rec'd.\r\n");
    if (comStat.fXoffSent)  TRACE("Tx waiting, XOFF char sent.\r\n");
    if (comStat.fEof)   TRACE("EOF character received.\r\n");
    if (comStat.fTxim)  TRACE("Character waiting for Tx.\r\n");
    if (comStat.cbInQue)  TRACE("%d bytes in input buffer.\r\n", comStat.cbInQue);
    if (comStat.cbOutQue)   TRACE("%d bytes in output buffer.\r\n", comStat.cbOutQue);

    return;
}
/*-----------------------------------------------------------------------------

FUNCTION: ReportModemStatus(DWORD)

PURPOSE: Reports modem status line states

PARAMETERS:
    dwModemStatus - current modem status flag

COMMENTS: Checks each button according to the state

HISTORY:   Date:      Author:     Comment:
           10/27/95   AllenD      Wrote it

-----------------------------------------------------------------------------*/
void Port::ReportModemStatus(DWORD dwModemStatus)
{
//	if (m_Stat_CTS != NULL)
//		m_Stat_CTS->SetCheck(MS_CTS_ON & dwModemStatus?1:0);
//	if (m_Stat_DSR != NULL)
//		m_Stat_DSR->SetCheck(MS_DSR_ON & dwModemStatus?1:0);
//	if (m_Stat_Ring != NULL)
//		m_Stat_Ring->SetCheck(MS_RING_ON & dwModemStatus?1:0);
//	if (m_Stat_RLSD != NULL)
//		m_Stat_RLSD->SetCheck(MS_RLSD_ON & dwModemStatus?1:0);
    return ; // don't trouble yourself - we don't care for the callscape
	if (MS_CTS_ON & dwModemStatus) {
		TRACE("MS_CTS_ON\r\n");
	} else {
		TRACE("MS_CTS_OFF\r\n");
	}
    if (MS_DSR_ON & dwModemStatus) {
		TRACE("MS_DSR_ON\r\n");
	} else {
		TRACE("MS_DSR_OFF\r\n");
    }
	if (MS_RING_ON & dwModemStatus) {
		TRACE("MS_RING_ON\r\n");
	} else {
		TRACE("MS_RING_OFF\r\n");
    }
	if (MS_RLSD_ON & dwModemStatus) {
		TRACE("MS_RLSD_ON\r\n");
	} else {
		TRACE("MS_RLSD_OFF\r\n");
	}
    return;
}

////
void Port::StartThreads()
{
	DWORD dwReadStatId;
    DWORD dwWriterId;
	TRACE("Starting threads");
	
    SetMonitorThreadHandle( 
            CreateThread( NULL, 
                          0,
                          (LPTHREAD_START_ROUTINE) MyMonitorThreadProc,
						  // (LPTHREAD_START_ROUTINE) ReaderAndStatusThreadProc,
                          (LPVOID) this, 
                          0, 
                          &dwReadStatId) );

    if (GetMonitorThreadHandle() == NULL)
      ErrorInComm("CreateThread(Reader/Status)");
	

    SetWriterThreadHandle(
            CreateThread( NULL, 
                          0, 
                          (LPTHREAD_START_ROUTINE) MyWriterThreadProc, 
                          (LPVOID) this, 
                          0, 
                          &dwWriterId ) );

    if (GetWriterThreadHandle() == NULL)
        ErrorInComm("Cannot CreateThread (Writer)");

    return;
} // end of StartThreads

// accessor and mutator functions

PCHAR  Port::GetName()
{
  return m_szName;
} // end of GetName

int Port::SetName(PCHAR sNewName)
{
	if (strlen(sNewName) < P_MAX_NAME_LEN) {
		strncpy(m_szName, sNewName, P_MAX_NAME_LEN);
		return P_OK;
	} else
		return P_ERR_NAMETOOLONG;
}

HANDLE Port::GetComDev()
{
  return hCommPort;
} // end of GetComDev

void Port::SetComDev(HANDLE hNewHandle)
{
  hCommPort = hNewHandle;
} // end of SetComDev

HANDLE Port::GetWriterThreadHandle()
{
  return hWriter;
} // end of GetWriterThreadHandle

void Port::SetWriterThreadHandle(HANDLE hNewHandle)
{
  hWriter = hNewHandle;
} // end of SetWriterThreadHandle

HANDLE Port::GetMonitorThreadHandle()
{
  return hReaderStatus;
} // end of GetMonitorThreadHandle

void Port::SetMonitorThreadHandle(HANDLE hNewHandle)
{
  hReaderStatus = hNewHandle;
} // end of SetMoniterThreadHandle


BOOL Port::IsConnected()
{
  return fConnected;
} // end of IsConnected 

void Port::SetConnected(BOOL bState)
{
  fConnected = bState;
} // end of SetConnected

BYTE Port::GetParity()
{
	return bParity;
} // end of GetParity

void Port::SetParity(BYTE bNewParity)
{
	bParity = bNewParity;
} // end of SetParity

BOOL Port::GetStopBits()
{
	return bStopBits;
} // end of GetStopBit

void Port::SetStopBits(BOOL bNewStop)
{
	bStopBits = bNewStop;
} // end of SetStopBit

DWORD Port::GetBaudRate()
{
	return dwBaudRate;
} // end of GetBaudRate

void Port::SetBaudRate(DWORD dwNewBaud)
{
	dwBaudRate = dwNewBaud;
} // end of SetBaudRate

DWORD Port::GetEventFlags()
{
	return dwEventFlags;
} // end of GetEventFlags

void Port::SetEventFlags(DWORD dwNewEventFlags)
{
	dwEventFlags = dwNewEventFlags;
} // end of SetEventFlags

BOOL Port::ReadingDisabled()
{
	return fNoReading;
} // end of ReadingDisabled

void Port::DisableReading(BOOL fNewReading)
{
	fNoReading = fNewReading;
} // end of DisableReading

BOOL Port::WritingDisabled()
{
	return fNoWriting;
} // end of WritingDisabled

void Port::DisableWriting(BOOL fNewWriting)
{
	fNoWriting = fNewWriting;
} // end of DisableWriting


BOOL Port::EventsDisabled()
{
	return fNoEvents;
} // end of EventsDisabled()

void Port::DisableEvents(BOOL fNewState)
{
	fNoEvents = fNewState;
} // end of DisableEvents

BOOL Port::StatusDisabled()
{
	return fNoStatus;
} // end of StatusDisabled

void Port::DisableStatus(BOOL fNewStatus)
{
	fNoStatus = fNewStatus;
} // end of DisableStatus
/*
BOOL Port::ShowTimeouts()
{
	return fDisplayTimeouts;
} // end of ShowTimeouts

void Port::SetShowTimeouts(BOOL fNewState)
{
	fDisplayTimeouts = fNewState;
} // end of SetShowTimeouts
*/
BOOL Port::GetBinary()
{
	return fBinary;
} // end of GetBinary

void Port::SetBinary(BOOL fNewState)
{
	fBinary = fNewState;
} // end of SetBinary


DWORD Port::GetDTRControl()
{
	return fDtrControl;
} // end of GetDTRControl

void Port::SetDTRControl(DWORD dwNewVal) 
{
	fDtrControl = dwNewVal;
} // end of SetDTRControl

DWORD Port::GetRTSControl()
{
	return fRtsControl;
} // end of GetRTSControl

void Port::SetRTSControl(DWORD dwNewVal)
{
	fRtsControl = dwNewVal;
} // end of SetRTSControl

CHAR Port::GetXONChar()
{
	return chXON;
}

void Port::SetXONChar(CHAR chNewChar)
{
	chXON = chNewChar;
}

CHAR Port::GetXOFFChar()
{
	return chXOFF;
}

void Port::SetXOFFChar(CHAR chNewChar)
{
	chXOFF = chNewChar;
}

WORD Port::GetXONLimit()
{
	return wXONLimit;
}

void Port::SetXONLimit(WORD wNewVal)
{
	wXONLimit = wNewVal;
}

WORD Port::GetXOFFLimit()
{
	return wXOFFLimit;
}

void Port::SetXOFFLimit(WORD wNewVal)
{
	wXOFFLimit = wNewVal;
}

BOOL Port::GetCTSOutFlow()
{
	return fCTSOutFlow;
}

void Port::SetCTSOutFlow(BOOL bNewVal)
{
	fCTSOutFlow = bNewVal;
}

BOOL Port::GetDSROutFlow()
{
	return fDSROutFlow;
}

void Port::SetDSROutFlow(BOOL bNewVal)
{
	fDSROutFlow = bNewVal;
}

BOOL Port::GetDSRInFlow()
{
	return fDSRInFlow;
}

void Port::SetDSRInFlow(BOOL bNewVal)
{
	fDSRInFlow = bNewVal;
}

BOOL Port::GetXONXOFFOutFlow()
{
	return fXonXoffOutFlow;
}

void Port::SetXONXOFFOutFlow(BOOL bNewVal)
{
	fXonXoffOutFlow = bNewVal;
}

BOOL Port::GetXONXOFFInFlow()
{
	return fXonXoffInFlow;
}

void Port::SetXONXOFFInFlow(BOOL bNewVal)
{
	fXonXoffInFlow = bNewVal;
}

BOOL Port::GetTXAFTERXOFFSENT()
{
	return  fTXafterXoffSent;
}

void Port::SetTXAFTERXOFFSENT(BOOL bNewVal)
{
	fTXafterXoffSent = bNewVal;
}

BYTE Port::GetByteSize()
{
	return bByteSize;
} 

void Port::SetByteSize(BYTE bNewByte)
{
	bByteSize = bNewByte;
}

CHAR Port::GetFlagChar()
{
	return chFlag;
} 

void Port::SetFlagChar(CHAR chNewFlag)
{
	chFlag = chNewFlag;
}


COMMTIMEOUTS Port::GetTimeouts()
{
	return timeoutsnew;
}

void Port::SetTimeouts(COMMTIMEOUTS cto)
{
	// CommTimeouts is a structure, so we need to copy all members..
	// slower than pointers, but not used very often
	timeoutsnew.ReadIntervalTimeout = cto.ReadIntervalTimeout;
	timeoutsnew.ReadTotalTimeoutMultiplier = cto.ReadTotalTimeoutMultiplier;
	timeoutsnew.ReadTotalTimeoutConstant = cto.ReadTotalTimeoutConstant;
	timeoutsnew.WriteTotalTimeoutMultiplier = cto.WriteTotalTimeoutMultiplier;
	timeoutsnew.WriteTotalTimeoutConstant = cto.WriteTotalTimeoutConstant;
}

void Port::SetOrigTimeouts(COMMTIMEOUTS cto)
{
	timeoutsorig.ReadIntervalTimeout = cto.ReadIntervalTimeout;
	timeoutsorig.ReadTotalTimeoutMultiplier = cto.ReadTotalTimeoutMultiplier;
	timeoutsorig.ReadTotalTimeoutConstant = cto.ReadTotalTimeoutConstant;
	timeoutsorig.WriteTotalTimeoutMultiplier = cto.WriteTotalTimeoutMultiplier;
	timeoutsorig.WriteTotalTimeoutConstant = cto.WriteTotalTimeoutConstant;
}

COMMTIMEOUTS Port::GetOrigTimeouts()
{
	return timeoutsorig;
}

int Port::EscapeFunction(DWORD dwFN)
{
	// valid dwFN's could be checked here. - see winbase.h for values
	if ((dwFN <= SETXOFF) || (dwFN > CLRBREAK))
		return P_ERR_INVALID_ESCAPEFN;
	// allow developers access to escape functions for this port 
	EscapeCommFunction(GetComDev(),dwFN);
	return 0;
} // end of EscapeFunction


// return DCB 
/*
PDCB Port::GetDCB()
{
	if (!GetCommState(GetComDev(), &m_dcb)) {
	   ErrorReporter("GetCommState");
	   return ERR_GETCOMMSTATE;
	}
	return &m_dcb;
} // end of GetDCB

// allow setting of the comms parameters directly ?
int Port::SetDCB(PDCB theDCB)
{

} // end of SetDCB
*/