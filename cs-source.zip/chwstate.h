// chwstate.h
// the states that the callscape can be in
#ifndef _CHWSTATE_
 #define _CHWSTATE_
// Define serial port states constants. 
#define STATE_IDLE			0x00
#define STATE_WAITRESPONSE	0x01
#define STATE_WAITLENBYTE	0x02
#define STATE_WAITDATABYTE	0x03
#define STATE_WAITCHECKSUM	0x04
#define STATE_WAITCMDBYTE	0x05
#define STATE_WAITDATAHEAD	0x06
//#define STATE_WAITCRCBYTE2	0x07
#define STATE_WAITCLASSID	0x08
                  
// Define block receive id for serial port usage.                  
#define BLOCK_NONE			0x00
#define BLOCK_ESC2			0x01
#define BLOCK_ACK2          0x02
// #define BLOCK_ADSI          0x03 we don't do ADSI
#define BLOCK_CLIP          0x04
#define BLOCK_MEMO          0x05  
#define BLOCK_QUERY			0x06
#define BLOCK_ESC3			0x07// PTP 2/18/1997 added to mark that the
								// received data block is the retry of 
								// the previously received data block.
#endif // __CHWSTATE__