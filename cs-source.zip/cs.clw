; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CCsCtrl
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "cs.h"
CDK=Y

ClassCount=2
Class1=CCsCtrl
Class2=CCsPropPage

ResourceCount=2
LastPage=0
Resource1=IDD_PROPPAGE_CS
Resource2=IDD_ABOUTBOX_CS

[CLS:CCsCtrl]
Type=0
HeaderFile=CsCtl.h
ImplementationFile=CsCtl.cpp
Filter=W
BaseClass=COleControl
VirtualFilter=wWC
LastObject=CCsCtrl

[CLS:CCsPropPage]
Type=0
HeaderFile=CsPpg.h
ImplementationFile=CsPpg.cpp
Filter=D

[DLG:IDD_ABOUTBOX_CS]
Type=1
Class=?
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_PROPPAGE_CS]
Type=1
Class=CCsPropPage
ControlCount=0

