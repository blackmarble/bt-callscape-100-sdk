#if !defined(AFX_CSCTL_H__E7CB9F10_9316_11D1_9709_00A024CB61CA__INCLUDED_)
#define AFX_CSCTL_H__E7CB9F10_9316_11D1_9709_00A024CB61CA__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// #include "CallScapeHandler.h"
#include "CScapeHW.h"
#define MAX_CALLS 10

// CsCtl.h : Declaration of the CCsCtrl ActiveX Control class.

// OCX State machine requires the following states....
#define CS_OCX_STATE_IDLE					0x00 // makes if () easier if zero
#define CS_OCX_STATE_DISCONNECTED			0x01
#define CS_OCX_STATE_DISCONNECTING			0x02
#define CS_OCX_STATE_INITIALIZING			0x03
#define CS_OCX_STATE_EXPECTQUERYRESULT		0x04
#define CS_OCX_STATE_EXPECTCLIP				0x05
#define CS_OCX_STATE_BUSY					0x06
#define CS_OCX_STATE_HANDLINGERROR			0x07
#define CS_OCX_STATE_HANDLINGMESSAGE		0x08
#define CS_OCX_STATE_HANDLINGMISCEVENT		0x09
#define CS_OCX_STATE_ERROR					-1

#define CS_OCX_ERR_OK						0x00
#define CS_OCX_ERR_INVALIDSTATE				0xf0
#define CS_ERR_BADTIMER						0xf1
#define CS_ERR_DISCONNECTED					0xf2

// ....and the following events		
#define CS_OCX_EV_CONNECTING				0x01
#define CS_OCX_EV_CONNECTED					0x02
#define CS_OCX_EV_QUERYBOX					0x03
#define CS_OCX_EV_GOTQUERYRESULT			0x04
#define CS_OCX_EV_GETCLIP					0x05
#define CS_OCX_EV_GOTCLIP					0x06
#define CS_OCX_EV_DISCONNECTING				0x07
#define CS_OCX_EV_DISCONNECTED				0x08
#define CS_OCX_EV_HANDLINGMESSAGE			0x09
#define CS_OCX_EV_DONEMESSAGE				0x0a
#define CS_OCX_EV_HANDLINGERROR 			0x0b
#define CS_OCX_EV_DONEERROR					0x0c
#define CS_OCX_EV_HANDLINGMISCEVENT			0x0d
#define CS_OCX_EV_DONEMISCEVENT				0x0e

#define CS_WATCHDOG_TIMEOUT_VAL				10000

/////////////////////////////////////////////////////////////////////////////
// CCsCtrl : See CsCtl.cpp for implementation.

class CCsCtrl : public COleControl //, CCallScapeHandler
{
        DECLARE_DYNCREATE(CCsCtrl)

// Constructor
public:
     CCsCtrl();
	 int HandleCallScapeEvent(int nCallScapeEvent, PBYTE lpBuf, DWORD dwBufLen) ;
	 int HandleCallScapeError(PCHAR szMessage) ;
	 int HandleCallScapeMessage(PCHAR szMessage) ;
     CString m_sCallPhoneNumber[MAX_CALLS+1];
	 CString m_sComPort;
     CString m_sCallType[MAX_CALLS+1];
	 CString m_sCallTime[MAX_CALLS+1];
	 CString m_sCallName[MAX_CALLS+1];
	 CString m_sCallNoName[MAX_CALLS+1];
	 CString m_sCallMessagesNumber[MAX_CALLS+1];

	 short m_iCallDirection[MAX_CALLS+1];
	 short m_iStatus;
	 short m_icalllistsize;
	 short m_iEvent;

	 short m_iMissedOut;
	 short m_iMissedIn;
	 short m_iMissedLost;

	 short m_iTotalMissedCalls;
	 
	 char tmpstr[256];
// Overrides
        // ClassWizard generated virtual function overrides
        //{{AFX_VIRTUAL(CCsCtrl)
        public:
        virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
        virtual void DoPropExchange(CPropExchange* pPX);
        virtual void OnResetState();
        //}}AFX_VIRTUAL

// Implementation
protected:
        ~CCsCtrl();
		CallScapeHW * m_Callscape; // the callscape object
        DECLARE_OLECREATE_EX(CCsCtrl)    // Class factory and guid
        DECLARE_OLETYPELIB(CCsCtrl)      // GetTypeInfo
        DECLARE_PROPPAGEIDS(CCsCtrl)     // Property page IDs
        DECLARE_OLECTLTYPE(CCsCtrl)             // Type name and misc status

// Message maps
        //{{AFX_MSG(CCsCtrl)
	    afx_msg LRESULT OnCSMessage(WPARAM wParam, LPARAM lParam);
		afx_msg LRESULT OnCSError(WPARAM wParam, LPARAM lParam);
		afx_msg LRESULT OnCSEvent(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
        DECLARE_MESSAGE_MAP()

// Dispatch maps
        //{{AFX_DISPATCH(CCsCtrl)
        afx_msg short Hangup();
        afx_msg long Dial(LPCTSTR pno);
	afx_msg short Connect(LPCTSTR port);
	afx_msg short Disconnect();
	afx_msg short Status();
	afx_msg BSTR ComPort();
	afx_msg BSTR CallTime(short callnumber);
	afx_msg BSTR PhoneNumber(short callnumber);
	afx_msg BSTR CallName(short callnumber);
	afx_msg BSTR CallNoName(short callnumber);
	afx_msg BSTR CallMessagesNumber(short callnumber);
	afx_msg short GetMissedCalls();
	afx_msg short MissedCalls();
	afx_msg short MissedLost();
	afx_msg short MissedOutgoing();
	afx_msg short MissedIncoming();
	afx_msg short IsBusy();
	//}}AFX_DISPATCH
        DECLARE_DISPATCH_MAP()

        afx_msg void AboutBox();

// Event maps
        //{{AFX_EVENT(CCsCtrl)
	void FirePhoneNumberChanged(LPCTSTR phoneNumber)
		{FireEvent(eventidPhoneNumberChanged,EVENT_PARAM(VTS_BSTR), phoneNumber);}
	void FireStatusChanged(short status)
		{FireEvent(eventidStatusChanged,EVENT_PARAM(VTS_I2), status);}
	void FireDialedChar(LPCTSTR dialedchar)
		{FireEvent(eventidDialedChar,EVENT_PARAM(VTS_BSTR), dialedchar);}
	void FireEventChanged(short eventchanged)
		{FireEvent(eventidEventChanged,EVENT_PARAM(VTS_I2), eventchanged);}
	//}}AFX_EVENT
        DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
        enum {
        //{{AFX_DISP_ID(CCsCtrl)
	dispidHangup = 1L,
	dispidDial = 2L,
	dispidConnect = 3L,
	dispidDisconnect = 4L,
	dispidStatus = 5L,
	dispidComPort = 6L,
	dispidCallTime = 7L,
	dispidPhoneNumber = 8L,
	dispidCallName = 9L,
	dispidCallNoName = 10L,
	dispidCallMessagesNumber = 11L,
	dispidGetMissedCalls = 12L,
	dispidMissedCalls = 13L,
	dispidMissedLost = 14L,
	dispidMissedOutgoing = 15L,
	dispidMissedIncoming = 16L,
	dispidIsBusy = 17L,
	eventidPhoneNumberChanged = 1L,
	eventidStatusChanged = 2L,
	eventidDialedChar = 3L,
	eventidEventChanged = 4L,
	//}}AFX_DISP_ID
        };
private : 
	short PostEvent(short Event); // to update the state machine
	short StartWatchDogTimer();
	short StopWatchDogTimer();
	short m_CurrentState; // the state of the callscape messaging software
    // busy flag indicates to vb that cs is not ready for function calls.
	// set by Callscape stuff
    short m_busy; 
	void  SetBusy(short newstate); // used to set m_busy (latches on STATE_ERROR)
	short m_ForcedBusy; // set by software when it knows there is a lot to do
	// for DEBUG ONLY
	void TranslateState(short State);
	void TranslateEvent(short Event);
	// used to guard against timeouts...
	UINT m_uiWatchDogTimer;
	
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CSCTL_H__E7CB9F10_9316_11D1_9709_00A024CB61CA__INCLUDED)

