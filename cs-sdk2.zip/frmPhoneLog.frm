VERSION 5.00
Object = "{00028C01-0000-0000-0000-000000000046}#1.0#0"; "DBGRID32.OCX"
Begin VB.Form frmPhoneLog 
   Caption         =   "PhoneBook Query"
   ClientHeight    =   3672
   ClientLeft      =   1104
   ClientTop       =   336
   ClientWidth     =   5544
   LinkTopic       =   "Form1"
   ScaleHeight     =   3672
   ScaleWidth      =   5544
   Begin VB.Data datPrimaryRS 
      Align           =   2  'Align Bottom
      Caption         =   " "
      Connect         =   "Access"
      DatabaseName    =   "C:\user\btsdk\vb\phonebook.mdb"
      DefaultCursorType=   0  'DefaultCursor
      DefaultType     =   2  'UseODBC
      Exclusive       =   0   'False
      Height          =   324
      Left            =   0
      Options         =   0
      ReadOnly        =   0   'False
      RecordsetType   =   1  'Dynaset
      RecordSource    =   "select [DateStamp],[TimeStamp],[PersonName],[Call Discription],[PhoneNumber] from [PhoneBook Query] Order by [DateStamp]"
      Top             =   3348
      Visible         =   0   'False
      Width           =   5544
   End
   Begin MSDBGrid.DBGrid grdDataGrid 
      Align           =   1  'Align Top
      Bindings        =   "frmPhoneLog.frx":0000
      Height          =   3504
      Left            =   0
      OleObjectBlob   =   "frmPhoneLog.frx":015A
      TabIndex        =   0
      Top             =   0
      Width           =   5544
   End
End
Attribute VB_Name = "frmPhoneLog"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Const DBNAME = "phonebook.mdb"

Private Sub datPrimaryRS_Error(DataErr As Integer, Response As Integer)
  'This is where you would put error handling code
  'If you want to ignore errors, comment out the next line
  'If you want to trap them, add code here to handle them
  MsgBox "Data error event hit err:" & Error$(DataErr)
  Response = 0  'Throw away the error
End Sub

Private Sub datPrimaryRS_Reposition()
  Screen.MousePointer = vbDefault
  On Error Resume Next
End Sub

Private Sub datPrimaryRS_Validate(Action As Integer, Save As Integer)
  'This is where you put validation code
  'This event gets called when the following actions occur
  Select Case Action
    Case vbDataActionMoveFirst
    Case vbDataActionMovePrevious
    Case vbDataActionMoveNext
    Case vbDataActionMoveLast
    Case vbDataActionAddNew
    Case vbDataActionUpdate
    Case vbDataActionDelete
    Case vbDataActionFind
    Case vbDataActionBookmark
    Case vbDataActionClose
      Screen.MousePointer = vbDefault
  End Select
  Screen.MousePointer = vbHourglass
End Sub

Private Sub Form_Load()
 dname = App.Path & "\" & DBNAME
 datPrimaryRS.DatabaseName = dname
 
End Sub

Private Sub Form_Unload(Cancel As Integer)
  Screen.MousePointer = vbDefault
End Sub

Private Sub Form_Resize()
  On Error Resume Next
  'This will resize the grid when the form is resized
  grdDataGrid.Height = Me.ScaleHeight - 30
End Sub

Private Sub grdDataGrid_Click()

End Sub
