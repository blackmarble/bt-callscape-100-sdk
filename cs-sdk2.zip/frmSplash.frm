VERSION 5.00
Begin VB.Form frmSplash 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   3705
   ClientLeft      =   30
   ClientTop       =   30
   ClientWidth     =   5850
   ControlBox      =   0   'False
   Icon            =   "frmSplash.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3705
   ScaleWidth      =   5850
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Visible         =   0   'False
   Begin VB.Frame fraMainFrame 
      Height          =   3615
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   5820
      Begin VB.CommandButton Command1 
         Caption         =   "OK"
         Height          =   495
         Left            =   4320
         TabIndex        =   9
         Top             =   2880
         Width           =   1095
      End
      Begin VB.PictureBox picLogo 
         Height          =   615
         Left            =   510
         Picture         =   "frmSplash.frx":0442
         ScaleHeight     =   555
         ScaleWidth      =   615
         TabIndex        =   1
         Top             =   840
         Width           =   675
      End
      Begin VB.Label Label3 
         Caption         =   "NOT FOR GENERAL RELEASE"
         Height          =   375
         Left            =   480
         TabIndex        =   8
         Top             =   1920
         Width           =   1935
      End
      Begin VB.Label Label1 
         Caption         =   "FOR EVALUATION PURPOSES ONLY"
         Height          =   255
         Left            =   480
         TabIndex        =   7
         Top             =   1560
         Width           =   2895
      End
      Begin VB.Label lblProductName 
         AutoSize        =   -1  'True
         Caption         =   "BT VB Phone"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   31.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   750
         Left            =   1320
         TabIndex        =   6
         Tag             =   "Product"
         Top             =   840
         Width           =   3990
      End
      Begin VB.Label lblPlatform 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "Version"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   15.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   360
         Left            =   1680
         TabIndex        =   5
         Tag             =   "Platform"
         Top             =   2520
         Width           =   1140
      End
      Begin VB.Label lblVersion 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "0.17a"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   285
         Left            =   2205
         TabIndex        =   4
         Tag             =   "Version"
         Top             =   2880
         Width           =   600
      End
      Begin VB.Label lblCompany 
         Caption         =   "Black Marble"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   3720
         TabIndex        =   3
         Tag             =   "Company"
         Top             =   1920
         Width           =   1095
      End
      Begin VB.Label lblCopyright 
         Caption         =   "Copyright 1998"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   3720
         TabIndex        =   2
         Tag             =   "Copyright"
         Top             =   1680
         Width           =   1575
      End
   End
End
Attribute VB_Name = "frmSplash"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
 Unload Me
End Sub

Private Sub Form_Load()
    lblVersion.Caption = App.Major & "." & App.Minor & "." & App.Revision
    lblProductName.Caption = App.Title
End Sub

