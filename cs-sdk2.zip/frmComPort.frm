VERSION 5.00
Begin VB.Form frmComPort 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "ComPort"
   ClientHeight    =   2610
   ClientLeft      =   2835
   ClientTop       =   3480
   ClientWidth     =   3315
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1542.624
   ScaleMode       =   0  'User
   ScaleWidth      =   3104.821
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.OptionButton comport 
      Caption         =   "COM4"
      Height          =   372
      Index           =   4
      Left            =   1560
      TabIndex        =   4
      Top             =   1200
      Width           =   1215
   End
   Begin VB.OptionButton comport 
      Caption         =   "COM3"
      Height          =   195
      Index           =   3
      Left            =   1560
      TabIndex        =   3
      Top             =   960
      Width           =   975
   End
   Begin VB.OptionButton comport 
      Caption         =   "COM1"
      Height          =   195
      Index           =   1
      Left            =   480
      TabIndex        =   1
      Top             =   960
      Value           =   -1  'True
      Width           =   975
   End
   Begin VB.OptionButton comport 
      Caption         =   "COM2"
      Height          =   372
      Index           =   2
      Left            =   480
      TabIndex        =   2
      Top             =   1200
      Width           =   852
   End
   Begin VB.Frame Frame1 
      Caption         =   "Ports"
      Height          =   1212
      Left            =   360
      TabIndex        =   6
      Top             =   600
      Width           =   2772
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   390
      Left            =   1080
      TabIndex        =   0
      Top             =   2040
      Width           =   1140
   End
   Begin VB.Label Label1 
      Caption         =   "Please Select CallScape Connection"
      Height          =   252
      Left            =   240
      TabIndex        =   5
      Top             =   240
      Width           =   2772
   End
End
Attribute VB_Name = "frmComPort"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public PortSelected As Integer
Public PortString As String
Private Sub cmdOK_Click()
    Me.Hide
End Sub
Private Sub comport_Click(Index As Integer)
 PortSelected = Index
 If Index = 1 Then PortString = "COM1"
 If Index = 2 Then PortString = "COM2"
 If Index = 3 Then PortString = "COM3"
 If Index = 4 Then PortString = "COM4"
 
End Sub

Private Sub Form_Load()
 PortSelected = 1
 PortString = "COM1"
End Sub
