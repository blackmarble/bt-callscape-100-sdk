VERSION 5.00
Object = "{E7CB9EFF-9316-11D1-9709-00A024CB61CA}#1.0#0"; "CS.OCX"
Begin VB.Form Phonefrm 
   BackColor       =   &H00C0C0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "BT VB Phone"
   ClientHeight    =   5175
   ClientLeft      =   30
   ClientTop       =   315
   ClientWidth     =   6525
   Icon            =   "Mainfrm.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5175
   ScaleWidth      =   6525
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox Text4 
      Height          =   372
      Left            =   4320
      TabIndex        =   37
      Top             =   4680
      Width           =   1935
   End
   Begin VB.TextBox Text3 
      Height          =   372
      Left            =   1200
      TabIndex        =   36
      Top             =   4680
      Width           =   1695
   End
   Begin CSLib.Cs CallScape1 
      Height          =   495
      Left            =   2760
      TabIndex        =   35
      Top             =   2160
      Width           =   975
      _Version        =   65536
      _ExtentX        =   1714
      _ExtentY        =   868
      _StockProps     =   1
   End
   Begin VB.TextBox Text2 
      Height          =   372
      Left            =   4320
      TabIndex        =   34
      Top             =   4200
      Width           =   1935
   End
   Begin VB.TextBox Text1 
      Height          =   372
      Left            =   1200
      TabIndex        =   33
      Top             =   4200
      Width           =   1695
   End
   Begin VB.CommandButton x2way 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":0442
      Height          =   372
      Left            =   3960
      Picture         =   "Mainfrm.frx":0921
      Style           =   1  'Graphical
      TabIndex        =   32
      Top             =   2520
      Width           =   1092
   End
   Begin VB.CommandButton Keypad 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":0E00
      Enabled         =   0   'False
      Height          =   372
      Left            =   120
      Picture         =   "Mainfrm.frx":1217
      Style           =   1  'Graphical
      TabIndex        =   31
      Top             =   720
      Width           =   735
   End
   Begin VB.CommandButton Recent 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":1614
      Enabled         =   0   'False
      Height          =   372
      Left            =   360
      Picture         =   "Mainfrm.frx":1A77
      Style           =   1  'Graphical
      TabIndex        =   30
      Top             =   3360
      Width           =   732
   End
   Begin VB.CommandButton Search 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":1F0A
      Enabled         =   0   'False
      Height          =   372
      Left            =   1920
      Picture         =   "Mainfrm.frx":233D
      Style           =   1  'Graphical
      TabIndex        =   29
      Top             =   720
      Width           =   735
   End
   Begin VB.CommandButton Paused 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":2738
      Enabled         =   0   'False
      Height          =   372
      Left            =   1080
      Picture         =   "Mainfrm.frx":2BA3
      Style           =   1  'Graphical
      TabIndex        =   28
      Top             =   3360
      Width           =   732
   End
   Begin VB.CommandButton QuickDial 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":3032
      Enabled         =   0   'False
      Height          =   372
      Left            =   840
      Picture         =   "Mainfrm.frx":3485
      Style           =   1  'Graphical
      TabIndex        =   27
      Top             =   720
      Width           =   1095
   End
   Begin VB.CommandButton ReminderCall 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":38A3
      Enabled         =   0   'False
      Height          =   372
      Left            =   5040
      Picture         =   "Mainfrm.frx":3DE9
      Style           =   1  'Graphical
      TabIndex        =   26
      Top             =   1800
      Width           =   1092
   End
   Begin VB.CommandButton Notes 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":4390
      Enabled         =   0   'False
      Height          =   372
      Left            =   4680
      Picture         =   "Mainfrm.frx":4793
      Style           =   1  'Graphical
      TabIndex        =   25
      Top             =   3000
      Width           =   732
   End
   Begin VB.CommandButton RecentCalls 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":4BA7
      Enabled         =   0   'False
      Height          =   372
      Left            =   2640
      Picture         =   "Mainfrm.frx":5019
      Style           =   1  'Graphical
      TabIndex        =   24
      Top             =   720
      Width           =   1095
   End
   Begin VB.CommandButton CallLog 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":5455
      Height          =   724
      Left            =   5400
      Picture         =   "Mainfrm.frx":58B9
      Style           =   1  'Graphical
      TabIndex        =   23
      Top             =   3000
      Width           =   732
   End
   Begin VB.CommandButton CallMinder 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":5D99
      Enabled         =   0   'False
      Height          =   372
      Left            =   5040
      Picture         =   "Mainfrm.frx":62B5
      Style           =   1  'Graphical
      TabIndex        =   22
      Top             =   2520
      Width           =   1092
   End
   Begin VB.CommandButton CallReturn 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":682F
      Enabled         =   0   'False
      Height          =   372
      Left            =   3960
      Picture         =   "Mainfrm.frx":6D42
      Style           =   1  'Graphical
      TabIndex        =   21
      Top             =   1800
      Width           =   1092
   End
   Begin VB.CommandButton CallWaiting 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":72B3
      Enabled         =   0   'False
      Height          =   372
      Left            =   3960
      Picture         =   "Mainfrm.frx":77E4
      Style           =   1  'Graphical
      TabIndex        =   20
      Top             =   2160
      Width           =   1092
   End
   Begin VB.CommandButton Delete 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":7D72
      Enabled         =   0   'False
      Height          =   372
      Left            =   1800
      Picture         =   "Mainfrm.frx":81E8
      Style           =   1  'Graphical
      TabIndex        =   19
      Top             =   3360
      Width           =   732
   End
   Begin VB.CommandButton Dial 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":867D
      Height          =   495
      Left            =   3840
      Picture         =   "Mainfrm.frx":8B44
      Style           =   1  'Graphical
      TabIndex        =   18
      Top             =   1200
      Width           =   1215
   End
   Begin VB.CommandButton Directory 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":9032
      Height          =   372
      Left            =   3960
      Picture         =   "Mainfrm.frx":9436
      Style           =   1  'Graphical
      TabIndex        =   17
      Top             =   3360
      Width           =   732
   End
   Begin VB.CommandButton EndCall 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":9863
      Height          =   495
      Left            =   5040
      Picture         =   "Mainfrm.frx":9D43
      Style           =   1  'Graphical
      TabIndex        =   16
      Top             =   1200
      Width           =   1335
   End
   Begin VB.CommandButton Entries 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":A24C
      Enabled         =   0   'False
      Height          =   372
      Left            =   3960
      Picture         =   "Mainfrm.frx":A645
      Style           =   1  'Graphical
      TabIndex        =   15
      Top             =   3000
      Width           =   732
   End
   Begin VB.CommandButton NotesLog 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":AA61
      Enabled         =   0   'False
      Height          =   372
      Left            =   4680
      Picture         =   "Mainfrm.frx":AE77
      Style           =   1  'Graphical
      TabIndex        =   14
      Top             =   3360
      Width           =   732
   End
   Begin VB.CommandButton CallDiversion 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":B29E
      Enabled         =   0   'False
      Height          =   372
      Left            =   5040
      Picture         =   "Mainfrm.frx":B7D2
      Style           =   1  'Graphical
      TabIndex        =   13
      Top             =   2160
      Width           =   1092
   End
   Begin VB.TextBox PDisplay 
      Enabled         =   0   'False
      Height          =   852
      Left            =   3960
      TabIndex        =   12
      Top             =   240
      Width           =   2295
   End
   Begin VB.CommandButton DIGIT 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":BD72
      Height          =   492
      Index           =   11
      Left            =   600
      Picture         =   "Mainfrm.frx":C23A
      Style           =   1  'Graphical
      TabIndex        =   11
      Tag             =   "*"
      Top             =   2760
      Width           =   612
   End
   Begin VB.CommandButton DIGIT 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":C6F7
      Height          =   492
      Index           =   10
      Left            =   1800
      Picture         =   "Mainfrm.frx":CBAF
      Style           =   1  'Graphical
      TabIndex        =   10
      Tag             =   "#"
      Top             =   2760
      Width           =   612
   End
   Begin VB.CommandButton DIGIT 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":D066
      Height          =   492
      Index           =   9
      Left            =   1800
      Picture         =   "Mainfrm.frx":D540
      Style           =   1  'Graphical
      TabIndex        =   9
      Tag             =   "9"
      Top             =   2280
      Width           =   612
   End
   Begin VB.CommandButton DIGIT 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":DA19
      Height          =   492
      Index           =   8
      Left            =   1200
      Picture         =   "Mainfrm.frx":DEE5
      Style           =   1  'Graphical
      TabIndex        =   8
      Tag             =   "8"
      Top             =   2280
      Width           =   612
   End
   Begin VB.CommandButton DIGIT 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":E3B5
      Height          =   492
      Index           =   7
      Left            =   600
      Picture         =   "Mainfrm.frx":E885
      Style           =   1  'Graphical
      TabIndex        =   7
      Tag             =   "7"
      Top             =   2280
      Width           =   612
   End
   Begin VB.CommandButton DIGIT 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":ED57
      Height          =   492
      Index           =   6
      Left            =   1800
      Picture         =   "Mainfrm.frx":F222
      Style           =   1  'Graphical
      TabIndex        =   6
      Tag             =   "6"
      Top             =   1800
      Width           =   612
   End
   Begin VB.CommandButton DIGIT 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":F6F3
      Height          =   492
      Index           =   5
      Left            =   1200
      Picture         =   "Mainfrm.frx":FBAC
      Style           =   1  'Graphical
      TabIndex        =   5
      Tag             =   "5"
      Top             =   1800
      Width           =   612
   End
   Begin VB.CommandButton DIGIT 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":10072
      Height          =   492
      Index           =   4
      Left            =   600
      Picture         =   "Mainfrm.frx":10534
      Style           =   1  'Graphical
      TabIndex        =   4
      Tag             =   "4"
      Top             =   1800
      Width           =   612
   End
   Begin VB.CommandButton DIGIT 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":10A0A
      Height          =   492
      Index           =   3
      Left            =   1800
      Picture         =   "Mainfrm.frx":10ED4
      Style           =   1  'Graphical
      TabIndex        =   3
      Tag             =   "3"
      Top             =   1320
      Width           =   612
   End
   Begin VB.CommandButton DIGIT 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":113A0
      Height          =   492
      Index           =   2
      Left            =   1200
      Picture         =   "Mainfrm.frx":11863
      Style           =   1  'Graphical
      TabIndex        =   2
      Tag             =   "2"
      Top             =   1320
      Width           =   612
   End
   Begin VB.CommandButton DIGIT 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":11D39
      Height          =   492
      Index           =   1
      Left            =   600
      Picture         =   "Mainfrm.frx":121E8
      Style           =   1  'Graphical
      TabIndex        =   1
      Tag             =   "1"
      Top             =   1320
      Width           =   612
   End
   Begin VB.CommandButton DIGIT 
      Appearance      =   0  'Flat
      DownPicture     =   "Mainfrm.frx":12695
      Height          =   492
      Index           =   0
      Left            =   1200
      Picture         =   "Mainfrm.frx":12B4E
      Style           =   1  'Graphical
      TabIndex        =   0
      Tag             =   "0"
      Top             =   2760
      Width           =   612
   End
   Begin VB.Label Label4 
      BackStyle       =   0  'Transparent
      Caption         =   "Dialed No."
      Height          =   255
      Left            =   3240
      TabIndex        =   41
      Top             =   4680
      Width           =   1095
   End
   Begin VB.Label Label3 
      BackStyle       =   0  'Transparent
      Caption         =   "Event No."
      Height          =   375
      Left            =   120
      TabIndex        =   40
      Top             =   4680
      Width           =   975
   End
   Begin VB.Label Label2 
      BackStyle       =   0  'Transparent
      Caption         =   "Status"
      Height          =   375
      Left            =   3240
      TabIndex        =   39
      Top             =   4320
      Width           =   855
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "Phone No."
      Height          =   255
      Left            =   120
      TabIndex        =   38
      Top             =   4320
      Width           =   855
   End
   Begin VB.Line Line1 
      X1              =   240
      X2              =   6000
      Y1              =   3960
      Y2              =   3960
   End
   Begin VB.Image Image1 
      Height          =   5190
      Left            =   0
      Picture         =   "Mainfrm.frx":13004
      Top             =   0
      Width           =   6540
   End
End
Attribute VB_Name = "Phonefrm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim DialString As String
Dim dname As String
Dim db As Database
Dim sqlcmd As String

Private Sub CallLog_Click()
 frmPhoneLog.Show
End Sub
Private Sub CallScape1_PhoneNumberChanged(ByVal phoneNumber As String)
 Text1.Text = phoneNumber
 DialString = phoneNumber
 SETDISPLAY (DialString)
 ' this line if left in causes a db error, tmp commented out
 X = UpdatePhoneLog(0, phoneNumber)
End Sub
Private Sub CallScape1_StatusChanged(ByVal Status As Integer)
 Text2.Text = Status
End Sub
Private Sub CallScape1_EventChanged(ByVal eventchanged As Integer)
 Text3.Text = eventchanged
 If eventchaged = 27 Then
   DialString = ""
   SETDISPLAY (DialString)
 End If
End Sub
Private Sub CallScape1_DialedChar(ByVal dialedchar As String)
 Text1.Text = dialedchar
 DialString = DialString + dialedchar
 SETDISPLAY (DialString)
End Sub
Private Sub Delete_Click()
 DialString = ""
 SETDISPLAY (DialString)
End Sub
Private Sub Dial_Click()
If DialString = "" Then
   MsgBox ("No number to dial")
Else
   X = UpdatePhoneLog(1, DialString)
   CallScape1.Dial (DialString)
End If
End Sub
Private Sub DIGIT_Click(Index As Integer)
 DialString = DialString + DIGIT(Index).Tag
 SETDISPLAY (DialString)
End Sub
Private Sub Directory_Click()
 frmPhoneBook.Show
End Sub
Private Sub EndCall_Click()
 CallScape1.Hangup
 DialString = ""
 SETDISPLAY (DialString)
End Sub
Private Sub SETDISPLAY(str As String)
 PDisplay.Text = str
End Sub
Function UpdatePhoneLog(calldir As Integer, phoneNumber As String)
sqlcmd = "INSERT INTO PhoneLog VALUES ( '" & phoneNumber & "' , '" & Date & "' , " & calldir & " , '" & Time & "' );"
'MsgBox (sqlcmd)
db.Execute sqlcmd, dbSQLPassThrough
End Function


Private Sub Form_Load()
 frmSplash.Show vbModal, Me
 frmComPort.Show vbModal, Me
 Dim s As String
 Dim NumMissedCalls As Integer
 Dim Retries As Integer
 Dim i As Integer
 Dim Timeout As Integer
 Timeout = 10000
 Retries = 0

' Open the log database
dname = App.Path & "\" & "phonebook.mdb"
Set db = OpenDatabase(dname)
 
 
 CallScape1.Connect (frmComPort.PortString)
 ' wait for connect to complete
   While (Retries < Timeout) And (CallScape1.IsBusy <> 0)
    DoEvents
    Retries = Retries + 1
   Wend
   If (Retries >= Timeout) Then
     MsgBox ("Timeout connecting to CallScape")
     Unload Me
     End
   End If
   If (CallScape1.IsBusy <> 0) Then
     MsgBox ("Error Connecting to callscape due to it being busy")
     Unload Me
     End
   End If
   
   
   CallScape1.GetMissedCalls
   ' this will make the callscape busy
 Retries = 0
 While (Retries < Timeout) And (CallScape1.IsBusy <> 0)
    DoEvents
    Retries = Retries + 1
 Wend
 If (Retries >= Timeout) Then MsgBox ("Timeout getting missed calls")
 If (CallScape1.IsBusy = -1) Then
    MsgBox ("Error Communicating with Callscape - check port settings and power")
    Unload Me
 End If
 
 NumMissedCalls = CallScape1.MissedCalls
 If (NumMissedCalls < 0) Then
    MsgBox ("Error Communicating with Callscape - check port settings and power")
    Unload Me
 End If
 
 If (NumMissedCalls > 0) Then
   ' there are missed calls
   s = "There are " + str(NumMissedCalls) + " missed calls."
   MsgBox s
   ' now do something with them
 
   For i = 1 To NumMissedCalls
     s = "Missed Call " + str(i) + " : " + CallScape1.phoneNumber(i)
     MsgBox s
   Next i
 Else
MsgBox "There are no missed calls"
 End If
 
 
End Sub

Private Sub Form_Unload(Cancel As Integer)
' close the login DB
db.Close
' disconnect from the callscape
CallScape1.Disconnect
End Sub
